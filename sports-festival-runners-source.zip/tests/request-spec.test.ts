import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { JUMP_PATTERNS } from '../src/games/basketball/patterns';
import { planRows,fillChunk,type CourseObject,type Chunk } from '../src/games/football/chunks';
import { Random } from '../src/core/types';
const rhythms=[[.88,.90,1.16,.94,.96,1.16],[1.12,.88,1.04,.88,.96,1.12],[.94,1.14,.88,1.14,.90,1.00]];
test('Requested cadence assignments preserve all 90 recipes plus all 18 rotated accent phrases',()=>{
  const accents=[['normal','normal','normal','high','long','high'],['high','high','normal','high','long','long'],['long','normal','high','long','normal','long']];
  for(let i=0;i<90;i++){assert.deepEqual(JUMP_PATTERNS[i].cadence,rhythms[i%3]);for(const type of ['normal','high','long'])assert.equal(JUMP_PATTERNS[i].beats.filter(b=>b===type).length,2);}
  accents.forEach((sequence,family)=>{for(let shift=0;shift<6;shift++){const p=JUMP_PATTERNS[90+family*6+shift];assert.deepEqual(p.beats,[...sequence.slice(shift),...sequence.slice(0,shift)]);assert.deepEqual(p.cadence,rhythms[family]);}});
});
test('Requested hold and late barriers retain their exact physical timings and finite footprints',()=>{
 for(const tempo of ['quick','hold','late'] as const){const rows=planRows(0,'hardCrossing',1.05,{z:-4,safeX:0,gap:2},new Random(3),false,undefined,44,tempo);const c:Chunk={id:3,start:0,kind:'hardCrossing',rows,safeX:rows[1].safeX,gap:1.05,objects:[],variant:2,crossingTempo:tempo,length:rows[1].z+5};let id=0;fillChunk(c,(type,x,z,width,depth,height):CourseObject=>({id:id++,type,x,baseX:x,z,width,depth,height,moving:false,amplitude:0,frequency:0,phase:0,passed:false}));
 const rails=c.objects.filter(o=>o.type==='wall'&&o.height===.55);assert.ok(rails.every(o=>o.depth===.5));for(const row of rows)assert.ok(rails.some(o=>Math.abs(o.z-(row.z-(tempo==='late'?.55:2.4)))<1e-8));if(tempo==='hold'){assert.equal(rows[0].clearance,5.4+44*1.35*.20);assert.ok(rails.some(o=>Math.abs(o.z-(rows[0].z+4.8))<1e-8));}}
});
test('Two-game production copy is explicitly limited while independent dodgeball sources stay local',()=>{
 const config=readFileSync(new URL('../vite.config.ts',import.meta.url),'utf8');assert.match(config,/publicDir: command === 'serve' \? 'public' : false/);assert.match(config,/\['\.nojekyll', 'favicon.svg', 'licenses'\]/);
 const app=readFileSync(new URL('../src/App.tsx',import.meta.url),'utf8');assert.ok(!/dodgeball|TestHub|research\/Admin/.test(app));
});
