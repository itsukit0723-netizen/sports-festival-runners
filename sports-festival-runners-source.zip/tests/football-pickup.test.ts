import test from 'node:test';
import assert from 'node:assert/strict';
import { FootballModel } from '../src/games/football/model';
import { FOOTBALL as F, STEP } from '../src/core/config';
import { emptyInput } from '../src/core/types';
import { collectsStar } from '../src/games/football/pickup';
import type { CourseObject } from '../src/games/football/chunks';

function scenario(type:'star'|'boost'='star',x=0,z=0) {
  const model=new FootballModel(1);model.distance=0;model.x=x;
  const token:CourseObject={id:99999,type,x:0,baseX:0,z,width:1,depth:.1,height:1,moving:false,amplitude:0,frequency:0,phase:0,passed:false};
  model.chunks=[{id:0,start:0,kind:'bonusCoin',safeX:0,gap:3,rows:[{z:10,safeX:0,gap:3}],objects:[token]}];
  return {model,token};
}

test('Stars require close contact: old square corners, sideways misses and early collection are excluded',()=>{
  for(const [x,z] of [[.7,0],[.5,.5],[0,.75]]){
    const {model,token}=scenario('star',x,z+F.forwardSpeed*STEP);
    model.update(STEP,emptyInput());assert.equal(model.coins,0,`${x},${z}`);assert.equal(token.passed,false);
  }
  for(const x of [-.55,0,.55]){const {model}=scenario('star',x,F.forwardSpeed*STEP/2);model.update(STEP,emptyInput());assert.equal(model.coins,1);}
});

test('Fast sideways and forward crossings collect a contacted star exactly once',()=>{
  const {model,token}=scenario('star',-2,F.forwardSpeed*STEP/2);
  model.update(STEP,{...emptyInput(),drag:4/F.dragSensitivity});
  assert.equal(model.x,2);assert.equal(model.coins,1);assert.equal(token.passed,true);
  model.update(STEP,emptyInput());assert.equal(model.coins,1);
  assert.ok(collectsStar(0,-2,0,2,0,0));
  assert.equal(collectsStar(-2,.7,2,.7,0,0),false);
  assert.equal(collectsStar(0,0,0,0,.63,0),false);
});

test('Boost pickup and double-star rewards retain their previous behavior',()=>{
  const boost=scenario('boost',.75,1.1);boost.model.update(STEP,emptyInput());assert.ok(boost.model.boost>0);
  const star=scenario('star',0,0);star.token.rewardMultiplier=2;star.model.update(STEP,emptyInput());
  assert.equal(star.model.events.find(e=>e.kind==='coin')?.points,F.tokenScore*2);
});
