import {skilledBasketballInput} from './helpers/basketball-player';
import assert from 'node:assert/strict';import fs from 'node:fs';
import {BasketballModel,isRunnerPickup,runnerPickupClear} from '../src/games/basketball/model';import {FootballModel} from '../src/games/football/model';import {DifficultyDirector} from '../src/core/director';import {Random,emptyInput} from '../src/core/types';import {STEP,BASKETBALL as B,FOOTBALL as F} from '../src/core/config';import {routeX,choiceRouteX,scrambleChoiceX,courseChunkLength,courseCollision} from '../src/games/football/chunks';
fs.mkdirSync('artifacts/audit-20261025',{recursive:true});
const results={basketball180s:0,football180s:0,football600s:0,randomizedRuns:0,totalSteps:0,physicsChecks:0};let maxB=0,maxF=0;const started=Date.now();
for(let seed=1;seed<=120;seed++){
 const b=new BasketballModel(seed),director=new DifficultyDirector(new Random(1));
 for(let i=0;i<180/STEP&&!b.over;i++){
  b.update(STEP,skilledBasketballInput(b));b.events.length=0;maxB=Math.max(maxB,b.objects.length);results.totalSteps++;
  assert.ok([b.y,b.vy,b.score,b.speed].every(Number.isFinite));
  if(i%120===0)for(const p of b.objects.filter(isRunnerPickup))assert.ok(runnerPickupClear(p.x,p.y,b.objects));
 }
 assert.ok(!b.over&&b.time>=179.9,`basketball seed ${seed} failed at ${b.time}`);results.basketball180s++;
 const f=new FootballModel(seed);for(let i=0;i<180/STEP&&!f.over;i++){
  const dx=f.nextChallengeRow().safeX-f.x;f.update(STEP,{...emptyInput(),axis:Math.abs(dx)<.06?0:Math.sign(dx)});f.events.length=0;results.totalSteps++;
  maxF=Math.max(maxF,f.chunks.reduce((n,c)=>n+c.objects.length,0));assert.ok(Number.isFinite(f.score)&&Number.isFinite(f.x)&&f.chunks.length<=8);
 }assert.ok(!f.over&&f.time>=179.9,`football seed ${seed} failed at ${f.time}`);results.football180s++;
 if(seed%20===0)console.log(`safe-route progress ${seed}/120`);
}
for(let seed=1;seed<=12;seed++){const f=new FootballModel(seed);while(f.time<600&&!f.over){const dx=f.nextChallengeRow().safeX-f.x;f.update(STEP,{...emptyInput(),axis:Math.abs(dx)<.06?0:Math.sign(dx)});f.events.length=0;results.totalSteps++;assert.ok(f.chunks.length<=8&&Number.isFinite(f.score));}assert.ok(!f.over&&f.time>=599.9,`600s seed ${seed}`);results.football600s++;}
for(let seed=1;seed<=300;seed++){
 const random=new Random(seed*731);for(const m of [new BasketballModel(seed),new FootballModel(seed)]){
  m.time=random.next()*240;for(let i=0;i<30/STEP&&!m.over;i++){const input={jump:random.next()<.01,axis:random.pick([-1,0,1]),drag:random.next()<.03?(random.next()-.5)*1.6:0,touchJump:{held:random.next()<.85,pressure:random.next()},testInvincible:true};m.update(STEP,input);m.events.length=0;assert.ok([m.time,m.score,m.speed,m.distance].every(Number.isFinite));if(m instanceof BasketballModel){assert.ok(Number.isFinite(m.y)&&m.objects.length<140);}else assert.ok(Math.abs(m.x)<=F.courseWidth/2&&m.chunks.length<=8);results.totalSteps++;}results.randomizedRuns++;
 }
}
for(const pressure of [undefined,0,.1,.49,.5,.51,.8,1])for(const hold of [0,.008,.04,.08,.18,.3]){const b=new BasketballModel(1);for(let i=0;i<100;i++){b.update(STEP,{...emptyInput(),jump:i===0,touchJump:{held:i*STEP<hold,pressure}});assert.ok(b.y<=B.ground-B.radius+1e-8&&Number.isFinite(b.y));}results.physicsChecks++;}
const output={...results,maxBasketballObjects:maxB,maxFootballObjects:maxF,elapsedSeconds:(Date.now()-started)/1000};fs.writeFileSync('artifacts/audit-20261025/stress.json',JSON.stringify(output,null,2));console.log(output);
