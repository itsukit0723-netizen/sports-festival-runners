import { FootballModel } from '../src/games/football/model';
import { routeX, choiceRouteX } from '../src/games/football/chunks';
import { Random } from '../src/core/types';
import { STEP, FOOTBALL as F } from '../src/core/config';
// Reproducible comparison only: this is not a measured human average.
const allRuns: number[] = [];
const chooseRisk = process.argv.includes('--choices');
for (const decisionInterval of [.12,.2,.28]) {
 const runs:number[]=[];
 for(let seed=1;seed<=100;seed++) {
  const m=new FootballModel(seed), r=new Random(seed*317);let target=0,next=0;
  while(!m.over&&m.time<180){
   if(m.time>=next){const z=m.distance+m.speed*.18;const chunk=m.chunks.find(c=>c.start+F.chunkLength>z);target=(chunk ? chooseRisk && chunk.choice && chunk.id % 2 === 0 ? choiceRouteX(chunk,z) : routeX(chunk.rows,z) : 0)+(r.next()-.5)*.3; next=m.time+decisionInterval*(.8+r.next()*.4);}
   const dx=target-m.x;m.update(STEP,{jump:false,drag:0,axis:Math.abs(dx)<.07?0:Math.sign(dx)});m.events.length=0;
  }runs.push(m.time);allRuns.push(m.time);
 }runs.sort((a,b)=>a-b); console.log({decisionInterval,runs:100,mean: +(runs.reduce((a,b)=>a+b)/100).toFixed(1),median:+runs[50].toFixed(1),p10:+runs[10].toFixed(1),p90:+runs[90].toFixed(1),capped180:runs.filter(t=>t>=180).length});
}

console.log({ syntheticOnly: true, policy: chooseRisk ? 'alternate-choices' : 'normal-route', totalRuns: allRuns.length, meanSeconds: +(allRuns.reduce((a,b)=>a+b)/allRuns.length).toFixed(1) });
