import { test } from 'node:test';
import assert from 'node:assert/strict';
import { FOOTBALL as F, STEP } from '../src/core/config';
import { emptyInput } from '../src/core/types';
import { FootballModel } from '../src/games/football/model';
import { choiceRouteX, routeX, courseCollision } from '../src/games/football/chunks';

test('Frequent generated forks keep both paths and neighboring seams safe at maximum BOOST', () => {
  let left = 0, right = 0;
  for (let seed = 1; seed <= 12; seed++) {
    const m = new FootballModel(seed), seen = new Set<number>(); let previous = -Infinity;
    for (let i = 0; i < 120 / STEP; i++) {
      const row = m.nextChallengeRow(), dx = row.safeX - m.x;
      m.update(STEP, { ...emptyInput(), axis: Math.abs(dx) < .06 ? 0 : Math.sign(dx), testInvincible: true }); m.events.length = 0;
      for (const chunk of m.chunks) if (!seen.has(chunk.id)) {
        seen.add(chunk.id); if (!chunk.choice) continue;
        assert.ok(chunk.start - previous >= F.choiceSpacingChunks * F.chunkLength); previous = chunk.start;
        if (chunk.choice.x < chunk.rows[1].safeX) left++; else right++;
        const hazards = m.chunks.flatMap(c => c.objects).filter(o => o.type !== 'star' && o.type !== 'boost');
        let prior = choiceRouteX(chunk, chunk.choice.entryZ);
        for (let z = chunk.choice.entryZ + .1; z < chunk.rows.at(-1)!.z + 1; z += .1) {
          const risk = choiceRouteX(chunk, z);
          assert.ok(Math.abs(risk - prior) / (.1 / (F.maxForwardSpeed * F.boostMultiplier)) < F.steeringSensitivity * .86);
          for (const o of hazards) {
            assert.equal(courseCollision(o, risk, z, m.time), false, `seed ${seed}, optional route seam`);
            assert.equal(courseCollision(o, routeX(chunk.rows, z), z, m.time), false, `seed ${seed}, normal route seam`);
          }
          prior = risk;
        }
      }
    }
  }
  assert.ok(left > 20 && right > 20);
});

test('World visits remain infrequent while separate double-star forks recur between them', () => {
  let gates = 0, stars = 0;
  for (let seed = 1; seed <= 12; seed++) {
    const m = new FootballModel(seed), seen = new Set<number>(); let priorGate = -Infinity;
    while (m.time < 120) {
      const dx = m.nextChallengeRow().safeX - m.x;
      m.update(STEP, { ...emptyInput(), axis: Math.abs(dx) < .06 ? 0 : Math.sign(dx), testInvincible: true }); m.events.length = 0;
      for (const c of m.chunks) if (c.start <= m.distance && !seen.has(c.id)) {
        seen.add(c.id);
        if (!c.choice || m.time < 20) continue;
        if (c.choice.worlds) {
          assert.ok(m.time - priorGate > 9, 'a world must last long enough to experience'); priorGate = m.time; gates++;
        } else {
          stars++; assert.equal(c.objects.filter(o => o.type === 'star' && o.rewardMultiplier === 2).length, 3);
        }
      }
    }
  }
  const rate = (count: number) => count / 12 * .6;
  assert.ok(rate(gates) >= 3.5 && rate(gates) <= 5);
  assert.ok(rate(stars) >= 14 && rate(stars) <= 20);
});
