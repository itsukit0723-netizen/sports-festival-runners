import { test } from 'node:test';
import assert from 'node:assert/strict';
import { InputController } from '../src/core/input';

// Exercise the actual event controller, including devices returning the .5
// unsupported-pressure sentinel. No browser-specific pressure API is assumed.
class Surface extends EventTarget {
  clientWidth = 400;
  closest() { return null; }
  setPointerCapture() {}
}
class Button extends Surface {}
const windowEvents = new EventTarget();
Object.assign(globalThis, { window: windowEvents, Element: Surface, HTMLButtonElement: Button });
function pointer(surface: Surface, type: string, values: Record<string, unknown> = {}) {
  surface.dispatchEvent(Object.assign(new Event(type, { cancelable: true }), {
    pointerId: 1, button: 0, pointerType: 'touch', clientX: 100, pressure: .5, ...values,
  }));
}
test('Touch input: unsupported pressure falls back to held state, including a tap between frames', () => {
  const s = new Surface(), c = new InputController(s as unknown as HTMLElement, 'basketballRunner', () => {}, () => {});
  pointer(s, 'pointerdown');
  assert.deepEqual(c.read().touchJump, { held: true });
  pointer(s, 'pointerup', { pressure: 0 });
  assert.deepEqual(c.read().touchJump, { held: false });
  pointer(s, 'pointerdown'); pointer(s, 'pointerup', { pressure: 0 });
  const tap = c.read(); assert.equal(tap.jump, true); assert.equal(tap.touchJump?.held, false);
  c.dispose();
});
test('Touch input: peak pressure is retained; extra fingers cannot steal or trigger a jump', () => {
  const s = new Surface(), c = new InputController(s as unknown as HTMLElement, 'basketballRunner', () => {}, () => {});
  pointer(s, 'pointerdown', { pressure: .2 }); c.read();
  pointer(s, 'pointerdown', { pointerId: 2, pressure: 1 });
  pointer(s, 'pointermove', { pressure: .9 });
  pointer(s, 'pointermove', { pressure: .3 });
  pointer(s, 'pointerup', { pointerId: 2 });
  const held = c.read(); assert.equal(held.jump, false); assert.deepEqual(held.touchJump, { held: true, pressure: .9 });
  pointer(s, 'pointerup', { pressure: 0 });
  assert.deepEqual(c.read().touchJump, { held: false, pressure: .9 }); c.dispose();
});
test('Touch input: cancel/reset release the gesture; desktop jump and football dragging stay unchanged', () => {
  const s = new Surface(), c = new InputController(s as unknown as HTMLElement, 'basketballRunner', () => {}, () => {});
  pointer(s, 'pointerdown'); pointer(s, 'pointercancel');
  assert.equal(c.read().jump, false);
  c.reset(); assert.equal(c.read().touchJump, undefined);
  pointer(s, 'pointerdown', { pointerType: 'mouse' });
  assert.deepEqual(c.read(), { jump: true, touchJump: undefined, axis: 0, drag: 0 });
  pointer(s, 'pointerup'); c.dispose();
  const football = new InputController(s as unknown as HTMLElement, 'rollingFootball', () => {}, () => {});
  pointer(s, 'pointerdown'); pointer(s, 'pointermove', { clientX: 200 });
  const input = football.read(); assert.equal(input.jump, false); assert.equal(input.drag, .25); assert.equal(input.touchJump, undefined);
  football.dispose();
});

test('A transient focus loss releases football steering without requesting pause', () => {
  const s = new Surface(); let pauses = 0;
  const c = new InputController(s as unknown as HTMLElement, 'rollingFootball', () => pauses++, () => {});
  windowEvents.dispatchEvent(Object.assign(new Event('keydown', { cancelable: true }), { code: 'ArrowRight', repeat: false }));
  assert.equal(c.read().axis, 1);
  pointer(s, 'pointerdown'); pointer(s, 'pointermove', { clientX: 200 });
  windowEvents.dispatchEvent(new Event('blur'));
  assert.equal(c.read().axis, 0); assert.equal(c.read().drag, 0); assert.equal(pauses, 0);
  pointer(s, 'pointerdown', { pointerId: 2 }); pointer(s, 'pointermove', { pointerId: 2, clientX: 140 });
  assert.equal(c.read().drag, .1, 'a new drag works after focus returns'); c.dispose();
});
