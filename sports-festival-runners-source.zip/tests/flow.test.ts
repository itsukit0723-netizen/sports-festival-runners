import { test } from 'node:test';
import assert from 'node:assert/strict';
import { BasketballModel, isRunnerPickup } from '../src/games/basketball/model';
import { FULL_GUIDE, SHORT_GUIDE, SHORT_GUIDE_HOLD } from '../src/games/basketball/jump';
import { runnerRhythm } from '../src/games/basketball/obstacles';
import { FootballModel } from '../src/games/football/model';
import { planRows, planChoice, fillChunk, choiceRouteX, routeX, courseCollision, coursePickupClear, type Chunk, type CourseObject } from '../src/games/football/chunks';
import { BASKETBALL as B, FOOTBALL as F, STEP } from '../src/core/config';
import { emptyInput, Random } from '../src/core/types';

test('Basketball: LOW guides match the shorter touch arc and reward an early landing', () => {
  for (const hold of [undefined, SHORT_GUIDE_HOLD]) {
    const m = new BasketballModel(1), guide = hold === undefined ? FULL_GUIDE : SHORT_GUIDE;
    for (let i = 0; i < guide.points.length - 1; i++) {
      m.update(STEP, { ...emptyInput(), jump: i === 0, touchJump: hold === undefined ? undefined : { held: i * STEP < hold } });
      assert.ok(Math.abs(B.ground - B.radius - m.y - guide.points[i + 1].height) < 1e-8);
    }
  }
  function collect(short: boolean) {
    const m = new BasketballModel(1);
    while (!m.objects.some(o => !isRunnerPickup(o))) m.update(STEP, emptyInput());
    const obstacle = m.objects.find(o => !isRunnerPickup(o))!;
    const rewards = new Set(m.objects.filter(o => o.landingReward).map(o => o.id));
    assert.equal(obstacle.profile, 'normal'); assert.equal(rewards.size, 2);
    let takeoff = -1, collected = 0;
    while (m.time < 5 && !m.over) {
      const jump = takeoff < 0 && obstacle.x - B.playerX <= m.speed * SHORT_GUIDE.apex - obstacle.width / 2;
      if (jump) takeoff = m.time;
      const before = m.objects.filter(o => rewards.has(o.id)).map(o => ({ ...o }));
      m.update(STEP, { ...emptyInput(), jump, touchJump: short ? { held: takeoff < 0 || m.time - takeoff < SHORT_GUIDE_HOLD } : undefined });
      for (const o of before) if (!m.objects.some(n => n.id === o.id) && Math.abs(o.x - B.playerX) < 45) collected++;
    }
    assert.equal(m.over, false); return collected;
  }
  assert.ok(collect(true) > collect(false), 'short jump should collect more landing coins without making a full jump fatal');
});

test('Basketball: collection beats redistribute cadence without changing the average', () => {
  const beats = Array.from({ length: 6 }, (_, i) => runnerRhythm(i));
  assert.ok(Math.abs(beats.reduce((sum, b) => sum + b, 0) / 6 - 1) < 1e-12);
  assert.ok(beats[5] > beats[4] * 1.2);
});

test('Basketball: short jumps can clear both LOW shapes at every speed tier', () => {
  for (const type of ['cone', 'hurdle'] as const) for (const time of [0, 30, 60, 120]) for (const boosted of [false, true]) {
    let cleared = false;
    for (let lead = 10; lead < 400 && !cleared; lead += 2) {
      const m = new BasketballModel(1); m.time = time; if (boosted) m.boost = 2;
      const height = type === 'cone' ? B.obstacles.normal.coneHeight : B.obstacles.normal.hurdleHeight;
      const width = type === 'cone' ? B.obstacles.normal.coneWidth : B.obstacles.normal.hurdleWidth;
      const obstacle = { id: 999, type, x: B.playerX + lead, y: B.ground - height, width, height, passed: false, minClearance: 999 };
      m.objects = [obstacle];
      for (let i = 0; i < 120 && !m.over; i++) m.update(STEP, { ...emptyInput(), jump: i === 0, touchJump: { held: i * STEP < SHORT_GUIDE_HOLD } });
      cleared = !m.over && obstacle.passed;
    }
    assert.ok(cleared, `${type} ${time}s boost=${boosted}`);
  }
});

test('Football: both choice routes stay clear, enter and merge within maximum BOOST steering', () => {
  let choices = 0;
  for (let seed = 1; seed <= 200; seed++) {
    const entry = { z: -4, safeX: 0, gap: 1.9 };
    const rows = planRows(0, 'mediumSlalom', 1.9, entry, new Random(seed));
    const choice = planChoice(rows, entry); if (!choice) continue;
    choices++;
    const chunk: Chunk = { id: seed, start: 0, kind: 'mediumSlalom', safeX: rows.at(-1)!.safeX, gap: 1.9, rows, choice, objects: [] };
    let id = 0;
    fillChunk(chunk, (type, x, z, width, depth, height): CourseObject => ({ id: id++, type, x, baseX: x, z, width, depth, height, moving: false, amplitude: 0, frequency: 0, phase: 0, passed: false }));
    const hazards = chunk.objects.filter(o => !['star', 'boost'].includes(o.type));
    const doubles = chunk.objects.filter(o => o.rewardMultiplier === 2);
    assert.equal(doubles.length, 3);
    for (const star of doubles) assert.ok(coursePickupClear(star.x, star.z, chunk.objects));
    let previous = choiceRouteX(chunk, choice.entryZ);
    for (let z = choice.entryZ + .02; z < 27; z += .02) {
      const x = choiceRouteX(chunk, z);
      assert.ok(Math.abs(x - previous) / (.02 / (F.maxForwardSpeed * F.boostMultiplier)) < F.steeringSensitivity * .86);
      for (const o of hazards) {
        assert.equal(courseCollision(o, x, z, 0), false, `seed ${seed}: optional route`);
        assert.equal(courseCollision(o, routeX(rows, z), z, 0), false, `seed ${seed}: normal route`);
      }
      previous = x;
    }
  }
  assert.ok(choices > 10);
});

test('Football: optional stars double the reward; recovery retains obstacles and pools stay bounded', () => {
  function score(multiplier: number) {
    const m = new FootballModel(1), chunk = m.chunks[0];
    const star = chunk.objects.find(o => o.type === 'star')!;
    chunk.objects = [star]; star.rewardMultiplier = multiplier; m.x = star.x; m.distance = star.z - .05;
    m.update(STEP, emptyInput()); return m.score - m.speed * STEP * 1.8;
  }
  assert.equal(score(2), score(1) * 2);
  let choices = 0, recoveries = 0;
  for (let seed = 1; seed <= 12; seed++) {
    const m = new FootballModel(seed), seen = new Set<number>();
    for (let i = 0; i < 120 / STEP; i++) {
      const row = m.nextChallengeRow(), dx = row.safeX - m.x;
      m.update(STEP, { ...emptyInput(), axis: Math.abs(dx) < .06 ? 0 : Math.sign(dx) });
      assert.equal(m.over, false);
      for (const c of m.chunks) if (!seen.has(c.id)) {
        seen.add(c.id);
        if (c.choice) { choices++; assert.ok(!c.recovery); }
        if (c.recovery) {
          recoveries++;
          assert.equal(c.rows.length, 4);
          assert.ok(c.rows.at(-1)!.gap > 2.1);
          assert.ok(c.objects.filter(o => !['star', 'boost'].includes(o.type)).length >= 8);
        }
        for (const o of c.objects) assert.ok((o.rewardMultiplier ?? 1) === (o.type === 'star' && c.choice && Math.abs(o.x - c.choice.x) < .001 ? 2 : 1));
      }
      assert.ok(m.chunks.reduce((sum, c) => sum + c.objects.length, 0) < F.poolSize);
      m.events.length = 0;
    }
  }
  assert.ok(choices > 0); assert.ok(recoveries > 10);
});
