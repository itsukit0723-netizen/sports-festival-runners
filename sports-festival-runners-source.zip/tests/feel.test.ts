import { test } from 'node:test';
import assert from 'node:assert/strict';
import { GameFeel } from '../src/core/feel';
import type { GameEvent } from '../src/core/types';

test('Camera effects keep bounds at all frame rates, including stacked events', () => {
  const events: readonly GameEvent[] = Object.freeze(['boost', 'jump', 'land', 'near', 'smash'].map(kind => Object.freeze({ kind: kind as GameEvent['kind'] })));
  for (const fps of [30, 60, 120]) {
    const feel = new GameFeel();
    for (let i = 0; i < fps * 30; i++) {
      feel.update(1 / fps, i % fps === 0 ? events : [], 1);
      const b = feel.basketballCamera(1000), f = feel.footballCamera(100);
      assert.ok(b.zoom >= .965 && b.zoom <= 1.018); assert.ok(b.y >= 0 && b.y <= 8);
      assert.ok(f.fov >= 48 && f.fov <= 63.2); assert.ok(Math.abs(f.bank) <= .027);
      assert.ok(f.height >= 4.8 && f.height <= 5.1); assert.ok(f.distance <= 9.4);
    }
    for (let i = 0; i < fps * 3; i++) feel.update(1 / fps, [], 0);
    assert.ok(feel.impact < 1e-8 && feel.rush < 1e-6);
  }
});
test('Pausing freezes presentation and reduced motion removes camera kicks and banking', () => {
  const feel = new GameFeel(); feel.update(.016, [{ kind: 'near' }], 1);
  const before = JSON.stringify(feel); for (let i = 0; i < 120; i++) feel.update(0, [], 1);
  assert.equal(JSON.stringify(feel), before);
  feel.reducedMotion = true;
  assert.deepEqual(feel.basketballCamera(150), { zoom: 1, y: 0 });
  assert.equal(feel.footballCamera(1).bank, 0); assert.ok(feel.footballCamera(1).fov <= 52);
});
