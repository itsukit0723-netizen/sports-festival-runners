import { test } from 'node:test';
import assert from 'node:assert/strict';
import { GameFeel } from '../src/core/feel';
import type { GameEvent } from '../src/core/types';

test('Camera lens, horizon and height stay fixed during stacked events at every frame rate', () => {
  const events: readonly GameEvent[] = Object.freeze(['boost', 'jump', 'land', 'near', 'smash', 'portal'].map(kind => Object.freeze({ kind: kind as GameEvent['kind'] })));
  for (const fps of [30, 60, 120]) {
    const feel = new GameFeel();
    for (let i = 0; i < fps * 30; i++) {
      feel.update(1 / fps, i % fps === 0 ? events : [], 1);
      const b = feel.basketballCamera(1000), f = feel.footballCamera(100);
      assert.deepEqual(b, { zoom: 1, y: 0 });
      assert.deepEqual(f, { fov: 52, bank: 0, height: 5.1, distance: 9, lookAhead: -8 });
      assert.deepEqual(feel.footballCamera(-100), f);
    }
    for (let i = 0; i < fps * 3; i++) feel.update(1 / fps, [], 0);
    assert.ok(feel.impact < 1e-8 && feel.rush < 1e-6);
  }
});
test('Pausing freezes feedback and reduced motion preserves the same stable camera', () => {
  const feel = new GameFeel(); feel.update(.016, [{ kind: 'near' }], 1);
  const before = JSON.stringify(feel); for (let i = 0; i < 120; i++) feel.update(0, [], 1);
  assert.equal(JSON.stringify(feel), before);
  feel.reducedMotion = true;
  assert.deepEqual(feel.basketballCamera(150), { zoom: 1, y: 0 });
  assert.equal(feel.footballCamera(1).bank, 0); assert.ok(feel.footballCamera(1).fov <= 52);
});
