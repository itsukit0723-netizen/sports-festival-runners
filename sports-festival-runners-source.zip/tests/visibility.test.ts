import test from 'node:test';import assert from 'node:assert/strict';import * as THREE from 'three';
import {frameFootball,routeSignOpacity,pickupVisible} from '../src/games/football/view';
import {FOOTBALL as F} from '../src/core/config';
import {bindPlayViewport} from '../src/ui/play-viewport';
test('Centered framing shows the ball and both real sidelines on small, tall and landscape screens',()=>{
 for(const [w,h] of [[280,650],[320,568],[360,900],[390,740],[390,844],[430,932],[768,1024],[844,390],[1280,720]]){
  const c=new THREE.PerspectiveCamera();frameFootball(c,w,h);const matrix=c.matrixWorld.clone(),projection=c.projectionMatrix.clone();
  for(const x of [-3.9,0,3.9]){
   const p=new THREE.Vector3(x,F.ballRadius+.03,0).project(c);
   assert.ok(Math.abs(p.x)<.9);assert.ok(Math.abs((1-p.y)/2-(h>w?.82:.77))<1e-8);
  }
  for(const x of [-F.courseWidth/2,F.courseWidth/2])assert.ok(Math.abs(new THREE.Vector3(x,0,0).project(c).x)<.9);
  frameFootball(c,w,h);assert.ok(c.matrixWorld.equals(matrix));assert.ok(c.projectionMatrix.equals(projection));
 }
});
test('Near route labels fade out before the player; missed pickups disappear only after the collection window',()=>{
 assert.equal(routeSignOpacity(30),1);assert.equal(routeSignOpacity(16),1);assert.equal(routeSignOpacity(12),.5);assert.equal(routeSignOpacity(8),0);assert.equal(routeSignOpacity(-1),0);
 assert.ok(pickupVisible(-1.2));assert.ok(pickupVisible(-.85));assert.equal(pickupVisible(-1.3),false);
});
test('Visible viewport and element resizing refresh the canvas, then remove every listener on exit',()=>{
 const previousWindow=Object.getOwnPropertyDescriptor(globalThis,'window'),previousObserver=Object.getOwnPropertyDescriptor(globalThis,'ResizeObserver');
 const viewport=Object.assign(new EventTarget(),{height:650}),win=Object.assign(new EventTarget(),{visualViewport:viewport,innerHeight:740});let observerCallback=()=>{},disconnected=false,updates=0;
 class Observer{constructor(callback:()=>void){observerCallback=callback;}observe(){}disconnect(){disconnected=true;}}
 Object.assign(globalThis,{window:win,ResizeObserver:Observer});const values=new Map<string,string>(),page={style:{height:'',setProperty:(k:string,v:string)=>values.set(k,v),removeProperty:(k:string)=>values.delete(k)},setAttribute(){},removeAttribute(){}};
 try{
  const dispose=bindPlayViewport(page as unknown as HTMLElement,{} as HTMLCanvasElement,()=>updates++);
  assert.equal(values.get('--play-height'),'650px');viewport.height=740;viewport.dispatchEvent(new Event('resize'));assert.equal(values.get('--play-height'),'740px');
  viewport.height=844;win.dispatchEvent(new Event('resize'));assert.equal(values.get('--play-height'),'844px');observerCallback();const before=updates;
  assert.equal(page.style.height,'844px');
  dispose();viewport.dispatchEvent(new Event('resize'));win.dispatchEvent(new Event('resize'));assert.equal(updates,before);assert.ok(disconnected);assert.equal(values.size,0);
 }finally{if(previousWindow)Object.defineProperty(globalThis,'window',previousWindow);else Reflect.deleteProperty(globalThis,'window');if(previousObserver)Object.defineProperty(globalThis,'ResizeObserver',previousObserver);else Reflect.deleteProperty(globalThis,'ResizeObserver');}
});
test('An embedded host header keeps its own space while the game uses the rest of the visible height',()=>{
 const previousWindow=Object.getOwnPropertyDescriptor(globalThis,'window'),previousObserver=Object.getOwnPropertyDescriptor(globalThis,'ResizeObserver');
 const viewport=Object.assign(new EventTarget(),{height:740}),win=Object.assign(new EventTarget(),{visualViewport:viewport,innerHeight:740});let callback=()=>{},headerHeight=56;
 class Observer{constructor(c:()=>void){callback=c;}observe(){}disconnect(){}}
 const values=new Map(),page={parentElement:{querySelector:()=>({getBoundingClientRect:()=>({height:headerHeight})})},style:{height:'',setProperty:(k:string,v:string)=>values.set(k,v),removeProperty:(k:string)=>values.delete(k)},setAttribute(){},removeAttribute(){}};
 Object.assign(globalThis,{window:win,ResizeObserver:Observer});
 try{const dispose=bindPlayViewport(page as unknown as HTMLElement,{} as HTMLCanvasElement,()=>{});assert.equal(page.style.height,'684px');assert.equal(values.get('--play-inset'),'56px');headerHeight=72;callback();assert.equal(page.style.height,'668px');viewport.height=844;viewport.dispatchEvent(new Event('resize'));assert.equal(page.style.height,'772px');dispose();assert.equal(page.style.height,'');}
 finally{if(previousWindow)Object.defineProperty(globalThis,'window',previousWindow);else Reflect.deleteProperty(globalThis,'window');if(previousObserver)Object.defineProperty(globalThis,'ResizeObserver',previousObserver);else Reflect.deleteProperty(globalThis,'ResizeObserver');}
});
