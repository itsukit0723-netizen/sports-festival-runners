import test from 'node:test';import assert from 'node:assert/strict';
import {routeSignOpacity,pickupVisible} from '../src/games/football/view';
import {bindPlayViewport} from '../src/ui/play-viewport';
test('Near route labels fade out before the player; missed pickups disappear only after the collection window',()=>{
 assert.equal(routeSignOpacity(30),1);assert.equal(routeSignOpacity(16),1);assert.equal(routeSignOpacity(12),.5);assert.equal(routeSignOpacity(8),0);assert.equal(routeSignOpacity(-1),0);
 assert.ok(pickupVisible(-1.2));assert.ok(pickupVisible(-.85));assert.equal(pickupVisible(-1.3),false);
});
test('Visible viewport and element resizing refresh the canvas, then remove every listener on exit',()=>{
 const previousWindow=Object.getOwnPropertyDescriptor(globalThis,'window'),previousObserver=Object.getOwnPropertyDescriptor(globalThis,'ResizeObserver');
 const viewport=Object.assign(new EventTarget(),{height:650}),win=Object.assign(new EventTarget(),{visualViewport:viewport,innerHeight:740});let observerCallback=()=>{},disconnected=false,updates=0;
 class Observer{constructor(callback:()=>void){observerCallback=callback;}observe(){}disconnect(){disconnected=true;}}
 Object.assign(globalThis,{window:win,ResizeObserver:Observer});const values=new Map<string,string>(),page={style:{height:'',setProperty:(k:string,v:string)=>values.set(k,v),removeProperty:(k:string)=>values.delete(k)},setAttribute(){},removeAttribute(){}};
 try{
  const dispose=bindPlayViewport(page as unknown as HTMLElement,{} as HTMLCanvasElement,()=>updates++);
  assert.equal(values.get('--play-height'),'650px');viewport.height=740;viewport.dispatchEvent(new Event('resize'));assert.equal(values.get('--play-height'),'740px');
  viewport.height=844;win.dispatchEvent(new Event('resize'));assert.equal(values.get('--play-height'),'844px');observerCallback();const before=updates;
  assert.equal(page.style.height,'844px');
  dispose();viewport.dispatchEvent(new Event('resize'));win.dispatchEvent(new Event('resize'));assert.equal(updates,before);assert.ok(disconnected);assert.equal(values.size,0);
 }finally{if(previousWindow)Object.defineProperty(globalThis,'window',previousWindow);else Reflect.deleteProperty(globalThis,'window');if(previousObserver)Object.defineProperty(globalThis,'ResizeObserver',previousObserver);else Reflect.deleteProperty(globalThis,'ResizeObserver');}
});
test('An embedded host header keeps its own space while the game uses the rest of the visible height',()=>{
 const previousWindow=Object.getOwnPropertyDescriptor(globalThis,'window'),previousObserver=Object.getOwnPropertyDescriptor(globalThis,'ResizeObserver');
 const viewport=Object.assign(new EventTarget(),{height:740}),win=Object.assign(new EventTarget(),{visualViewport:viewport,innerHeight:740});let callback=()=>{},headerHeight=56;
 class Observer{constructor(c:()=>void){callback=c;}observe(){}disconnect(){}}
 const values=new Map(),page={parentElement:{querySelector:()=>({getBoundingClientRect:()=>({height:headerHeight})})},style:{height:'',setProperty:(k:string,v:string)=>values.set(k,v),removeProperty:(k:string)=>values.delete(k)},setAttribute(){},removeAttribute(){}};
 Object.assign(globalThis,{window:win,ResizeObserver:Observer});
 try{const dispose=bindPlayViewport(page as unknown as HTMLElement,{} as HTMLCanvasElement,()=>{});assert.equal(page.style.height,'684px');assert.equal(values.get('--play-inset'),'56px');headerHeight=72;callback();assert.equal(page.style.height,'668px');viewport.height=844;viewport.dispatchEvent(new Event('resize'));assert.equal(page.style.height,'772px');dispose();assert.equal(page.style.height,'');}
 finally{if(previousWindow)Object.defineProperty(globalThis,'window',previousWindow);else Reflect.deleteProperty(globalThis,'window');if(previousObserver)Object.defineProperty(globalThis,'ResizeObserver',previousObserver);else Reflect.deleteProperty(globalThis,'ResizeObserver');}
});
