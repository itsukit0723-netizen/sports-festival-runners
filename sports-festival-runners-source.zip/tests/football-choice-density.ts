import { FootballModel } from '../src/games/football/model';
import { STEP, FOOTBALL as F } from '../src/core/config';
import { emptyInput } from '../src/core/types';
let choices=0,worlds=0,stars=0,chunks=0,hazards=0;
for(let seed=1;seed<=100;seed++){
 const m=new FootballModel(seed),seen=new Set<number>();
 while(m.time<120){
  const row=m.nextChallengeRow(),dx=row.safeX-m.x;
  m.update(STEP,{...emptyInput(),axis:Math.abs(dx)<.06?0:Math.sign(dx),testInvincible:true});m.events.length=0;
  for(const c of m.chunks)if(c.start<=m.distance&&!seen.has(c.id)){seen.add(c.id);if(m.time>=20){chunks++;if(c.choice){choices++;if(c.choice.worlds)worlds++;else stars++;}hazards+=c.objects.filter(o=>!['star','boost'].includes(o.type)).length;}}
 }
}
console.log(JSON.stringify({syntheticOnly:true,seeds:100,windowSeconds:100,worldGatesPerMinute:+(worlds/100*.6).toFixed(2),starForksPerMinute:+(stars/100*.6).toFixed(2),choicesPerMinute:+(choices/100*.6).toFixed(2),hazardsPerMinute:+(hazards/100*.6).toFixed(2),choiceChunkPercent:+(choices/chunks*100).toFixed(1)}));
