// Synthetic input profiles, NOT a substitute for first-time human playtesting.
// Fixed reaction / timing noise lets balance changes be compared reproducibly.
import { BasketballModel } from '../src/games/basketball/model';
import { FootballModel } from '../src/games/football/model';
import { Random, emptyInput } from '../src/core/types';
import { BASKETBALL as B, FOOTBALL as F, STEP } from '../src/core/config';
const limit = 120;
const basketball: number[] = [], football: number[] = [];
for (let seed = 1; seed <= 100; seed++) {
  const random = new Random(seed * 317);
  const b = new BasketballModel(seed); let id = -1, lead = .24;
  while (!b.over && b.time < limit) {
    const o = b.objects.find(o => ['cone', 'hurdle', 'dummy', 'bench', 'mat'].includes(o.type) && o.x + o.width > B.playerX - B.radius);
    if (o && o.id !== id) { id = o.id; lead = .23 + (random.next() - .5) * .14; }
    const timeToEdge = o ? (o.x - B.playerX) / b.speed : 100;
    b.update(STEP, { ...emptyInput(), jump: !!o && timeToEdge <= lead && timeToEdge > .05 && b.y >= B.ground - B.radius - .5 });
    b.events.length = 0;
  }
  basketball.push(b.time);
  const f = new FootballModel(seed); let target = 0, rowId = -1, responseIn = 0;
  while (!f.over && f.time < limit) {
    const row = f.nextChallengeRow();
    if (row.z !== rowId && row.z - f.distance < f.speed * 1.1) {
      rowId = row.z; responseIn = .28 + random.next() * .32;
    }
    if (rowId === row.z) {
      responseIn -= STEP;
      if (responseIn <= 0) target = row.safeX;
    }
    const dx = target - f.x;
    f.update(STEP, { jump: false, axis: Math.abs(dx) < .07 ? 0 : Math.sign(dx), drag: 0 });
    f.events.length = 0;
  }
  football.push(f.time);
}
function summarize(name: string, runs: number[]) {
  runs.sort((a, b) => a - b);
  console.log(name, { runs: runs.length, meanSeconds: +(runs.reduce((s, n) => s + n, 0) / runs.length).toFixed(1), medianSeconds: +runs[50].toFixed(1), p10: +runs[10].toFixed(1), p90: +runs[90].toFixed(1), survived120s: runs.filter(n => n >= limit).length });
}
console.log('Synthetic profiles only. These values are not measured human averages.');
summarize('BASKETBALL', basketball); summarize('FOOTBALL', football);
