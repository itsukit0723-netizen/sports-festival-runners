import {test} from 'node:test';
import assert from 'node:assert/strict';
import {FootballModel} from '../src/games/football/model';
import {planRows,fillChunk,routeX,motionOffset,motionDepthOffset,courseCollision,coursePickupClear,type Chunk,type CourseObject} from '../src/games/football/chunks';
import {Random,emptyInput} from '../src/core/types';
import {STEP} from '../src/core/config';
test('Small-ball scramble has independent irregular 2D motion and leaves a navigable path',()=>{
 for(let seed=1;seed<=8;seed++){
  const rows=planRows(0,'hardScramble',1.7,{z:-4,safeX:0,gap:2.4},new Random(seed));
  const c:Chunk={id:0,start:0,kind:'hardScramble',rows,safeX:rows[2].safeX,gap:1.7,objects:[],variant:seed};let id=0;
  fillChunk(c,(type,x,z,width,depth,height):CourseObject=>({id:id++,type,x,baseX:x,z,width,depth,height,moving:false,amplitude:0,frequency:0,phase:0,passed:false}));
  const balls=c.objects.filter(o=>o.type==='roller');assert.ok(balls.length>=12);assert.ok(balls.every(o=>o.chaotic&&o.width<1&&o.depthAmplitude!>0));
  assert.ok(new Set(balls.map(o=>`${o.frequency}:${o.phase}`)).size>=12);
  for(const star of c.objects.filter(o=>o.type==='star'))assert.ok(coursePickupClear(star.x,star.z,c.objects));
  for(let t=0;t<12;t+=.13)for(const o of balls){
   o.x=o.baseX+motionOffset(o,t);o.z=o.baseZ!+motionDepthOffset(o,t);
   assert.ok(Math.abs(o.x)+o.width/2<=4.4);assert.ok(Math.abs(o.z-o.baseZ!)<=o.depthAmplitude!+1e-6);
   for(let z=0;z<=26;z+=.25)assert.equal(courseCollision(o,routeX(rows,z),z,t),false);
  }
 }
});
test('Generated games repeatedly contain scramble sections and retain extended edge sections until passed',()=>{
 for(const seed of [1,2,99]){
  const m=new FootballModel(seed),swarm=new Set<number>();let extended=0;
  while(m.time<90){
   for(const c of m.chunks){if(c.kind==='hardScramble'&&c.start<=m.distance)swarm.add(c.id);if(c.length&&c.rows[1].z>m.distance&&c.start+26<m.distance)extended++;}
   const dx=m.nextChallengeRow().safeX-m.x;m.update(STEP,{...emptyInput(),axis:Math.abs(dx)<.06?0:Math.sign(dx),testInvincible:true});m.events.length=0;
  }
  assert.ok(swarm.size>=2);assert.ok(extended>20);
 }
});
