import {test} from 'node:test';
import assert from 'node:assert/strict';
import {FootballModel} from '../src/games/football/model';
import {planRows,fillChunk,routeX,scrambleChoiceX,motionOffset,motionDepthOffset,courseCollision,coursePickupClear,type Chunk,type CourseObject} from '../src/games/football/chunks';
import {Random,emptyInput} from '../src/core/types';
import {STEP,FOOTBALL as F} from '../src/core/config';
test('Small-ball scramble has independent irregular 2D motion and leaves a navigable path',()=>{
 for(let seed=1;seed<=8;seed++){
  const rows=planRows(0,'hardScramble',1.7,{z:-4,safeX:0,gap:2.4},new Random(seed));
  const c:Chunk={id:0,start:0,kind:'hardScramble',rows,safeX:rows[2].safeX,gap:1.7,objects:[],variant:seed};let id=0;
  fillChunk(c,(type,x,z,width,depth,height):CourseObject=>({id:id++,type,x,baseX:x,z,width,depth,height,moving:false,amplitude:0,frequency:0,phase:0,passed:false}));
  const balls=c.objects.filter(o=>o.type==='roller'),chaotic=balls.filter(o=>o.chaotic);assert.ok(chaotic.length>=9);assert.ok(chaotic.every(o=>o.width<1&&o.depthAmplitude!>0));
  assert.ok(new Set(chaotic.map(o=>`${o.frequency}:${o.phase}`)).size>=9);
  assert.ok(c.scrambleChoice);assert.equal(c.objects.filter(o=>o.type==='star').length,0);
  assert.equal(balls.filter(o=>!o.chaotic).length,1);
  for(const x of [rows[1].safeX,c.scrambleChoice.x]){
   const capacity=(rows[1].z-rows[0].z-2*1.25)/(44*1.35)*11.8;
   assert.ok(Math.abs(x-rows[0].safeX)<=capacity*.86);
   assert.ok(Math.abs(rows[2].safeX-x)<=capacity*.86);
  }
  for(const star of c.objects.filter(o=>o.type==='star'))assert.ok(coursePickupClear(star.x,star.z,c.objects));
  for(let t=0;t<12;t+=.13)for(const o of balls){
   o.x=o.baseX+motionOffset(o,t);if(o.chaotic)o.z=o.baseZ!+motionDepthOffset(o,t);
   assert.ok(Math.abs(o.x)+o.width/2<=4.4);if(o.chaotic)assert.ok(Math.abs(o.z-o.baseZ!)<=o.depthAmplitude!+1e-6);
   for(let z=0;z<=34;z+=.25)for(const x of [routeX(rows,z),scrambleChoiceX(c,z)])assert.equal(courseCollision(o,x,z,t),false,`seed ${seed} ${o.id} at ${z}/${t}`);
  }
 }
});
test('Generated games repeatedly contain scramble sections and retain extended edge sections until passed',()=>{
 for(const seed of [1,2,99]){
  const m=new FootballModel(seed),swarm=new Set<number>();let extended=0;
  while(m.time<90){
   for(const c of m.chunks){if(c.kind==='hardScramble'&&c.start<=m.distance)swarm.add(c.id);if(c.length&&c.rows[1].z>m.distance&&c.start+26<m.distance)extended++;}
   const dx=m.nextChallengeRow().safeX-m.x;m.update(STEP,{...emptyInput(),axis:Math.abs(dx)<.06?0:Math.sign(dx),testInvincible:true});m.events.length=0;
  }
  assert.ok(swarm.size>=2);assert.ok(extended>20);
 }
});

test('Scramble routes are protected against the entire independent lateral and depth sweep, not only sampled phases',()=>{
 for(let seed=1;seed<=12;seed++){
  const rows=planRows(0,'hardScramble',1.7,{z:-4,safeX:0,gap:2.4},new Random(seed),false,undefined,44);
  const c:Chunk={id:0,start:0,length:34,kind:'hardScramble',rows,safeX:rows[2].safeX,gap:1.7,objects:[],variant:seed};let id=0;
  fillChunk(c,(type,x,z,width,depth,height):CourseObject=>({id:id++,type,x,baseX:x,z,width,depth,height,moving:false,amplitude:0,frequency:0,phase:0,passed:false}));
  for(const o of c.objects){
   const radius=o.width/2+F.ballRadius*.78,baseZ=o.baseZ??o.z,lo=baseZ-(o.depthAmplitude??0)-radius,hi=baseZ+(o.depthAmplitude??0)+radius;
   const candidates=[lo,hi,...rows.flatMap(r=>[r.z-3.15,r.z-1.25,r.z,r.z+1.25,r.z+3.15])].filter(z=>z>=lo&&z<=hi);
   for(const route of [(z:number)=>routeX(rows,z),(z:number)=>scrambleChoiceX(c,z)]){
    const xs=candidates.map(route),min=Math.min(...xs),max=Math.max(...xs);
    const left=o.baseX-o.amplitude,right=o.baseX+o.amplitude;
    const distance=Math.max(left-max,min-right,0);
    assert.ok(distance>radius,`seed ${seed}, ball ${o.id}: swept envelope blocks a route`);
   }
  }
 }
});
