import { test } from 'node:test';
import assert from 'node:assert/strict';
import { bindPagePause } from '../src/core/page-pause';

test('Visible focus changes never auto-pause; hidden pages and page exits still pause', () => {
  const doc = Object.assign(new EventTarget(), { hidden: false }), page = new EventTarget(); let pauses = 0;
  const dispose = bindPagePause(doc, page, () => pauses++);
  for (let i = 0; i < 5; i++) { page.dispatchEvent(new Event('blur')); page.dispatchEvent(new Event('focus')); doc.dispatchEvent(new Event('visibilitychange')); }
  assert.equal(pauses, 0);
  doc.hidden = true; doc.dispatchEvent(new Event('visibilitychange')); assert.equal(pauses, 1);
  doc.hidden = false; doc.dispatchEvent(new Event('visibilitychange')); assert.equal(pauses, 1, 'returning must not toggle a manual pause');
  page.dispatchEvent(new Event('pagehide')); assert.equal(pauses, 2);
  dispose(); doc.hidden = true; doc.dispatchEvent(new Event('visibilitychange')); page.dispatchEvent(new Event('pagehide')); assert.equal(pauses, 2);
});
