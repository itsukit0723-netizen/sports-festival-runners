import test from 'node:test';import assert from 'node:assert/strict';import * as THREE from 'three';
import {GoldenStadium} from '../src/games/football/golden-stadium';
test('Golden stadium builds compatible batches, leaves the playing corridor empty and disposes resources',()=>{
 const before=Object.getOwnPropertyDescriptor(globalThis,'document');
 Object.assign(globalThis,{document:{createElement:()=>({width:0,height:0,getContext:()=>new Proxy({},{get:()=>()=>{},set:()=>true})})}});
 try {
  const stadium=new GoldenStadium();stadium.update(123,14,false);stadium.group.updateMatrixWorld(true);
  const p=new THREE.Vector3();let triangles=0,meshes=0;const geos=new Set<THREE.BufferGeometry>(),materials=new Set<THREE.Material>();
  stadium.group.traverse(o=>{if(!(o instanceof THREE.Mesh))return;meshes++;geos.add(o.geometry);const list=Array.isArray(o.material)?o.material:[o.material];list.forEach(m=>materials.add(m));
   const pos=o.geometry.getAttribute('position');triangles+=(o.geometry.index?.count??pos.count)/3;
   for(let i=0;i<pos.count;i++){p.fromBufferAttribute(pos,i).applyMatrix4(o.matrixWorld);assert.ok(Math.abs(p.x)>4.4||p.y>4,'stage architecture must not appear as an uncollidable road obstacle');}
  });
  assert.ok(meshes<80);assert.ok(triangles<350000,`stage has ${triangles} triangles`);
  let disposed=0;geos.forEach(g=>g.addEventListener('dispose',()=>disposed++));materials.forEach(m=>m.addEventListener('dispose',()=>disposed++));
  const texture=stadium.surface;texture.addEventListener('dispose',()=>disposed++);stadium.update(140,25,true);
  assert.equal(stadium.group.children.find(o=>o instanceof THREE.Points)?.visible,false);
  stadium.dispose();assert.ok(disposed>=geos.size+materials.size+1);
 } finally {if(before)Object.defineProperty(globalThis,'document',before);else Reflect.deleteProperty(globalThis,'document');}
});
