import {test} from 'node:test';
import assert from 'node:assert/strict';
import {FootballModel} from '../src/games/football/model';
import {motionOffset} from '../src/games/football/chunks';
import {defenderPose} from '../src/games/football/defender-pose';
import {STEP} from '../src/core/config';
import {emptyInput} from '../src/core/types';

test('Defender steps toward the player without teleporting or leaving the protected movement envelope',()=>{
 const m=new FootballModel(1),guard=m.chunks[0].objects[0];
 Object.assign(guard,{type:'defender',x:0,baseX:0,z:m.distance+80,width:1.6,depth:1.1,height:1.9,moving:true,amplitude:1.2,frequency:4.8,phase:0,velocityX:0});
 assert.ok(motionOffset(guard,1,2.2)>motionOffset(guard,1,-2.2));
 let furthest=0;
 for(const target of [2.2,-2.2]){
  m.x=target;
  for(let i=0;i<120;i++){
   const before=guard.x;m.update(STEP,{...emptyInput(),testInvincible:true});m.events.length=0;
   assert.ok(Math.abs(guard.x-before)<=2.6*STEP+1e-9);assert.ok(Math.abs(guard.x)<=guard.amplitude+1e-9);
  }
  if(target>0){assert.ok(guard.x>.4);furthest=guard.x;}else assert.ok(guard.x<furthest-.4);
 }
});

test('Defensive shuffle stops the feet when planted and uses restrained balance instead of idle flailing',()=>{
 for(let time=0;time<10;time+=.07){
  const planted=defenderPose(time,0,4);assert.equal(Math.abs(planted.step),0);assert.equal(Math.abs(planted.lean),0);assert.equal(planted.effort,0);
  const right=defenderPose(time,2.6,4),left=defenderPose(time,-2.6,-4);
  assert.ok(right.lean<0&&left.lean>0);assert.ok(Math.abs(right.lean)<=.042);
  assert.ok(Math.abs(right.headYaw)<=.22&&Math.abs(right.bodyYaw)<=.12);
  assert.ok(Math.abs(right.step)<=1);
 }
});
