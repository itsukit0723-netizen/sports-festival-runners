import { test } from 'node:test';
import assert from 'node:assert/strict';
import { BasketballModel } from '../src/games/basketball/model';
import { FootballModel } from '../src/games/football/model';
import { emptyInput } from '../src/core/types';
import { STEP, BASKETBALL as B, FOOTBALL as F } from '../src/core/config';

test('Basketball: landing reward feedback reports actual points; ordinary coins stay ordinary', () => {
  for (const reward of [false, true]) for (const fever of [false, true]) {
    const m = new BasketballModel(1); if (fever) m.fever = 2;
    const coin = () => ({ id: 999, type: 'coin' as const, x: B.playerX, y: m.y, width: 22, height: 22, minClearance: 999, passed: false, landingReward: reward });
    m.objects = [coin()]; m.update(STEP, emptyInput());
    m.combo = 7; m.score = 0; m.events = []; m.objects = [coin()];
    m.update(STEP, emptyInput());
    const event = m.events.find(e => e.kind === 'coin')!;
    assert.equal(event.reward, reward ? 'landing' : undefined);
    assert.equal(event.points, B.coinScore * 2 * (fever ? 2 : 1));
    assert.ok(Math.abs(m.score - m.speed * STEP / 16 * (fever ? 2 : 1) - event.points!) < 1e-9);
  }
});
test('Football: double-star feedback agrees with awarded points and never fires for normal stars', () => {
  for (const multiplier of [1, 2]) {
    const m = new FootballModel(1), c = m.chunks[0], star = c.objects.find(o => o.type === 'star')!;
    m.chunks = [c]; c.objects = [star];
    star.rewardMultiplier = multiplier; m.x = star.x; m.distance = star.z;
    m.update(STEP, emptyInput()); m.combo = 7; m.score = 0; m.events = []; star.passed = false; m.distance = star.z;
    m.update(STEP, emptyInput());
    const event = m.events.find(e => e.kind === 'coin')!;
    assert.equal(event.reward, multiplier === 2 ? 'double' : undefined);
    assert.equal(event.points, F.tokenScore * 2 * multiplier);
    assert.ok(Math.abs(m.score - m.speed * STEP * 1.8 - event.points!) < 1e-9);
  }
});
