import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { Matrix4, Quaternion, Vector3 } from 'three';
const file = readFileSync(new URL('../src/assets/sakura-garden.glb', import.meta.url));
const jsonLength = file.readUInt32LE(12), doc = JSON.parse(file.subarray(20, 20 + jsonLength).toString());
const binaryStart = 20 + jsonLength + 8;

test('Blender Sakura is a self-contained game asset with all six reusable models and a mobile geometry budget', () => {
  assert.equal(file.toString('ascii', 0, 4), 'glTF'); assert.equal(file.readUInt32LE(4), 2);
  const names = doc.scenes[0].nodes.map((i: number) => doc.nodes[i].name);
  for (const name of ['Sakura_Tree_A','Sakura_Tree_B','Sakura_Lantern','Sakura_Torii','Sakura_Shrine','Sakura_GardenBed']) assert.ok(names.includes(name));
  assert.ok(file.length < 2_000_000); assert.ok(doc.images.length >= 2);
  assert.ok(doc.images.every((i: {bufferView?: number;uri?: string}) => i.bufferView !== undefined && !i.uri));
  let triangles = 0;
  for (const mesh of doc.meshes) for (const p of mesh.primitives) triangles += doc.accessors[p.indices ?? p.attributes.POSITION].count / 3;
  assert.ok(triangles > 5000 && triangles < 25000);
});

test('Blender export preserves blossom alpha clipping, embedded textures and warm lantern emission', () => {
  const flower = doc.materials.find((m: {name:string}) => m.name.includes('atlas'));
  assert.equal(flower.alphaMode,'MASK'); assert.ok(flower.alphaCutoff > .2 && flower.alphaCutoff < .6);
  assert.ok(flower.pbrMetallicRoughness.baseColorTexture);
  const lantern = doc.materials.find((m: {name:string}) => m.name.includes('washi'));
  assert.ok(lantern.emissiveFactor.some((v:number) => v > .2));
});

test('Blender torii and shrine terraces leave the playable road clear', () => {
  const root = doc.scenes[0].nodes.find((i:number) => doc.nodes[i].name === 'Sakura_Torii'); let vertices = 0;
  function walk(index:number, parent:Matrix4) {
    const n=doc.nodes[index];const local=n.matrix ? new Matrix4().fromArray(n.matrix) : new Matrix4().compose(new Vector3(...(n.translation ?? [0,0,0])),new Quaternion(...(n.rotation ?? [0,0,0,1])),new Vector3(...(n.scale ?? [1,1,1])));
    const world=parent.clone().multiply(local);
    if(n.mesh !== undefined) for(const p of doc.meshes[n.mesh].primitives){
      const a=doc.accessors[p.attributes.POSITION],view=doc.bufferViews[a.bufferView],offset=binaryStart+(view.byteOffset??0)+(a.byteOffset??0),stride=view.byteStride??12;
      assert.equal(a.componentType,5126);
      for(let i=0;i<a.count;i++){const o=offset+i*stride;const v=new Vector3(file.readFloatLE(o),file.readFloatLE(o+4),file.readFloatLE(o+8)).applyMatrix4(world);assert.ok(Number.isFinite(v.y));if(v.y<3.5)assert.ok(Math.abs(v.x)>4.4,'roadside footings must remain outside the road');vertices++;}
    }
    for(const child of n.children??[])walk(child,world);
  }
  walk(root,new Matrix4());
  const shrine = doc.scenes[0].nodes.find((i:number) => doc.nodes[i].name === 'Sakura_Shrine');
  for(const [x,y,scale,angle] of [[-14.3,3.05,1.6,.18],[15.1,3.24,1.7,-.2]]) walk(shrine,new Matrix4().compose(new Vector3(x,y,-52),new Quaternion().setFromAxisAngle(new Vector3(0,1,0),angle),new Vector3(scale,scale,scale)));
  assert.ok(vertices>100);
});
