import test from 'node:test';import assert from 'node:assert/strict';
import {BasketballModel} from '../src/games/basketball/model';
import {GiantPower,GIANT} from '../src/games/basketball/giant';
import {BASKETBALL as B,STEP} from '../src/core/config';
import {emptyInput,Random} from '../src/core/types';import {DifficultyDirector} from '../src/core/director';
import type {RunnerObject} from '../src/games/basketball/model';
import {skilledBasketballInput} from './helpers/basketball-player';
function quiet(golden=true){const m=new BasketballModel(17);m.setGolden(golden);Object.assign(m,{obstacleIn:1000,coinIn:1000,itemIn:1000,nextBonus:100000});return m;}
function tick(m:BasketballModel,seconds:number){for(let i=0;i<Math.ceil(seconds/STEP);i++)m.update(STEP,emptyInput());}
function hazard(id:number,x:number,type:RunnerObject['type']='dummy'):RunnerObject{return{id,type,x,y:B.ground-110,width:40,height:110,passed:false,minClearance:999};}
function grown(){const m=quiet();m.fever=3;tick(m,.4);assert.equal(m.giantScale,4);return m;}

test('Only Golden fever grows the ball; collecting the real item starts the power once',()=>{
 const normal=quiet(false);normal.fever=3;tick(normal,.5);assert.equal(normal.giantScale,1);assert.equal(normal.giantActive,false);
 const m=quiet();m.objects=[{...hazard(1,B.playerX,'fever'),y:B.ground-30,width:22,height:22}];tick(m,.4);
 assert.equal(m.giantScale,GIANT.scale);assert.equal(m.events.filter(e=>e.kind==='giant').length,1);
 const boost=quiet();boost.boost=2;tick(boost,.4);assert.equal(boost.giantScale,1);
});
test('The visible giant body breaks high obstacles and overhead rails once',()=>{
 const m=grown();const high=hazard(10,B.playerX+55),beam={...hazard(11,B.playerX+35,'beam'),y:B.ground-164,height:20,width:220};m.objects=[high,beam];const before=m.score;
 tick(m,.1);assert.equal(m.over,false);assert.equal(m.events.filter(e=>e.kind==='smash').length,2);assert.ok(m.score>=before+200);assert.ok(!m.objects.includes(high)&&!m.objects.includes(beam));
});
test('Expiry during a full jump preserves size and horizontal rhythm until landing',()=>{
 const m=grown();m.update(STEP,{...emptyInput(),jump:true});m.fever=STEP/2;const scale=m.giantScale,rate=m['giant'].speedFactor;let airSteps=0;
 while(m.y<B.ground-B.radius-.5){m.update(STEP,emptyInput());assert.equal(m.over,false);assert.equal(m.giantScale,scale);assert.equal(m['giant'].speedFactor,rate);airSteps++;assert.ok(airSteps<140);}
 assert.ok(airSteps>50);assert.ok(m.giantRecovery);tick(m,.4);assert.ok(m.giantScale>1&&m.giantScale<scale);tick(m,1);assert.equal(m.giantScale,1);assert.equal(m.giantActive,false);
});
test('Return remains smooth when BOOST overlaps, expires mid-return, or ends before giant expiry',()=>{
 const director=new DifficultyDirector(new Random(3));
 for(const time of [0,30,1000])for(const boost of [0,.25,1.7])for(const jump of ['none','short','full']){
  const m=grown();m.time=time;m.update(0,emptyInput());m.boost=boost;m.fever=STEP/2;
  if(jump!=='none')m.update(STEP,{...emptyInput(),jump:true,shortJump:jump==='short'});
  let previous=m.speed/director.basketball(m.time).speed;
  for(let i=0;i<480;i++){m.update(STEP,emptyInput());const rate=m.speed/director.basketball(m.time).speed;assert.ok(Math.abs(rate-previous)<.025,`${time}/${boost}/${jump}: ${previous} -> ${rate}`);previous=rate;assert.equal(m.over,false);}
  assert.equal(m.giantActive,false);assert.equal(m.giantScale,1);
 }
});
test('Recovery clears only the immediate reaction corridor without awarding smash points, then restores danger',()=>{
 const m=grown();m.fever=STEP/2;tick(m,1.16);assert.ok(m.giantRecovery);
 const near=hazard(20,B.playerX+m.speed*.7),far=hazard(21,B.playerX+m.speed*2.7);m.objects=[near,far];const score=m.score;
 tick(m,.15);assert.equal(m.giantActive,false);assert.equal(m.over,false);assert.ok(!m.objects.includes(near));assert.ok(m.objects.includes(far));assert.ok(m.score-score<30);
 tick(m,GIANT.reaction-.05);assert.equal(m.over,false);tick(m,2);assert.equal(m.over,true);
});
test('Reacquiring fever during shrink resumes growth from the current size without a snap',()=>{
 const m=grown();m.fever=STEP/2;tick(m,.5);const scale=m.giantScale;assert.ok(scale>1&&scale<4);m.fever=2;m.update(STEP,emptyInput());assert.ok(m.giantScale>=scale&&m.giantScale-scale<.02);assert.equal(m.giantRecovery,false);tick(m,.4);assert.equal(m.giantScale,4);
});
test('Power cloning for course forecasts is independent and cannot alter the live state',()=>{
 const power=new GiantPower();power.advance(.2,true,1.18,true);const before=JSON.stringify(power),clone=power.clone();clone.advance(.5,false,1,true);assert.equal(JSON.stringify(power),before);assert.notEqual(clone.scale,power.scale);
});
test('Actual course generation leaves at least the reaction window after handoff at every speed stage',()=>{
 for(const time of [0,50,300,1000]){
  const m=new BasketballModel(8);m.setGolden(true);m.time=time;m.fever=.6;Object.assign(m,{nextBonus:time+10000,itemIn:1000});
  for(let i=0;i<600&&(!m.events.some(e=>e.kind==='giantEnd')||m.giantActive);i++){m.update(STEP,emptyInput());assert.equal(m.over,false);}
  assert.equal(m.giantActive,false);const end=m.time;
  while(m.time-end<GIANT.reaction-.03){m.update(STEP,emptyInput());assert.equal(m.over,false,`${time}: unsafe return`);}
 }
});
test('Twelve three-minute Golden courses stay playable through natural giant pickups and recovery',()=>{
 let powers=0;
 for(let seed=1;seed<=12;seed++){
  const m=new BasketballModel(seed);m.setGolden(true);
  for(let i=0;i<180/STEP&&!m.over;i++){m.update(STEP,skilledBasketballInput(m));powers+=m.events.filter(e=>e.kind==='giant').length;m.events.length=0;}
  assert.ok(!m.over,`Golden seed ${seed} died at ${m.time}`);assert.ok(m.time>=179.99);
 }
 assert.ok(powers>=24);
});

