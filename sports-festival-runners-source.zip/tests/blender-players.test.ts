import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {Matrix4,Quaternion,Vector3,Box3} from 'three';
const file=readFileSync(new URL('../src/assets/football-players.glb',import.meta.url));const length=file.readUInt32LE(12),doc=JSON.parse(file.subarray(20,20+length).toString()),start=28+length;
function bounds(root:number){const b=new Box3();function visit(i:number,parent:Matrix4){const n=doc.nodes[i],m=parent.clone().multiply(n.matrix?new Matrix4().fromArray(n.matrix):new Matrix4().compose(new Vector3(...n.translation??[0,0,0]),new Quaternion(...n.rotation??[0,0,0,1]),new Vector3(...n.scale??[1,1,1])));if(n.mesh!==undefined)for(const p of doc.meshes[n.mesh].primitives){const a=doc.accessors[p.attributes.POSITION],v=doc.bufferViews[a.bufferView],off=start+(v.byteOffset??0)+(a.byteOffset??0);for(let j=0;j<a.count;j++){const at=off+j*(v.byteStride??12);b.expandByPoint(new Vector3(file.readFloatLE(at),file.readFloatLE(at+4),file.readFloatLE(at+8)).applyMatrix4(m));}}for(const child of n.children??[])visit(child,m);}visit(root,new Matrix4());return b;}
test('Player asset has articulated joints, embedded surface detail and bounded mobile payload',()=>{
 assert.equal(file.toString('ascii',0,4),'glTF');assert.ok(file.length<1_500_000);
 for(const name of ['Athlete','MatchBall','HazardBall','head','leftArm','rightArm','leftLeg','rightLeg'])assert.ok(doc.nodes.some((n:any)=>n.name===name),name);
 assert.ok(doc.images.length>0&&doc.images.every((i:any)=>i.bufferView!==undefined&&!i.uri));
 assert.ok(doc.materials.filter((m:any)=>m.normalTexture).length>=4);
 let triangles=0;for(const m of doc.meshes)for(const p of m.primitives)triangles+=doc.accessors[p.indices].count/3;assert.ok(triangles<32000);
});
test('Player art retains the defender footprint and exact unit ball diameter',()=>{
 const athlete=bounds(doc.nodes.findIndex((n:any)=>n.name==='Athlete'));assert.ok(athlete.min.y>=0&&athlete.max.y<1.95);assert.ok(athlete.min.x>-.75&&athlete.max.x<.75);
 const ball=bounds(doc.nodes.findIndex((n:any)=>n.name==='MatchBall'));for(const k of ['x','y','z'] as const){assert.ok(ball.min[k]>=-1.001&&ball.max[k]<=1.001);assert.ok(ball.max[k]-ball.min[k]>1.97);}
 const hazard=bounds(doc.nodes.findIndex((n:any)=>n.name==='HazardBall'));assert.ok(hazard.min.distanceTo(ball.min)<.001&&hazard.max.distanceTo(ball.max)<.001);
});
