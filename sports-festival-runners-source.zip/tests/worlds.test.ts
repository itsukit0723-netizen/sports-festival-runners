import { test } from 'node:test';
import assert from 'node:assert/strict';
import { gateWorlds, WORLD_IDS } from '../src/games/football/worlds';
import { FootballModel } from '../src/games/football/model';
import { STEP } from '../src/core/config';
import { emptyInput } from '../src/core/types';

test('World gates offer distinct destinations and never repeat the previous gate destinations', () => {
  let previous = ['city'] as (typeof WORLD_IDS[number])[];
  const seen = new Set<string>();
  for (let i = 0; i < 200; i++) {
    const worlds = gateWorlds(i * 317, i, previous);
    assert.notEqual(worlds[0], worlds[1]);
    for (const world of worlds) { assert.ok(!previous.includes(world)); seen.add(world); }
    previous = worlds;
  }
  assert.equal(seen.size, 5);
});

test('Actual gate traversal selects the corresponding world once; world gates have no star trail', () => {
  const destinations: string[] = [];
  for (const side of [0, 1]) {
    const m = new FootballModel(1);
    while (!m.chunks.some(chunk => chunk.choice?.worlds)) {
      const dx = m.nextChallengeRow().safeX - m.x;
      m.update(STEP, { ...emptyInput(), axis: Math.abs(dx) < .06 ? 0 : Math.sign(dx), testInvincible: true });
    }
    const gate = m.chunks.find(chunk => chunk.choice?.worlds)!, choice = gate.choice!;
    assert.equal(gate.objects.filter(o => o.type === 'star').length, 0);
    m.distance = gate.rows[1].z - .04; m.x = side ? choice.x : gate.rows[1].safeX;
    m.events.length = 0; const before = m.score;
    m.update(STEP, emptyInput());
    assert.equal(m.over, false); assert.equal(m.world, choice.worlds![side]); assert.ok(choice.resolved);
    assert.ok(m.score >= before + 90); assert.equal(m.events.filter(e => e.kind === 'portal').length, 1);
    destinations.push(m.world); m.events.length = 0; m.update(STEP, emptyInput());
    assert.equal(m.events.filter(e => e.kind === 'portal').length, 0);
  }
  assert.notEqual(destinations[0], destinations[1]);
});
