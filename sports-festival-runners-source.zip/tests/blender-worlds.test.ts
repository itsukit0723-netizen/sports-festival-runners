import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { Matrix4, Quaternion, Vector3 } from 'three';
import { WORLD_MODEL_PLACEMENTS } from '../src/games/football/world-model-layouts';
const file=readFileSync(new URL('../src/assets/arcade-worlds.glb',import.meta.url)),length=file.readUInt32LE(12);
const doc=JSON.parse(file.subarray(20,20+length).toString()),binaryStart=20+length+8;
function visit(index:number,parent:Matrix4,read:(p:any,m:Matrix4)=>void){
  const n=doc.nodes[index],local=n.matrix?new Matrix4().fromArray(n.matrix):new Matrix4().compose(new Vector3(...(n.translation??[0,0,0])),new Quaternion(...(n.rotation??[0,0,0,1])),new Vector3(...(n.scale??[1,1,1]))),world=parent.clone().multiply(local);
  if(n.mesh!==undefined)for(const p of doc.meshes[n.mesh].primitives)read(p,world);
  for(const child of n.children??[])visit(child,world,read);
}
const roots=new Map<string,number>(doc.scenes[0].nodes.map((i:number)=>[doc.nodes[i].name,i]));

test('Four Blender worlds contain every configured model, embedded planet texture and bounded geometry',()=>{
  assert.equal(file.toString('ascii',0,4),'glTF');assert.equal(file.readUInt32LE(4),2);assert.ok(file.length<4_000_000);
  for(const p of WORLD_MODEL_PLACEMENTS)assert.ok(roots.has(p.name),p.name);
  assert.equal(roots.size,17);assert.ok(doc.images.length>=1);assert.ok(doc.images.every((i:any)=>i.bufferView!==undefined&&!i.uri));
  let triangles=0;for(const mesh of doc.meshes)for(const p of mesh.primitives)triangles+=doc.accessors[p.indices??p.attributes.POSITION].count/3;
  assert.ok(triangles>20000&&triangles<60000);
});

test('Every placed Blender structure leaves the low playable road volume open',()=>{
  let vertices=0;
  for(const p of WORLD_MODEL_PLACEMENTS){
    const transform=new Matrix4().compose(new Vector3(p.x,p.y,p.z),new Quaternion().setFromAxisAngle(new Vector3(0,1,0),p.rotation),new Vector3(p.scale,p.scale,p.scale));
    visit(roots.get(p.name)!,transform,(primitive,world)=>{
      const a=doc.accessors[primitive.attributes.POSITION],view=doc.bufferViews[a.bufferView],offset=binaryStart+(view.byteOffset??0)+(a.byteOffset??0),stride=view.byteStride??12;
      assert.equal(a.componentType,5126);
      for(let i=0;i<a.count;i++){const at=offset+i*stride,v=new Vector3(file.readFloatLE(at),file.readFloatLE(at+4),file.readFloatLE(at+8)).applyMatrix4(world);assert.ok(Number.isFinite(v.y));if(v.y>=-.1&&v.y<3.5)assert.ok(Math.abs(v.x)>4.4,`${p.world}/${p.name} enters road at x=${v.x.toFixed(2)}, y=${v.y.toFixed(2)}`);vertices++;}
    });
  }
  assert.ok(vertices>10000);
});

test('Repeated Blender scenery shares a practical per-world material and triangle budget',()=>{
  const stats=new Map<string,{draws:number;triangles:number}>();
  for(const p of WORLD_MODEL_PLACEMENTS){const s=stats.get(p.world)??{draws:0,triangles:0};visit(roots.get(p.name)!,new Matrix4(),primitive=>{s.draws++;s.triangles+=doc.accessors[primitive.indices??primitive.attributes.POSITION].count/3;});stats.set(p.world,s);}
  assert.equal(stats.size,4);
  for(const [world,s]of stats){assert.ok(s.draws<250,`${world}: ${s.draws} material primitives`);assert.ok(s.triangles<240000,`${world}: ${s.triangles} triangles`);}
});
