import { test } from 'node:test';
import assert from 'node:assert/strict';
import { PatternDeck } from '../src/core/patterns';
import { Random, emptyInput } from '../src/core/types';
import { STEP, FOOTBALL as F } from '../src/core/config';
import { JUMP_PATTERNS } from '../src/games/basketball/patterns';
import { FOOTBALL_PATTERNS, FOOTBALL_OPENING_CHUNKS } from '../src/games/football/patterns';
import { BasketballModel } from '../src/games/basketball/model';
import { FootballModel } from '../src/games/football/model';
import { planRows, fillChunk, routeX, courseCollision, coursePickupClear, type Chunk, type CourseObject } from '../src/games/football/chunks';

test('Jump phrases vary both profile mix and rhythm without changing the catalog average difficulty', () => {
  assert.equal(JUMP_PATTERNS.length, 108); assert.equal(FOOTBALL_PATTERNS.length, 96);
  assert.equal(new Set(JUMP_PATTERNS.map(p => p.beats.join(','))).size, 108);
  assert.equal(new Set(FOOTBALL_PATTERNS.map(p => JSON.stringify([p.kinds, p.phrase.turns, p.phrase.mirror]))).size, 96);
  for (const profile of ['normal', 'high', 'long']) assert.equal(JUMP_PATTERNS.flatMap(p=>p.beats).filter(p=>p===profile).length,216);
  assert.ok(JUMP_PATTERNS.some(p=>p.beats.slice(0,3).every(b=>b==='normal')));
  for(const pattern of JUMP_PATTERNS){
    assert.equal(pattern.cadence.length,pattern.beats.length);
    assert.ok(Math.abs(pattern.cadence.reduce((a,b)=>a+b)/6-1)<1e-10);
    assert.ok(pattern.cadence.every(c=>c>=.88&&c<=1.16));
  }
});

test('Pattern decks visit every recipe once and avoid the last six across reshuffles', () => {
  for (const recipes of [JUMP_PATTERNS, FOOTBALL_PATTERNS]) {
    const a = new PatternDeck(recipes, new Random(123)), b = new PatternDeck(recipes, new Random(123)), c = new PatternDeck(recipes, new Random(456));
    const seen: string[] = [], alternate: string[] = [];
    for (let i = 0; i < recipes.length * 3; i++) {
      const id = a.next().id; assert.equal(id, b.next().id); assert.ok(!seen.slice(-6).includes(id));
      seen.push(id); alternate.push(c.next().id);
    }
    for (let i = 0; i < 3; i++) assert.equal(new Set(seen.slice(i * recipes.length, (i + 1) * recipes.length)).size, recipes.length);
    assert.notDeepEqual(seen, alternate);
  }
});

test('Game openings are identical across seeds and later sections vary in multi-obstacle groups', () => {
  const a = new BasketballModel(1), b = new BasketballModel(99), bPatterns = new Set<string>();
  for (let i = 0; i < 65 / STEP; i++) {
    a.update(STEP, { ...emptyInput(), testInvincible: true }); b.update(STEP, { ...emptyInput(), testInvincible: true });
    if (a.time < 15 && i % 60 === 0) assert.deepEqual(a.objects, b.objects);
    if (a.coursePattern !== 'opening') bPatterns.add(a.coursePattern);
    a.events.length = b.events.length = 0;
  }
  assert.ok(bPatterns.size >= 5); assert.notEqual(a.coursePattern, b.coursePattern);
  function run(seed: number) {
    const m = new FootballModel(seed), opening = new Map<number, Chunk>(), groups = new Map<string, number>();
    const seen = new Set<number>();
    for (let i = 0; i < 65 / STEP; i++) {
      for (const chunk of m.chunks) if (!seen.has(chunk.id)) {
        seen.add(chunk.id);
        if (chunk.start < FOOTBALL_OPENING_CHUNKS * F.chunkLength) opening.set(chunk.id, structuredClone(chunk));
        if (chunk.patternId) groups.set(chunk.patternId, (groups.get(chunk.patternId) ?? 0) + 1);
      }
      m.update(STEP, { ...emptyInput(), testInvincible: true }); m.events.length = 0;
    }
    return { opening: [...opening.values()], groups };
  }
  const x = run(1), y = run(99);
  assert.equal(x.opening.length, FOOTBALL_OPENING_CHUNKS); assert.deepEqual(x.opening, y.opening);
  assert.ok(x.groups.size >= 8); assert.ok([...x.groups.values()].filter(count => count >= 3).length >= 6);
  assert.notDeepEqual([...x.groups.keys()], [...y.groups.keys()]);
});

test('Every football recipe keeps a clear, reachable route and safe pickups through section seams', () => {
  for (const pattern of FOOTBALL_PATTERNS) {
    let previous = { z: -4, safeX: 0, gap: F.corridor.normal };
    for (let index = 0; index < 8; index++) {
      const kind = index % 2 ? pattern.hardKinds[index % 4] : pattern.kinds[index % 4];
      const gap = kind.startsWith('hard') ? F.corridor.hard : F.corridor.normal;
      const rows = planRows(index * F.chunkLength, kind, gap, previous, new Random(index), false, { ...pattern.phrase, offset: index });
      const chunk: Chunk = { id: index, start: index * F.chunkLength, kind, rows, safeX: rows.at(-1)!.safeX, gap, objects: [] };
      let id = 0;
      fillChunk(chunk, (type, x, z, width, depth, height): CourseObject => ({ id: id++, type, x, baseX: x, z, width, depth, height, moving: false, amplitude: 0, frequency: 0, phase: 0, passed: false }));
      for (const token of chunk.objects.filter(o => o.type === 'star' || o.type === 'boost')) assert.ok(coursePickupClear(token.x, token.z, chunk.objects));
      const path = [previous, ...rows];
      for (let i = 1; i < path.length; i++) {
        const travel = (path[i].z - path[i - 1].z - 2 * F.route.rowClearance) / (F.maxForwardSpeed * F.boostMultiplier) * F.steeringSensitivity;
        assert.ok(Math.abs(path[i].safeX - path[i - 1].safeX) <= travel * .86);
      }
      for (let z = rows[0].z - 1; z <= rows.at(-1)!.z + 1; z += .15) for (const o of chunk.objects.filter(o => o.type !== 'star' && o.type !== 'boost')) {
        for (const time of [0, .3, 1.6]) {
          const x = routeX(rows, z);
          // The movement envelope is checked separately by the existing suite.
          assert.equal(courseCollision(o, x, z, time), false, `${pattern.id}: ${kind}`);
        }
      }
      previous = rows.at(-1)!;
    }
  }
});
