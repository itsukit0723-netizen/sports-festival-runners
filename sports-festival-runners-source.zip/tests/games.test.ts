import { test } from 'node:test';
import assert from 'node:assert/strict';
import { BasketballModel, runnerPickupClear, isRunnerPickup, type RunnerObject } from '../src/games/basketball/model';
import { FootballModel } from '../src/games/football/model';
import { fillChunk, CHUNK_KINDS, motionOffset, planRows, routeX, coursePickupClear, courseCollision, chooseChunkKind, type Chunk, type ChunkKind, type CourseObject } from '../src/games/football/chunks';
import { obstacleFor } from '../src/games/basketball/obstacles';
import { DifficultyDirector } from '../src/core/director';
import { BASKETBALL as B, FOOTBALL as F, STEP } from '../src/core/config';
import { emptyInput, Random } from '../src/core/types';
const obstacle = (type: RunnerObject['type'] = 'cone'): RunnerObject => ({ id: 999, type, x: B.playerX - 4, y: B.ground - 45, width: 28, height: 45, passed: false, minClearance: 999 });
function sampleChunk(kind: ChunkKind, safeX: number, seed = 1): Chunk {
  const gap = kind.startsWith('hard') ? 1.5 : 1.9;
  const rows = planRows(0, kind, gap, { z: -8, safeX, gap }, new Random(seed));
  const chunk: Chunk = { id: 0, start: 0, kind, safeX: rows[rows.length - 1].safeX, gap, rows, objects: [] };
  let id = 0;
  fillChunk(chunk, (type, x, z, width, depth, height): CourseObject => ({ id: id++, type, x, baseX: x, z, width, depth, height, moving: false, amplitude: 0, frequency: 0, phase: .4, passed: false }));
  return chunk;
}
test('Basketball: single jump, landing and no mid-air jump', () => {
  const m = new BasketballModel(1); m.update(STEP, { ...emptyInput(), jump: true });
  const rising = m.vy; m.update(STEP, { ...emptyInput(), jump: true }); assert.ok(m.vy > rising);
  for (let i = 0; i < 100; i++) m.update(STEP, emptyInput());
  assert.equal(m.y, B.ground - B.radius); assert.equal(m.vy, 0);
});
test('Basketball: tap duration and measured pressure change height without delaying takeoff', () => {
  function arc(hold: number, pressure?: number, power: 'normal' | 'boost' | 'fever' = 'normal', desktop = false) {
    const m = new BasketballModel(1); if (power !== 'normal') m[power] = 2;
    let apex = m.y, firstY = m.y, landed = 0;
    for (let i = 0; i < 120; i++) {
      m.update(STEP, { ...emptyInput(), jump: i === 0, touchJump: desktop ? undefined : { held: i * STEP < hold, pressure } });
      if (i === 0) firstY = m.y;
      apex = Math.min(apex, m.y);
      if (i > 0 && m.y === B.ground - B.radius) { landed = i; break; }
    }
    return { height: B.ground - B.radius - apex, firstY, landed };
  }
  const short = arc(0), medium = arc(.08), full = arc(.2), firm = arc(0, .9), weak = arc(0, .15), desktop = arc(0, undefined, 'normal', true);
  assert.ok(short.firstY < B.ground - B.radius, 'even a brief tap takes off immediately');
  assert.ok(short.height > 45 && short.height < 65);
  assert.ok(medium.height > short.height + 20 && full.height > medium.height + 20);
  assert.ok(firm.height > weak.height + 65);
  assert.equal(full.height, desktop.height); assert.equal(firm.height, desktop.height);
  assert.equal(full.landed, desktop.landed);
  for (const power of ['boost', 'fever'] as const) {
    assert.deepEqual(arc(.08, undefined, power), medium, `${power} must not alter vertical motion`);
  }
});
test('Basketball: boost still collides, fever destroys and scores', () => {
  const normal = new BasketballModel(1); normal.boost = 3; normal.objects = [obstacle()]; normal.update(STEP, emptyInput()); assert.equal(normal.over, true);
  const fever = new BasketballModel(1); fever.fever = 3; fever.objects = [obstacle()]; fever.update(STEP, emptyInput());
  assert.equal(fever.over, false); assert.ok(fever.events.some(e => e.kind === 'smash')); assert.ok(fever.score >= 100);
});
test('Basketball: all three obstacle profiles have a jump window at all speed tiers', () => {
  for (const time of [0, 8, 16, 25, 30, 40, 50, 60, 90, 120]) for (const profile of ['normal', 'high', 'long'] as const) for (const power of ['normal', 'boost', 'fever'] as const) {
    const speed = new DifficultyDirector(new Random(1)).basketball(time).speed;
    const descriptor = obstacleFor(profile, time, speed, new Random(4));
    let possible = false;
    for (let lead = 5; lead < B.maxSpeed * B.boostMultiplier * B.jumpForce / B.gravity + 80 && !possible; lead += 2) {
      const m = new BasketballModel(1); m.time = time;
      if (power === 'boost') m.boost = 2;
      // FEVER physics are checked without letting invincibility hide collisions.
      if (power === 'fever') m.fever = 2;
      m.objects = [{ ...obstacle(), ...descriptor, x: B.playerX + lead, y: B.ground - descriptor.height }];
      m.update(STEP, { ...emptyInput(), jump: true });
      for (let i = 0; i < 110 && !m.over; i++) m.update(STEP, emptyInput());
      const smashed = m.events.some(e => e.kind === 'smash');
      if (!m.over && !smashed && m.objects.every(o => o.id !== 999 || o.passed)) possible = true;
    }
    assert.ok(possible, `${profile}, ${time}s, ${power} must have a valid jump window`);
  }
});
test('Basketball: FEVER adds a smaller speed-up, BOOST takes priority without stacking', () => {
  const normal = new BasketballModel(1), boosted = new BasketballModel(1), fever = new BasketballModel(1), both = new BasketballModel(1);
  boosted.boost = 3; fever.fever = 3; both.boost = both.fever = 3;
  for (const m of [normal, boosted, fever, both]) m.update(STEP, emptyInput());
  assert.ok(Math.abs(boosted.speed / normal.speed - B.boostMultiplier) < 1e-12);
  assert.ok(Math.abs(fever.speed / normal.speed - B.feverSpeedMultiplier) < 1e-12);
  assert.equal(both.speed, boosted.speed); assert.ok(boosted.speed > fever.speed && fever.speed > normal.speed);
});
test('Basketball: starting and ending BOOST during a long jump preserves a clear path', () => {
  for (const startBoosted of [false, true]) {
    const m = new BasketballModel(1), descriptor = obstacleFor('long', 0, B.baseSpeed, new Random(4));
    m.objects = [{ ...obstacle(), ...descriptor, x: B.playerX + 140, y: B.ground - descriptor.height }];
    if (startBoosted) m.boost = .3;
    let jumpedAt = -1;
    for (let i = 0; i < 160 && !m.over; i++) {
      const o = m.objects.find(o => o.id === 999);
      const jump = jumpedAt < 0 && !!o && o.x - B.playerX <= B.baseSpeed * B.jumpForce / B.gravity - o.width / 2;
      if (jump) jumpedAt = m.time;
      if (!startBoosted && jumpedAt >= 0 && m.time - jumpedAt > .13) m.boost = 1;
      m.update(STEP, { ...emptyInput(), jump });
    }
    assert.equal(m.over, false); assert.ok(jumpedAt >= 0);
  }
});
test('Basketball: bonus starts with 24 coins, timers and combo expire', () => {
  const m = new BasketballModel(2); m.time = B.firstBonus - STEP; m.update(STEP, emptyInput());
  assert.ok(m.bonus > 5); assert.equal(m.objects.filter(o => o.type === 'coin').length, 24);
  m.objects = [{ ...obstacle('coin'), x: B.playerX, y: m.y, width: 20 }]; m.update(STEP, emptyInput());
  assert.equal(m.combo, 1); assert.equal(m.coins, 1);
  m.objects = []; for (let i = 0; i < 170; i++) m.update(STEP, emptyInput()); assert.equal(m.combo, 0);
});
test('Football: all templates and moving extremes retain the promised corridor', () => {
  for (const kind of CHUNK_KINDS) for (const safeX of [-2.65, 0, 2.65]) {
    const chunk = sampleChunk(kind, safeX);
    for (const o of chunk.objects.filter(o => !['star', 'boost'].includes(o.type))) {
      const row = chunk.rows.find(row => Math.abs(row.z - o.z) < .01)!;
      const nearest = Math.abs(row.safeX - o.x) - o.amplitude - o.width / 2;
      assert.ok(nearest > F.ballRadius, `${kind}: corridor ${row.safeX} blocked by ${o.type}`);
    }
  }
});
test('Football: obstacle counts are at least triple every previous non-bonus template', () => {
  const before: Record<Exclude<ChunkKind, 'bonusCoin'>, number> = { easyStraight: 1, easyCoin: 2, mediumWalls: 2, mediumDefender: 1, mediumBars: 1, mediumSlidingWalls: 1, hardSlidingWalls: 1, hardNarrow: 2, hardHoles: 2, boost: 1 };
  for (const kind of Object.keys(before) as (keyof typeof before)[]) {
    const chunk = sampleChunk(kind, 0);
    const count = chunk.objects.filter(o => !['star', 'boost'].includes(o.type)).length;
    assert.ok(count >= before[kind] * 3, `${kind}: ${count} obstacles vs ${before[kind]}`);
    assert.equal(chunk.rows.length, kind.startsWith('hard') ? 5 : 4);
  }
});
test('Football: rapid feints and sliding walls stay inside their collision envelope', () => {
  const m = new FootballModel(11);
  for (const kind of ['mediumDefender', 'mediumBars', 'mediumSlidingWalls', 'hardSlidingWalls'] as const) {
    const chunk = sampleChunk(kind, 2.65);
    for (const o of chunk.objects.filter(o => o.moving)) {
      assert.ok(o.frequency >= 4.5);
      for (let i = 0; i < 1200; i++) assert.ok(Math.abs(motionOffset(o, i * STEP)) <= o.amplitude + .000001);
    }
  }
  m.update(STEP, emptyInput()); assert.ok(m.speed >= 18);
});
test('Football: every dense row transition and chunk seam fits at maximum BOOST speed', () => {
  let previous = { z: -8, safeX: 0, gap: 1.5 };
  for (let i = 0; i < 500; i++) {
    const kind = CHUNK_KINDS[i % CHUNK_KINDS.length];
    for (const row of planRows(i * F.chunkLength, kind, 1.5, previous, new Random(i + 1))) {
      const freeTime = (row.z - previous.z - F.route.maxObstacleDepth - F.ballRadius * 2) / (F.maxForwardSpeed * F.boostMultiplier);
      assert.ok(Math.abs(row.safeX - previous.safeX) / F.steeringSensitivity <= freeTime * F.route.transitionSafety + .00001);
      previous = row;
    }
  }
});
test('Football: collision is instant, tokens score, steering is bounded', () => {
  const m = new FootballModel(1), o = m.chunks[0].objects.find(o => o.type === 'cone')!;
  m.x = o.x; m.distance = o.z - .1; m.update(STEP, emptyInput()); assert.ok(m.over);
  const star = new FootballModel(2); const token = star.chunks[0].objects.find(o => o.type === 'star')!;
  star.x = token.x; star.distance = token.z - .05; star.update(STEP, emptyInput()); assert.ok(star.coins > 0); assert.ok(star.score >= F.tokenScore);
  star.update(STEP, { ...emptyInput(), drag: 100 }); assert.ok(star.x <= F.courseWidth / 2 - F.ballRadius);
});
test('Football: the opening leaves time to try left and right controls', () => {
  for (const direction of [-1, 1]) {
    const m = new FootballModel(8);
    for (let i = 0; i < 120; i++) m.update(STEP, { ...emptyInput(), axis: direction });
    assert.equal(m.over, false); assert.ok(Math.abs(m.x) > 3);
  }
});
test('Football: 12 three-minute runs follow safe routes, with bounded object counts', () => {
  for (let seed = 1; seed <= 12; seed++) {
    const m = new FootballModel(seed); let peakObjects = 0;
    for (let i = 0; i < 180 / STEP && !m.over; i++) {
      const next = m.nextChallengeRow();
      const dx = next.safeX - m.x;
      m.update(STEP, { jump: false, axis: Math.abs(dx) < .06 ? 0 : Math.sign(dx), drag: 0 });
      peakObjects = Math.max(peakObjects, m.chunks.reduce((sum, c) => sum + c.objects.length, 0));
      m.events.length = 0;
    }
    assert.equal(m.over, false, `seed ${seed} died at ${m.time.toFixed(2)}`);
    assert.ok(m.time >= 179.9); assert.ok(m.chunks.length <= 6); assert.ok(peakObjects < 180); assert.ok(m.coins > 100);
  }
});
test('Basketball: skilled timing survives for three minutes across 12 seeds', () => {
  for (let seed = 1; seed <= 12; seed++) {
    const m = new BasketballModel(seed);
    for (let i = 0; i < 180 / STEP && !m.over; i++) {
      const o = m.objects.find(o => ['cone', 'hurdle', 'dummy', 'bench', 'mat'].includes(o.type) && o.x + o.width > B.playerX - B.radius);
      const baseSpeed = new DifficultyDirector(new Random(1)).basketball(m.time).speed;
      const apex = B.jumpForce / B.gravity;
      const apexTravel = baseSpeed * (apex + (B.boostMultiplier - 1) * Math.min(m.boost, apex) +
        (B.feverSpeedMultiplier - 1) * Math.max(0, Math.min(m.fever, apex) - Math.min(m.boost, apex)));
      const leadDistance = o ? apexTravel - o.width / 2 : -1;
      m.update(STEP, { ...emptyInput(), jump: !!o && o.x - B.playerX <= leadDistance && o.x > B.playerX && m.y >= B.ground - B.radius - .5 });
      m.events.length = 0;
      assert.ok(m.objects.length < 130);
      for (const pickup of m.objects.filter(isRunnerPickup)) assert.ok(runnerPickupClear(pickup.x, pickup.y, m.objects), `pickup ${pickup.id} overlaps a hazard`);
    }
    assert.equal(m.over, false, `seed ${seed} died at ${m.time.toFixed(2)}`); assert.ok(m.time >= 179.9);
  }
});

test('Basketball: BOOST and FEVER never change the jump height, apex or landing time', () => {
  for (const mode of ['boost', 'fever', 'midair'] as const) {
    const normal = new BasketballModel(71), fast = new BasketballModel(71);
    if (mode !== 'midair') fast[mode] = 2;
    for (let i = 0; i < 150; i++) {
      if (mode === 'midair' && i === 23) fast.boost = .2;
      const input = { ...emptyInput(), jump: i === 0 };
      normal.update(STEP, input); fast.update(STEP, input);
      assert.equal(fast.y, normal.y); assert.equal(fast.vy, normal.vy);
    }
    assert.ok(fast.distance > normal.distance);
    assert.ok(fast.rotation <= B.maxVisualRollRate * fast.time + 1e-9);
  }
});

test('Basketball: coins and powerups avoid newly spawned obstacles and stay within jump reach', () => {
  for (const profile of ['normal', 'high', 'long'] as const) {
    const m = new BasketballModel(4), descriptor = obstacleFor(profile, 60, B.maxSpeed, new Random(2));
    m.objects = [{ ...obstacle(), ...descriptor, x: B.width + 30, y: B.ground - descriptor.height }];
    for (let i = 0; i < 100; i++) {
      m.fever = 2; m.update(STEP, emptyInput());
      for (const token of m.objects.filter(isRunnerPickup)) {
        assert.ok(runnerPickupClear(token.x, token.y, m.objects));
        assert.ok(token.y >= B.ground - B.radius - B.jumpForce ** 2 / (2 * B.gravity));
      }
    }
  }
});

test('Football: token paths clear complete obstacle and movement envelopes in every template', () => {
  for (let seed = 1; seed <= 50; seed++) for (const kind of CHUNK_KINDS) {
    const chunk = sampleChunk(kind, (seed % 3 - 1) * 2.65, seed);
    assert.ok(chunk.objects.filter(o => o.type === 'star').length >= 7);
    for (const token of chunk.objects.filter(o => o.type === 'star')) {
      assert.ok(coursePickupClear(token.x, token.z, chunk.objects), `${kind}: unsafe star`);
      const row = chunk.rows.find(row => Math.abs(row.z - token.z) <= F.route.rowClearance);
      if (row) assert.ok(Math.abs(token.x - row.safeX) < 1e-6);
    }
    for (const row of chunk.rows) {
      assert.equal(routeX(chunk.rows, row.z + .5), row.safeX);
    }
  }
});
test('Elapsed time uses dt consistently for 30, 60 and 120 Hz', () => {
  const scores = [30, 60, 120].map(fps => { const m = new BasketballModel(10); for (let i = 0; i < fps * 2; i++) m.update(1 / fps, emptyInput()); assert.ok(Math.abs(m.time - 2) < .00001); return m.score; });
  assert.ok(Math.max(...scores) - Math.min(...scores) < 2);
});

test('Difficulty: 30s, 50s and later keep increasing speed and basketball density', () => {
  const d = new DifficultyDirector(new Random(1));
  let previous = d.basketball(0);
  for (const time of [16, 30, 50, 75, 90, 120]) {
    const next = d.basketball(time);
    assert.ok(next.speed > previous.speed); assert.ok(next.gap <= previous.gap);
    previous = next;
  }
  for (const boundary of [30, 50]) assert.ok(d.basketball(boundary + .01).speed - d.basketball(boundary - .01).speed < 1);
  const f = new FootballModel(1); let previousSpeed = 0;
  for (const time of [30, 50, 70, 100, 140]) {
    f.time = time; f.update(STEP, { ...emptyInput(), testInvincible: true });
    assert.ok(f.speed > previousSpeed); previousSpeed = f.speed;
  }
});

test('Basketball: FEVER and BONUS retain obstacles instead of an empty six-second area', () => {
  const m = new BasketballModel(3); const births: number[] = []; let lastId = -1;
  for (let i = 0; i < 65 / STEP; i++) {
    m.update(STEP, { ...emptyInput(), testInvincible: true });
    for (const o of m.objects.filter(o => !isRunnerPickup(o))) if (o.id > lastId) { births.push(m.time); lastId = o.id; }
    m.events.length = 0;
  }
  assert.ok(births.filter(t => t >= 14 && t <= 19.2).length >= 3);
  assert.ok(births.filter(t => t >= 39 && t <= 44.2).length >= 3);
  const fever = new BasketballModel(8); fever.fever = 20;
  let spawned = 0, previousId = -1;
  for (let i = 0; i < 8 / STEP; i++) {
    fever.update(STEP, emptyInput());
    for (const o of fever.objects.filter(o => !isRunnerPickup(o))) if (o.id > previousId) { spawned++; previousId = o.id; }
    fever.events.length = 0;
  }
  assert.ok(spawned >= 4);
});

test('Basketball: complete coin guides appear offscreen and never overlap powerups', () => {
  for (let seed = 1; seed <= 8; seed++) {
    const m = new BasketballModel(seed), known = new Set<number>(); let visibleCoins = new Map<number, { x: number; y: number }>();
    for (let i = 0; i < 90 / STEP; i++) {
      m.update(STEP, { ...emptyInput(), testInvincible: true });
      const ids = new Set(m.objects.map(o => o.id));
      for (const [id, previous] of visibleCoins) if (!ids.has(id)) {
        assert.ok(previous.x < 0 || Math.hypot(previous.x - B.playerX, previous.y - m.y) < 80, `visible coin popped out: ${id}`);
      }
      visibleCoins = new Map();
      const powers = m.objects.filter(o => o.type === 'boost' || o.type === 'fever');
      for (const o of m.objects.filter(o => o.type === 'coin')) {
        if (!known.has(o.id)) assert.ok(o.x >= B.width + 9, `coin ${o.id} appeared inside viewport`);
        for (const p of powers) assert.ok(Math.hypot(o.x - p.x, o.y - p.y) >= 42 - 1e-6, 'coin overlaps a powerup');
        if (o.x > -10 && o.x < B.width - 10) visibleCoins.set(o.id, { x: o.x, y: o.y });
        known.add(o.id);
      }
      m.events.length = 0;
    }
  }
});

// TEMP TEST CONTROLS: remove this test with src/testing/.
test('Temporary invincibility toggles collision only and OFF restores normal death', () => {
  const b = new BasketballModel(1); b.objects = [obstacle()];
  b.update(STEP, { ...emptyInput(), testInvincible: true });
  assert.equal(b.over, false); assert.equal(b.fever, 0); assert.equal(b.boost, 0);
  assert.ok(!b.events.some(e => e.kind === 'smash'));
  b.update(STEP, emptyInput()); assert.equal(b.over, true);
  const f = new FootballModel(1), o = f.chunks[0].objects.find(o => o.type === 'cone')!;
  f.x = o.x; f.distance = o.z - .1;
  f.update(STEP, { ...emptyInput(), testInvincible: true });
  assert.equal(f.over, false); assert.equal(f.boost, 0);
  f.update(STEP, emptyInput()); assert.equal(f.over, true);
});

test('Basketball: every second after 50 keeps getting harder, including beyond the old 120s cap', () => {
  const d = new DifficultyDirector(new Random(1));
  let previous = d.basketball(50);
  for (let time = 51; time <= 600; time++) {
    const next = d.basketball(time);
    assert.ok(next.speed > previous.speed, `speed stopped at ${time}s`);
    assert.ok(next.gap < previous.gap, `cadence stopped at ${time}s`);
    assert.ok(next.speed - previous.speed < 7); assert.ok(next.gap > 2 * B.jumpForce / B.gravity + .1);
    previous = next;
  }
  for (const time of [0, 8, 16, 25, 30, 40]) {
    const oldGaps = [2.05, 1.75, 1.5, 1.3, 1.18, 1.1];
    assert.ok(d.basketball(time).gap < oldGaps[[0, 8, 16, 25, 30, 40].indexOf(time)]);
  }
});

test('Football: new patterns increase density, vary routes and avoid consecutive repeats', () => {
  for (const kind of CHUNK_KINDS.filter(k => k !== 'bonusCoin')) {
    const routes = new Set<string>();
    for (let seed = 1; seed <= 30; seed++) {
      const c = sampleChunk(kind, 0, seed);
      assert.equal(c.rows.length, kind.startsWith('hard') ? 5 : 4);
      assert.ok(c.objects.filter(o => !['star', 'boost'].includes(o.type)).length >= c.rows.length * 2);
      routes.add(c.rows.map(r => `${r.z.toFixed(2)}:${r.safeX.toFixed(2)}`).join(','));
    }
    assert.ok(routes.size > 20);
  }
  for (const tier of ['easy', 'medium', 'hard'] as const) {
    const recent: ChunkKind[] = [], seen = new Set<ChunkKind>(), random = new Random(32);
    for (let i = 0; i < 100; i++) {
      const kind = chooseChunkKind(tier, random, recent);
      assert.notEqual(kind, recent.at(-1));
      if (tier !== 'easy') assert.ok(!recent.slice(-2).includes(kind));
      seen.add(kind); recent.push(kind);
    }
    if (tier === 'medium') for (const kind of ['mediumRollers', 'mediumRotors', 'mediumSlalom'] as ChunkKind[]) assert.ok(seen.has(kind));
    if (tier === 'hard') assert.ok(seen.has('hardMix'));
  }
});

test('Football: rolling balls, rotating arms and posts have the collision shapes they show', () => {
  const roller = sampleChunk('mediumRollers', 0).objects.find(o => o.type === 'roller')!;
  const pillar = sampleChunk('mediumSlalom', 0).objects.find(o => o.type === 'pillar')!;
  for (const o of [roller, pillar]) {
    assert.ok(courseCollision(o, o.x, o.z, 0));
    assert.equal(courseCollision(o, o.x + o.width / 2 + F.ballRadius + .1, o.z, 0), false);
  }
  const rotor = sampleChunk('mediumRotors', 0).objects.find(o => o.type === 'rotor')!;
  rotor.frequency = 1; rotor.phase = 0;
  assert.equal(courseCollision(rotor, rotor.x + .65, rotor.z + .65, 0), false);
  assert.equal(courseCollision(rotor, rotor.x + .65, rotor.z + .65, Math.PI / 4), true);
  const mixed = sampleChunk('hardMix', 0);
  for (const type of ['roller', 'rotor', 'pillar', 'slider', 'hole']) assert.ok(mixed.objects.some(o => o.type === type));
});

test('Football: new obstacle motion leaves the marked coin corridor open at every angle', () => {
  for (const kind of ['mediumRollers', 'mediumRotors', 'mediumSlalom', 'hardMix'] as const) for (const safeX of [-2.65, 0, 2.65]) {
    const c = sampleChunk(kind, safeX);
    for (const o of c.objects.filter(o => !['star', 'boost'].includes(o.type))) {
      const row = c.rows.find(r => r.z === o.z)!;
      for (let i = 0; i < 240; i++) {
        const time = i / 30; o.x = o.baseX + (o.moving ? motionOffset(o, time) : 0);
        for (const dz of [-.7, 0, .7]) assert.equal(courseCollision(o, row.safeX, row.z + dz, time), false, `${kind} blocked the route`);
      }
    }
  }
});

test('Football: bold roller sweeps use available width, stay inside the road and collide at their moving center', () => {
 const rollers=[-2.65,0,2.65].flatMap(x=>sampleChunk('mediumRollers',x).objects.filter(o=>o.type==='roller'));
 assert.ok(rollers.some(o=>o.amplitude>.9),'Wide obstacle space should allow a larger sweep');
 for(const o of rollers)for(let i=0;i<360;i++){
  const time=i/60;o.x=o.baseX+motionOffset(o,time);
  assert.ok(Math.abs(o.x)+o.width/2<=F.courseWidth/2+.001);
  assert.ok(courseCollision(o,o.x,o.z,time));
  assert.ok(!courseCollision(o,o.x+o.width/2+F.ballRadius+.1,o.z,time));
 }
});
