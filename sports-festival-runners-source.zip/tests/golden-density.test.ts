import test from 'node:test';import assert from 'node:assert/strict';
import {BasketballModel,isRunnerPickup,type RunnerObject} from '../src/games/basketball/model';
import {BASKETBALL as B,STEP} from '../src/core/config';import {emptyInput} from '../src/core/types';
import {FULL_GUIDE,SHORT_GUIDE} from '../src/games/basketball/jump';

test('Golden courses contain more hazards while normal mode retains the same generator',()=>{
 function count(golden:boolean,seed:number){const m=new BasketballModel(seed);m.setGolden(golden);Object.assign(m,{itemIn:10000,nextBonus:10000});const seen=new Set<number>();for(let i=0;i<60/STEP;i++){m.update(STEP,{...emptyInput(),testInvincible:true});for(const o of m.objects)if(!isRunnerPickup(o))seen.add(o.id);m.events.length=0;}return seen.size;}
 for(const seed of [1,17,87])assert.ok(count(true,seed)>count(false,seed)*1.2);
});
test('Golden double hurdles fit one deliberate full jump or held short tap at every speed',()=>{
 for(const time of [0,30,300,1000])for(const boosted of [false,true])for(const mode of ['full','short']){
  const m=new BasketballModel(8);m.setGolden(true);m.time=time;m.boost=boosted?5:0;Object.assign(m,{obstacleIn:10000,coinIn:10000,itemIn:10000,nextBonus:10000});m.update(0,emptyInput());
  const guide=mode==='full'?FULL_GUIDE:SHORT_GUIDE,x=B.playerX+m['forecastTravel'](guide.apex);
  const parent:RunnerObject={id:100,type:'hurdle',x:x-21,y:B.ground-64,width:42,height:64,profile:'normal',passed:false,minClearance:999};
  const buddy:RunnerObject={...parent,id:101,x:x+m['forecastTravel'](.16)-11,y:B.ground-24,width:22,height:24,clusterParent:100};m.objects=[parent,buddy];
  for(let i=0;i<1.2/STEP&&!m.over;i++)m.update(STEP,{...emptyInput(),jump:i===0,...(mode==='short'?{touchJump:{held:i*STEP<.08}}:{})});
  assert.equal(m.over,false,`${time}/${boosted}/${mode}`);assert.ok(parent.passed&&buddy.passed);
 }
});
test('A Golden boost is queued after existing hazards and future hazards leave an acceleration pocket',()=>{
 const m=new BasketballModel(4);m.setGolden(true);Object.assign(m,{coinIn:10000,itemIn:10000,nextBonus:10000});
 m.objects=[{id:100,type:'bench',x:500,y:B.ground-34,width:180,height:34,passed:false,minClearance:999},{id:101,type:'dummy',x:950,y:B.ground-110,width:40,height:110,passed:false,minClearance:999}];
 assert.ok(m['add']('boost',B.width+30,B.ground-30));const boost=m.objects.find(o=>o.type==='boost')!;assert.ok(boost.x>990+m.speed*.45);
 m['obstacleIn']=0;m.update(STEP,emptyInput());assert.ok(m.objects.includes(boost));const fresh=m.objects.filter(o=>!isRunnerPickup(o)&&o.id<100&&!o.clusterParent);
 assert.ok(fresh.length);assert.ok(fresh.every(o=>o.x-boost.x>=m.speed*B.boostMultiplier*.69));
});
