import {BasketballModel,isRunnerPickup} from '../../src/games/basketball/model';
import {BASKETBALL as B} from '../../src/core/config';
import {DifficultyDirector} from '../../src/core/director';
import {Random,emptyInput,type GameInput} from '../../src/core/types';
import {jumpGuide,FULL_GUIDE} from '../../src/games/basketball/jump';
const director=new DifficultyDirector(new Random(1));
const tapGuide=jumpGuide(0);
export function skilledBasketballInput(m:BasketballModel,hold?:number):GameInput {
  const o=m.objects.find(o=>!isRunnerPickup(o)&&o.type!=='beam'&&o.x+o.width>B.playerX-B.radius);
  const guide=o?.tapOnly?(hold===undefined?tapGuide:jumpGuide(hold)):FULL_GUIDE;
  let travel=0;
  for(let t=0;t<guide.apex;t+=1/480) {
    const dt=Math.min(1/480,guide.apex-t),at=t+dt/2;
    travel+=director.basketball(m.time+at).speed*(m.boost>at?B.boostMultiplier:m.fever>at?B.feverSpeedMultiplier:1)*dt;
  }
  const jump=!!o&&o.x+o.width/2-B.playerX<=travel&&o.x>B.playerX&&m.y>=B.ground-B.radius-.5;
  return {...emptyInput(),jump,shortJump:!!o?.tapOnly&&hold===undefined};
}
