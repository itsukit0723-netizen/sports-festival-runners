import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
import * as THREE from 'three';import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';
import {GoldenStadium,TROPHY_SPACING,TROPHY_PHASE,TROPHY_SIDE} from '../src/games/football/golden-stadium';
const file=fs.readFileSync(new URL('../src/assets/golden-trophy.glb',import.meta.url));
const gltf=await new GLTFLoader().parseAsync(file.buffer.slice(file.byteOffset,file.byteOffset+file.byteLength),'');
const trophy=gltf.scene.getObjectByName('GoldenTrophy')!;
function withCanvas<T>(run:()=>T){
 const before=Object.getOwnPropertyDescriptor(globalThis,'document');
 Object.assign(globalThis,{document:{createElement:()=>({width:0,height:0,getContext:()=>new Proxy({},{get:()=>()=>{},set:()=>true})})}});
 try{return run();}finally{if(before)Object.defineProperty(globalThis,'document',before);else Reflect.deleteProperty(globalThis,'document');}
}
test('Blender trophy has a ground-level origin, connected-looking cup silhouette and bounded payload',()=>{
 assert.ok(trophy);assert.ok(file.length<800_000);
 const b=new THREE.Box3().setFromObject(trophy),size=b.getSize(new THREE.Vector3());
 assert.ok(Math.abs(b.min.y)<1e-5);assert.ok(size.y>2.9&&size.y<3.1);assert.ok(size.x>2&&size.x<2.3);assert.ok(size.z<1.7);
 let triangles=0,gold=0;
 trophy.traverse(o=>{if(o instanceof THREE.Mesh){triangles+=(o.geometry.index?.count??o.geometry.getAttribute('position').count)/3;for(const m of Array.isArray(o.material)?o.material:[o.material])if(m instanceof THREE.MeshStandardMaterial&&m.metalness>.65)gold++;}});
 assert.ok(triangles<28000);assert.ok(gold>=2);
});
test('Loaded trophy clones stay on their plates, clear the playable road and share geometry',()=>withCanvas(()=>{
 const stage=new GoldenStadium();stage.setTrophy(trophy);stage.update(13,9,false);stage.group.updateMatrixWorld(true);
 let count=0,triangles=0;const originals=new Set<THREE.BufferGeometry>();trophy.traverse(o=>{if(o instanceof THREE.Mesh)originals.add(o.geometry);});
 stage.group.traverse(o=>{if(o.name==='TrophyMount'){
  count++;const b=new THREE.Box3().setFromObject(o);assert.ok(Math.abs(b.min.y)<1e-5);assert.ok(b.min.x>4.4||b.max.x< -4.4);assert.ok(b.max.y<5.5,'cup must remain below the flag hems');
  const plate=o.parent!.getObjectByName('TrophyDisplayPlate')!;const foot=new THREE.Box3().setFromObject(plate);assert.ok(Math.abs(foot.max.y)<1e-5);assert.ok(Math.abs(foot.min.y+.2)<1e-5);
  o.traverse(mesh=>{if(mesh instanceof THREE.Mesh)assert.ok(originals.has(mesh.geometry));});
 }if(o instanceof THREE.Mesh)triangles+=(o.geometry.index?.count??o.geometry.getAttribute('position').count)/3;});
 assert.equal(count,6);assert.ok(triangles<350000,`complete stage budget ${triangles}`);stage.dispose();
}));
test('Display bays move with the stadium, never spin or hover, and recycle outside the view',()=>withCanvas(()=>{
 const stage=new GoldenStadium();
 const bays=stage.group.children.filter(o=>o.name.startsWith('TrophyBay-'));
 for(const reduced of [false,true]){
  stage.update(10,0,reduced);const old=bays.map(o=>o.position.z);stage.update(12,20,reduced);
  for(let i=0;i<bays.length;i++){
   assert.ok(Math.abs(bays[i].position.z-old[i]-2)<1e-9);assert.equal(bays[i].position.y,0);assert.equal(Math.abs(bays[i].position.x),TROPHY_SIDE);assert.equal(bays[i].rotation.y,0);
   // Relative to each 28m column group the bay remains in the same free alcove.
   assert.ok(Math.abs((bays[i].position.z-12-TROPHY_PHASE)%28)<1e-9);
  }
 }
 const visible=()=>bays.filter(o=>o.position.z>-100&&o.position.z<7).map(o=>o.position.z).sort((a,b)=>a-b);
 stage.update(TROPHY_SPACING-.001,0,false);const a=visible();stage.update(TROPHY_SPACING+.001,0,false);const b=visible();
 assert.equal(a.length,b.length);for(let i=0;i<a.length;i++)assert.ok(Math.abs(b[i]-a[i]-.002)<1e-8);
 stage.dispose();
}));
