import * as THREE from 'three';
import { DefenderFactory } from '../../src/games/football/defender';
const canvas = document.querySelector('canvas')!;
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
const scene = new THREE.Scene(); scene.background = new THREE.Color('#d9e7f6');
scene.add(new THREE.HemisphereLight('#fff5e9', '#a8b4d7', 2.5));
const light = new THREE.DirectionalLight('#fff4db', 3); light.position.set(-8, 16, 9); scene.add(light);
const materials = new Map<string, THREE.MeshStandardMaterial>();
const factory = new DefenderFactory(g => g, color => {
  if (!materials.has(color)) materials.set(color, new THREE.MeshStandardMaterial({ color, roughness: .72 }));
  return materials.get(color)!;
});
const front = factory.create(), turned = factory.create(); front.position.x = -.95; turned.position.x = .95;
const turnedRoot = new THREE.Group(); turnedRoot.add(turned); turned.rotation.y = -.55;
scene.add(front, turnedRoot);
const floor = new THREE.Mesh(new THREE.PlaneGeometry(200, 200), new THREE.MeshStandardMaterial({ color: '#b9d1c6', roughness: 1 }));
floor.rotation.x = -Math.PI / 2; floor.position.y = -.025; scene.add(floor);
const camera = new THREE.PerspectiveCamera(31, 1, .1, 100); camera.position.set(.25, 1.7, 6.9); camera.lookAt(0, .96, 0);
function resize() { renderer.setSize(innerWidth, innerHeight, false); camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix(); }
resize(); addEventListener('resize', resize);
const started = performance.now();
function frame(now = performance.now()) {
  const time = (now - started) / 1000;
  front.position.set(-.95, 0, 0); turned.position.set(.95, 0, 0);
  factory.animate(front, time, 4.8, 1); factory.animate(turned, time + .7, 4.8, -1);
  renderer.render(scene, camera); requestAnimationFrame(frame);
}
frame();
