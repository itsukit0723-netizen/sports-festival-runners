import {FootballModel} from '../../src/games/football/model';
import {FootballRenderer} from '../../src/games/football/renderer';
import {CROSSING_STYLES,planRows,fillChunk,motionOffset,motionDepthOffset,type Chunk,type CourseObject} from '../../src/games/football/chunks';
import {Random} from '../../src/core/types';
const labels=['端回避：大型ボール → 壁','端回避：大型ボール2連続','端回避：スライドゲート','端回避：人 → 壁','端回避：回転バー → 壁','端回避：柱ジグザグ','小型ボールの不規則な混戦'];
const m=new FootballModel(2);m.distance=-2;m.x=0;m.time=1.1;m.world='city';m.chunks=[];
const renderer=new FootballRenderer(document.querySelector('canvas')!,m);let done=false;
let selected:number[]|undefined;
const compact=document.createElement('button');compact.textContent='今回の2点を比較';compact.onclick=()=>{selected=[1,6];(document.querySelector('button') as HTMLButtonElement).click();};document.querySelector('button')!.after(compact);
document.querySelector('button')!.onclick=()=>{
 if(!renderer.worldModelReady||!renderer.playerModelReady)return;
 done=true;const gallery=document.querySelector('#gallery')!;gallery.replaceChildren();
 (gallery as HTMLElement).style.gridTemplateColumns=selected?'repeat(2,1fr)':'repeat(3,1fr)';
 [...CROSSING_STYLES,'scramble'].forEach((_,index)=>{
  if(selected&&!selected.includes(index))return;
  const kind=index===6?'hardScramble':'hardCrossing';
  const rows=planRows(0,kind,2.05,{z:-2.2,safeX:0,gap:2.48},new Random(4),false,undefined,24);
  const c:Chunk={id:index,start:0,length:index===6?26:rows[1].z+5,kind,rows,safeX:rows.at(-1)!.safeX,gap:2.05,objects:[],variant:index*2};let id=index*100;
  m.distance=index===6?-2:rows[0].z-9;
  fillChunk(c,(type,x,z,width,depth,height):CourseObject=>({id:id++,type,x,baseX:x,z,width,depth,height,moving:false,amplitude:0,frequency:0,phase:0,passed:false}));m.chunks=[c];
  // Populate the actual model positions using the same motion function as play.
  for(const o of c.objects)if(o.moving){o.x=o.baseX+motionOffset(o,m.time);if(o.chaotic)o.z=o.baseZ!+motionDepthOffset(o,m.time);}
  for(let i=0;i<40;i++)renderer.render(.05,[]);
  const card=document.createElement('article'),title=document.createElement('h2'),img=document.createElement('img');title.textContent=labels[index];img.src=document.querySelector('canvas')!.toDataURL();img.alt=labels[index];card.append(title,img);gallery.append(card);
  if(selected){img.style.height='560px';img.style.objectFit='contain';img.style.background='#101a25';}
 });
 document.querySelector('canvas')!.style.display='none';document.querySelector('#status')!.textContent='同じ実レンダラーで端回避6種類と混戦を比較';
};
function frame(){if(!done){renderer.render(0,[]);document.querySelector('#status')!.textContent=renderer.worldModelReady&&renderer.playerModelReady?'準備完了':'読み込み中';requestAnimationFrame(frame);}}frame();
