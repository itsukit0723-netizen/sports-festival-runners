import {FootballModel} from '../../src/games/football/model';
import {FootballRenderer} from '../../src/games/football/renderer';
import {CROSSING_STYLES,planRows,fillChunk,motionOffset,type Chunk,type CourseObject} from '../../src/games/football/chunks';
import {Random} from '../../src/core/types';
const labels=['大型ボール → 動く壁','高難度：大型ボール2連続','連続スライドゲート','動くディフェンダー → 壁','大きな回転バー → 壁','柱の左右ジグザグ'];
const m=new FootballModel(2);m.distance=-2;m.x=0;m.time=1.1;m.world='city';m.chunks=[];
const renderer=new FootballRenderer(document.querySelector('canvas')!,m);let done=false;
document.querySelector('button')!.onclick=()=>{
 if(!renderer.worldModelReady||!renderer.playerModelReady)return;
 done=true;const gallery=document.querySelector('#gallery')!;gallery.replaceChildren();
 CROSSING_STYLES.forEach((_,index)=>{
  const rows=planRows(0,'hardCrossing',2.05,{z:-2.2,safeX:0,gap:2.48},new Random(4),false,undefined,24);
  const c:Chunk={id:index,start:0,kind:'hardCrossing',rows,safeX:rows[1].safeX,gap:2.05,objects:[],variant:index*2};let id=index*100;
  fillChunk(c,(type,x,z,width,depth,height):CourseObject=>({id:id++,type,x,baseX:x,z,width,depth,height,moving:false,amplitude:0,frequency:0,phase:0,passed:false}));m.chunks=[c];
  // Populate the actual model positions using the same motion function as play.
  for(const o of c.objects)if(o.moving)o.x=o.baseX+motionOffset(o,m.time);
  for(let i=0;i<40;i++)renderer.render(.05,[]);
  const card=document.createElement('article'),title=document.createElement('h2'),img=document.createElement('img');title.textContent=labels[index];img.src=document.querySelector('canvas')!.toDataURL();img.alt=labels[index];card.append(title,img);gallery.append(card);
 });
 document.querySelector('canvas')!.style.display='none';document.querySelector('#status')!.textContent='同じ実レンダラーで6種類を比較';
};
function frame(){if(!done){renderer.render(0,[]);document.querySelector('#status')!.textContent=renderer.worldModelReady&&renderer.playerModelReady?'準備完了':'読み込み中';requestAnimationFrame(frame);}}frame();
