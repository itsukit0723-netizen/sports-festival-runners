import React from 'react';import {createRoot} from 'react-dom/client';
import '../../src/styles.css';
import '@fontsource/barlow/latin-500.css';import '@fontsource/barlow/latin-700.css';import '@fontsource/barlow-condensed/latin-700.css';import '@fontsource/barlow-condensed/latin-800.css';
import '../../src/golden/public-service';import GameView from '../../src/ui/GameView';
const game=new URLSearchParams(location.search).get('game')==='basketball'?'basketballRunner':'rollingFootball';
const view=<GameView id={game} best={0} sound={false} onToggleSound={()=>{}} onBest={()=>{}} onHome={()=>location.reload()}/>;
createRoot(document.querySelector('#root')!).render(new URLSearchParams(location.search).has('host')?<div className="research-active"><style>{`.research-active .game-page{height:calc(100svh - 64px)}.research-active .game-shell{max-height:calc(100svh - 64px)}`}</style><div data-play-header="" style={{height:56,display:'flex',alignItems:'center',justifyContent:'space-between',padding:'0 12px',background:'#203221',color:'#eee',fontSize:12}}>参加者 001 · サッカー · 表示確認<button>テスト一覧へ戻る</button></div>{view}</div>:view);
