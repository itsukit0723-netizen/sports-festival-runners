import React from 'react';
import { createRoot } from 'react-dom/client';
import '../../src/styles.css';
import { RewardFeedback, RouteCue } from '../../src/ui/RewardFeedback';
import { BasketballModel, isRunnerPickup } from '../../src/games/basketball/model';
import { BasketballRenderer } from '../../src/games/basketball/renderer';
import { FootballModel } from '../../src/games/football/model';
import { FootballRenderer } from '../../src/games/football/renderer';
import { choiceRouteX, type Chunk } from '../../src/games/football/chunks';
import { SHORT_GUIDE, SHORT_GUIDE_HOLD } from '../../src/games/basketball/jump';
import { STEP, BASKETBALL as B, FOOTBALL as F } from '../../src/core/config';
import { emptyInput, clamp, type GameEvent } from '../../src/core/types';
const b = new BasketballModel(1);
while (!b.objects.some(o => !isRunnerPickup(o))) b.update(STEP, emptyInput());
const obstacle = b.objects.find(o => !isRunnerPickup(o))!;
while (obstacle.x > 200) b.update(STEP, emptyInput());
let f!: FootballModel, choice!: Chunk;
for (let seed = 1; seed <= 12 && !choice; seed++) {
  f = new FootballModel(seed);
  for (let i = 0; i < 120 / STEP && !choice; i++) { f.update(STEP, { ...emptyInput(), testInvincible: true }); choice = f.chunks.find(c => c.choice)!; }
}
if (!choice) throw Error('No generated choice found');
f.distance = choice.start - 3; f.x = choiceRouteX(choice, f.distance); f.chunks = [choice];
b.events = []; f.events = [];
const br = new BasketballRenderer(document.querySelector('#b')!, b), fr = new FootballRenderer(document.querySelector('#f')!, f);
const bf = createRoot(document.querySelector('#b-feedback')!), ff = createRoot(document.querySelector('#f-feedback')!);
createRoot(document.querySelector('#b-cue')!).render(<RouteCue game="basketballRunner" text="低めに跳ぶ → 早く着地 → ミントのコインを回収"/>);
createRoot(document.querySelector('#f-cue')!).render(<RouteCue game="rollingFootball" text="広い通常ルート ／ 狭い橙ルートはスター得点 ×2"/>);
br.render(0, []); fr.render(0, []);
document.querySelector<HTMLButtonElement>('#collect')!.onclick = e => {
  let takeoff = -1, bPoints = 0, fPoints = 0, bEvents: GameEvent[] = [], fEvents: GameEvent[] = [];
  for (let i = 0; i < 300 && !b.over; i++) {
    const jump = takeoff < 0 && obstacle.x - B.playerX <= b.speed * SHORT_GUIDE.apex - obstacle.width / 2;
    if (jump) takeoff = b.time;
    b.update(STEP, { ...emptyInput(), jump, touchJump: { held: takeoff < 0 || b.time - takeoff < SHORT_GUIDE_HOLD } });
    bEvents.push(...b.events.splice(0));
    bPoints = bEvents.filter(event => event.reward === 'landing').reduce((sum, event) => sum + event.points!, 0);
    if (bPoints >= 36) break;
  }
  for (let i = 0, collected = 0; i < 600 && !f.over && collected < 3; i++) {
    const target = choiceRouteX(choice, f.distance + f.speed * STEP);
    f.update(STEP, { ...emptyInput(), axis: clamp((target - f.x) / (F.steeringSensitivity * STEP), -1, 1) });
    const events = f.events.splice(0); fEvents.push(...events);
    collected += events.filter(event => event.reward === 'double').length;
  }
  fPoints = fEvents.filter(event => event.reward === 'double').reduce((sum, event) => sum + event.points!, 0);
  if (!bPoints || !fPoints || b.over || f.over) throw Error('Reward fixture did not collect safely');
  bf.render(<RewardFeedback notice={{ kind: 'landing', points: bPoints, serial: 1 }}/>);
  ff.render(<RewardFeedback notice={{ kind: 'double', points: fPoints, serial: 1 }}/>);
  br.render(.016, bEvents); fr.render(.016, fEvents);
  (e.currentTarget as HTMLButtonElement).disabled = true;
};
addEventListener('resize', () => { br.resize(); fr.resize(); br.render(0, []); fr.render(0, []); });
