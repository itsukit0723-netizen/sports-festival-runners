import { BasketballModel, isRunnerPickup } from '../../src/games/basketball/model';
import { BasketballRenderer } from '../../src/games/basketball/renderer';
import { FootballModel } from '../../src/games/football/model';
import { FootballRenderer } from '../../src/games/football/renderer';
import { BASKETBALL as B, FOOTBALL as F, STEP } from '../../src/core/config';
import { emptyInput, type GameEvent } from '../../src/core/types';
const seed = Number(new URLSearchParams(location.search).get('seed')) || 12;
const b = new BasketballModel(seed), f = new FootballModel(seed);
let bEvents: GameEvent[] = [], fEvents: GameEvent[] = [], paused = false, mode = '通常';
function advance() {
  const o = b.objects.find(o => !isRunnerPickup(o) && o.x + o.width > B.playerX - B.radius);
  const jump = !!o && o.x - B.playerX <= b.speed * B.jumpForce / B.gravity - o.width / 2 && o.x > B.playerX && b.y >= B.ground - B.radius - .5;
  b.update(STEP, { ...emptyInput(), jump, testInvincible: true });
  const dx = f.nextChallengeRow().safeX - f.x;
  f.update(STEP, { ...emptyInput(), axis: Math.abs(dx) < .06 ? 0 : Math.sign(dx), testInvincible: true });
  bEvents.push(...b.events.splice(0)); fEvents.push(...f.events.splice(0));
}
for (let i = 0; i < 20 / STEP; i++) advance(); bEvents = []; fEvents = [];
const br = new BasketballRenderer(document.querySelector('#b')!, b), fr = new FootballRenderer(document.querySelector('#f')!, f);
let lastFork = -1;
document.querySelector('#fork')!.addEventListener('click', () => {
  for (let i = 0; i < 90 / STEP; i++) {
    advance(); bEvents = []; fEvents = [];
    const fork = f.chunks.find(chunk => chunk.choice && chunk.id !== lastFork && chunk.rows[1].z - f.distance > 12 && chunk.rows[1].z - f.distance < 18);
    if (fork && f.time > 16) { lastFork = fork.id; break; }
  }
  paused = true; mode = '分岐プレビュー'; document.querySelector('#pause')!.textContent = '再開';
});
let edge = 1;
document.querySelector('#edge')!.addEventListener('click', () => {
  edge *= -1; f.x = edge * (F.courseWidth / 2 - F.ballRadius - .08); paused = true;
  document.querySelector('#pause')!.textContent = '再開';
  (document.querySelector('#f') as HTMLCanvasElement).style.height = '650px'; fr.resize();
  mode = `縦長画面・${edge < 0 ? '左端' : '右端'}`;
});
document.querySelector('#normal')!.addEventListener('click', () => { b.boost = b.fever = f.boost = 0; mode = '通常'; });
document.querySelector('#boost')!.addEventListener('click', () => { b.boost = f.boost = 60; bEvents.push({ kind: 'boost' }); fEvents.push({ kind: 'boost' }); mode = '加速プレビュー'; });
document.querySelector('#impact')!.addEventListener('click', () => { bEvents.push({ kind: 'near', x: B.playerX, y: b.y }); fEvents.push({ kind: 'dribble' }); });
document.querySelector('#pause')!.addEventListener('click', e => {
  paused = !paused; (e.currentTarget as HTMLButtonElement).textContent = paused ? '再開' : '比較用に止める';
  const before = JSON.stringify([b, f]); br.render(0, []); fr.render(0, []);
  if (JSON.stringify([b, f]) !== before) throw Error('Renderer mutated gameplay model');
});
let last = 0, accumulator = 0, frameTime = 0, frames = 0, fps = 0;
function frame(time: number) {
  const dt = last ? Math.min(.05, (time - last) / 1000) : 0; last = time;
  if (!paused) { accumulator += dt; while (accumulator >= STEP) { advance(); accumulator -= STEP; } }
  br.render(paused ? 0 : dt, bEvents); fr.render(paused ? 0 : dt, fEvents); bEvents = []; fEvents = [];
  frameTime += dt; frames++; if (frameTime > 1) { fps = Math.round(frames / frameTime); frames = 0; frameTime = 0; }
  document.querySelector('#status')!.textContent = `${mode} / ${fps} FPS / ${paused ? '停止・モデル不変 OK' : '再生中'}`;
  requestAnimationFrame(frame);
}
requestAnimationFrame(frame);
