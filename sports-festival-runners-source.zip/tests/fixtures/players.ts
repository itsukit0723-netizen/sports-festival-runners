import * as THREE from 'three';
import { BlenderPlayers } from '../../src/games/football/blender-players';
const canvas=document.querySelector('canvas')!,scene=new THREE.Scene();scene.background=new THREE.Color('#263747');
const renderer=new THREE.WebGLRenderer({canvas,antialias:true});renderer.setPixelRatio(Math.min(devicePixelRatio,1.65));renderer.setSize(canvas.clientWidth,660,false);
const camera=new THREE.PerspectiveCamera(35,canvas.clientWidth/660,.1,30);camera.position.set(1.3,1.4,4.8);camera.lookAt(.25,.95,0);
scene.add(new THREE.HemisphereLight('#c6d8ed','#283a3d',1.65));const light=new THREE.DirectionalLight('#ffe1b4',2.4);light.position.set(-8,16,9);scene.add(light);const rim=new THREE.DirectionalLight('#9cbbdf',1.1);rim.position.set(6,8,-20);scene.add(rim);
const floor=new THREE.Mesh(new THREE.PlaneGeometry(30,30),new THREE.MeshStandardMaterial({color:'#344a4c',roughness:1}));floor.rotation.x=-Math.PI/2;floor.position.y=.005;scene.add(floor);
new BlenderPlayers((athlete,ball,hazard)=>{const person=athlete.clone(true);person.position.x=-.65;scene.add(person);const b=ball.clone(true);b.scale.setScalar(.28);b.position.set(.55,.28,.4);b.rotation.set(.2,.2,.2);scene.add(b);const h=hazard.clone(true);h.scale.setScalar(.42);h.position.set(1.35,.42,-.35);h.rotation.set(.3,.5,.4);scene.add(h);canvas.dataset.asset='blender';});
function frame(){renderer.render(scene,camera);requestAnimationFrame(frame);}frame();
