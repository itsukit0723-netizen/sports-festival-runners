import {BasketballModel} from '../../src/games/basketball/model';import {BasketballRenderer} from '../../src/games/basketball/renderer';
import {FootballModel} from '../../src/games/football/model';import {FootballRenderer} from '../../src/games/football/renderer';
import {STACCATO_PATTERNS} from '../../src/games/basketball/patterns';import {STEP} from '../../src/core/config';import {emptyInput,type GameEvent} from '../../src/core/types';import {skilledBasketballInput} from '../helpers/basketball-player';
let b=new BasketballModel(1),f=new FootballModel(1),br=new BasketballRenderer(document.querySelector('#b')!,b);const fr=new FootballRenderer(document.querySelector('#f')!,f);
let golden=true,paused=false,full=false,last=0,acc=0,frames=0,fps=0,second=0;let be:GameEvent[]=[],fe:GameEvent[]=[];
br.setGolden(true);fr.setGolden(true);
const err=document.querySelector('#errors')!;
window.addEventListener('error',e=>err.textContent='ERROR: '+e.message);window.addEventListener('unhandledrejection',e=>err.textContent='ERROR: '+e.reason);
document.querySelector('#stage')!.addEventListener('click',()=>{golden=!golden;br.setGolden(golden);fr.setGolden(golden);document.querySelector('#stage')!.textContent=golden?'通常ステージに切替':'ゴールデンタイムに切替';});
function reset(fullJump:boolean) {
 br.dispose();b=new BasketballModel(1);b.time=35;full=fullJump;
 Object.assign(b,{obstacleIn:100,coinIn:100,itemIn:100,nextBonus:10000,opening:false});b['staccato'](STACCATO_PATTERNS[14]);Object.assign(b,{obstacleIn:100});
 br=new BasketballRenderer(document.querySelector('#b')!,b);br.setGolden(golden);be=[];paused=false;document.querySelector('#pause')!.textContent='停止';
}
document.querySelector('#tap')!.addEventListener('click',()=>reset(false));document.querySelector('#full')!.addEventListener('click',()=>reset(true));
document.querySelector('#pause')!.addEventListener('click',()=>{paused=!paused;document.querySelector('#pause')!.textContent=paused?'再開':'停止';});
function frame(now:number) {
 const dt=last?Math.min(.05,(now-last)/1000):0;last=now;second+=dt;frames++;if(second>=1){fps=frames/second;frames=0;second=0;}
 if(!paused) {
  acc+=dt;
  while(acc>=STEP) {
   const input=skilledBasketballInput(b);b.update(STEP,full?{...input,shortJump:false}:input);be.push(...b.events.splice(0));
   const dx=f.nextChallengeRow().safeX-f.x;f.update(STEP,{...emptyInput(),axis:Math.abs(dx)<.06?0:Math.sign(dx)});fe.push(...f.events.splice(0));acc-=STEP;
  }
 }
 br.render(paused?0:dt,be);fr.render(paused?0:dt,fe);be=[];fe=[];
 document.querySelector('#bs')!.textContent=`${golden?'GOLDEN':'NORMAL'} / ${full?'FULL JUMP':'SHORT JUMP'}\ntime=${b.time.toFixed(2)}s / ${b.over?'衝突':'生存'} / pattern=${b.coursePattern} / objects=${b.objects.length}`;
 const info=fr['renderer'].info.render;
 document.querySelector('#fs')!.textContent=`${golden?'GOLDEN':'NORMAL'} / time=${f.time.toFixed(2)}s / ${f.over?'衝突':'生存'}\nFPS=${fps.toFixed(1)} / draws=${info.calls} / triangles=${info.triangles}`;
 requestAnimationFrame(frame);
}
requestAnimationFrame(frame);
