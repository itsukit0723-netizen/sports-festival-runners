import React from 'react';
import { createRoot } from 'react-dom/client';
import GameView from '../../src/ui/GameView';
import '../../src/styles.css';
createRoot(document.querySelector('#root')!).render(<GameView id="rollingFootball" best={0} sound={false} onToggleSound={()=>{}} onHome={()=>{}} onBest={()=>{}}/>);
document.querySelector('#pause-test')!.addEventListener('click',()=>{for(let i=0;i<10;i++){window.dispatchEvent(new Event('blur'));window.dispatchEvent(new Event('focus'));}});
