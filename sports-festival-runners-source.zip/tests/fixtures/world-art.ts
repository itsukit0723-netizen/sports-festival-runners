import { FootballModel } from '../../src/games/football/model';
import { FootballRenderer } from '../../src/games/football/renderer';
import { WORLDS, WORLD_IDS } from '../../src/games/football/worlds';
import { STEP } from '../../src/core/config';
import { emptyInput } from '../../src/core/types';
const model = new FootballModel(2);
while(model.time < 22) { const dx = model.nextChallengeRow().safeX - model.x; model.update(STEP,{...emptyInput(), axis:Math.abs(dx)<.06?0:Math.sign(dx),testInvincible:true}); model.events.length=0; }
const renderer = new FootballRenderer(document.querySelector('canvas')!,model);
let galleryMode = false, frozen = false, last = 0, time = 0, frames = 0;
for(const world of WORLD_IDS) { const b=document.createElement('button'); b.textContent=WORLDS[world].name; b.onclick=()=>{model.world=world;document.querySelector('#status')!.textContent=WORLDS[world].name+' / 立体造形の確認';for(let i=0;i<40;i++)renderer.render(.05,[]);}; document.querySelector('#worlds')!.append(b); }
const stop=document.createElement('button');stop.textContent='動きを止める';stop.onclick=()=>{frozen=!frozen;stop.textContent=frozen?'動きを再開':'動きを止める';};document.querySelector('#worlds')!.append(stop);
function frame(t:number){const dt=last?Math.min(.05,(t-last)/1000):0;last=t;renderer.render(frozen?0:dt,[]);time+=dt;frames++;if(time>1 && !galleryMode){document.querySelector('#status')!.textContent=`${WORLDS[model.world].name} / ${Math.round(frames/time)} FPS / 入力・難易度・カメラは製品と共通`;time=frames=0;}requestAnimationFrame(frame);}requestAnimationFrame(frame);

const compare=document.createElement('button');compare.textContent='5世界を比較';compare.onclick=()=>{
 galleryMode=true;frozen=true;const gallery=document.querySelector('#gallery')!;gallery.replaceChildren();
 for(const world of WORLD_IDS){model.world=world;for(let i=0;i<40;i++)renderer.render(.05,[]);const card=document.createElement('article');const h=document.createElement('h2');h.textContent=WORLDS[world].name;const img=document.createElement('img');img.src=(document.querySelector('canvas') as HTMLCanvasElement).toDataURL();img.alt=WORLDS[world].name+'の実レンダラー画像';card.append(h,img);gallery.append(card);}
 document.querySelector('main')!.style.display='none';document.querySelector('#status')!.textContent='5世界 / 同じコース・同じカメラで比較';
};document.querySelector('#worlds')!.append(compare);
