import { createElement } from 'react';
import { createRoot } from 'react-dom/client';
import { WorldArrival } from '../../src/ui/WorldArrival';
import { FootballModel } from '../../src/games/football/model';
import { FootballRenderer } from '../../src/games/football/renderer';
import { WORLDS, WORLD_IDS } from '../../src/games/football/worlds';
import { STEP } from '../../src/core/config';
import { emptyInput } from '../../src/core/types';
import { motionOffset } from '../../src/games/football/chunks';
let rollerMotion=false;
const model = new FootballModel(2);
while(model.time < 22) { const dx = model.nextChallengeRow().safeX - model.x; model.update(STEP,{...emptyInput(), axis:Math.abs(dx)<.06?0:Math.sign(dx),testInvincible:true}); model.events.length=0; }
const renderer = new FootballRenderer(document.querySelector('canvas')!,model);
const rollerButton=document.createElement('button');rollerButton.textContent='動く障害物ボールを確認';rollerButton.onclick=()=>{
 for(let i=0;i<120/STEP;i++){
  const dx=model.nextChallengeRow().safeX-model.x;model.update(STEP,{...emptyInput(),axis:Math.abs(dx)<.06?0:Math.sign(dx),testInvincible:true});model.events.length=0;
  if(model.chunks.some(c=>c.objects.some(o=>o.type==='roller'&&o.z-model.distance>5&&o.z-model.distance<9)))break;
 }
 frozen=false;rollerMotion=true;document.querySelector('#status')!.textContent='障害物ボール / 同じ当たり判定・実コース';
};document.querySelector('#worlds')!.append(rollerButton);
const personButton=document.createElement('button');personButton.textContent='人とボールをゲーム内で確認';personButton.onclick=()=>{
 for(let i=0;i<120/STEP;i++){
  const dx=model.nextChallengeRow().safeX-model.x;model.update(STEP,{...emptyInput(),axis:Math.abs(dx)<.06?0:Math.sign(dx),testInvincible:true});model.events.length=0;
  if(model.chunks.some(c=>c.objects.some(o=>o.type==='defender'&&o.z-model.distance>5&&o.z-model.distance<7)))break;
 }
 frozen=true;document.querySelector('#status')!.textContent='実コースの人・ボール / 操作・当たり判定は共通';
};document.querySelector('#worlds')!.append(personButton);
let galleryMode = false, frozen = false, last = 0, time = 0, frames = 0;
for(const world of WORLD_IDS) { const b=document.createElement('button'); b.textContent=WORLDS[world].name; b.onclick=()=>{model.world=world;document.querySelector('#status')!.textContent=WORLDS[world].name+' / 立体造形の確認';for(let i=0;i<40;i++)renderer.render(.05,[]);}; document.querySelector('#worlds')!.append(b); }
const stop=document.createElement('button');stop.textContent='動きを止める';stop.onclick=()=>{frozen=!frozen;stop.textContent=frozen?'動きを再開':'動きを止める';};document.querySelector('#worlds')!.append(stop);
function frame(t:number){const dt=last?Math.min(.05,(t-last)/1000):0;last=t;
 if(rollerMotion&&!frozen){model.time+=dt;for(const c of model.chunks)for(const o of c.objects)if(o.moving)o.x=o.baseX+motionOffset(o,model.time);}
 renderer.render(frozen?0:dt,[]);const canvas=document.querySelector('canvas') as HTMLCanvasElement;canvas.dataset.asset=renderer.worldModelReady?'blender':'loading';canvas.dataset.players=renderer.playerModelReady?'blender':'loading';canvas.dataset.rollers=JSON.stringify(model.chunks.flatMap(c=>c.objects.filter(o=>o.type==='roller').map(o=>({x:o.x,base:o.baseX,amplitude:o.amplitude}))));time+=dt;frames++;if(time>1 && !galleryMode){document.querySelector('#status')!.textContent=`${WORLDS[model.world].name} / ${Math.round(frames/time)} FPS / 入力・難易度・カメラは製品と共通`;time=frames=0;}requestAnimationFrame(frame);}requestAnimationFrame(frame);

const compare=document.createElement('button');compare.textContent='5世界を比較';compare.onclick=()=>{
 const before=model.world;for(const world of WORLD_IDS){model.world=world;if(!renderer.worldModelReady){model.world=before;document.querySelector('#status')!.textContent='Blenderモデルを準備中';return;}}model.world=before;
 galleryMode=true;frozen=true;const gallery=document.querySelector('#gallery')!;gallery.replaceChildren();
 for(const world of WORLD_IDS){model.world=world;for(let i=0;i<40;i++)renderer.render(.05,[]);const card=document.createElement('article');const h=document.createElement('h2');h.textContent=WORLDS[world].name;const img=document.createElement('img');img.src=(document.querySelector('canvas') as HTMLCanvasElement).toDataURL();img.alt=WORLDS[world].name+'の実レンダラー画像';card.append(h,img);gallery.append(card);}
 document.querySelector('main')!.style.display='none';document.querySelector('#status')!.textContent='5世界 / 同じコース・同じカメラで比較';
};document.querySelector('#worlds')!.append(compare);

const arrivalRoot=createRoot(document.querySelector('#arrival-overlay')!);let arrivalSerial=0;
const effect=document.createElement('button');effect.textContent='世界切替の演出を確認';effect.onclick=()=>{
 model.world=WORLD_IDS[(WORLD_IDS.indexOf(model.world)+1)%WORLD_IDS.length];for(let i=0;i<40;i++)renderer.render(.05,[]);
 frozen=true;arrivalRoot.render(createElement(WorldArrival,{arrival:{world:model.world,serial:++arrivalSerial}}));
 document.querySelector('#status')!.textContent=WORLDS[model.world].name+' / 切り替え演出・0.2秒地点';
};document.querySelector('#worlds')!.append(effect);
