import test from 'node:test';import assert from 'node:assert/strict';
import {captureGolden,goldenScore,goldenRecord,goldenAtStart,configureGoldenReader,GOLDEN_OFF} from '../src/golden/policy';
import {getBest,saveBest} from '../src/core/storage';
test('Golden ON/OFF is sampled afresh for every start, while existing runs retain their snapshot',async()=>{
 let setting={enabled:false,eventId:'none',revision:'r0',updatedAt:1};let reads=0;
 configureGoldenReader(async()=>{reads++;return setting;});
 const normal=await goldenAtStart();setting={enabled:true,eventId:'festival-1',revision:'r1',updatedAt:2};
 const golden=await goldenAtStart();setting.enabled=false;setting.revision='r2';
 const after=await goldenAtStart();assert.equal(reads,3);assert.equal(normal.multiplier,1);assert.equal(golden.multiplier,2);assert.equal(after.multiplier,1);
 assert.equal(golden.revision,'r1');assert.equal(golden.eventId,'festival-1');assert.ok(Object.isFrozen(golden));
 assert.equal(goldenScore(123.9,golden),246);assert.equal(goldenScore(123.9,normal),123);assert.deepEqual(goldenRecord(123.9,golden),{golden:true,baseScore:123,scoreMultiplier:2,goldenEventId:'festival-1',goldenRevision:'r1',score:246});
 configureGoldenReader(async()=>{throw Error('offline');});await assert.rejects(goldenAtStart(),/offline/);configureGoldenReader(async()=>null);assert.deepEqual(await goldenAtStart(),GOLDEN_OFF);
});
test('Malformed shared settings cannot silently start an incorrectly scored event',()=>{
 for(const bad of [{enabled:'true'},{enabled:true,eventId:'x',revision:'r',updatedAt:NaN},{enabled:true,eventId:'',revision:'r',updatedAt:2}])assert.throws(()=>captureGolden(bad));
});
test('Golden BEST never overwrites normal BEST, and legacy normal records remain readable',()=>{
 const data=new Map<string,string>();Object.assign(globalThis,{localStorage:{getItem:(k:string)=>data.get(k)??null,setItem:(k:string,v:string)=>data.set(k,v)}});
 saveBest('basketballRunner',100);saveBest('basketballRunner',600,true);saveBest('basketballRunner',70);
 assert.equal(getBest('basketballRunner'),100);assert.equal(getBest('basketballRunner',true),600);assert.equal(getBest('rollingFootball'),0);
});
