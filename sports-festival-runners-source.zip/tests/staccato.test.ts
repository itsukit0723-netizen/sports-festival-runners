import test from 'node:test';import assert from 'node:assert/strict';
import {BasketballModel,isRunnerPickup,runnerPickupClear} from '../src/games/basketball/model';
import {STACCATO_PATTERNS,JUMP_PATTERNS} from '../src/games/basketball/patterns';
import {BASKETBALL as B,STEP} from '../src/core/config';import {emptyInput} from '../src/core/types';
import {skilledBasketballInput} from './helpers/basketball-player';
function phrase(index:number,time:number,boost:number) {
 const m=new BasketballModel(1);m.time=time;m.boost=boost;
 Object.assign(m,{obstacleIn:100,coinIn:100,itemIn:100,nextBonus:10000,opening:false});
 m['staccato'](STACCATO_PATTERNS[index]);
 // Only this phrase is simulated, while its actual collision and pickup paths run.
 Object.assign(m,{obstacleIn:100});return m;
}
test('108 small-jump phrases occupy half the deck and have distinct physical rhythms',()=>{
 assert.equal(STACCATO_PATTERNS.length,108);assert.equal(JUMP_PATTERNS.length,216);
 assert.equal(new Set(STACCATO_PATTERNS.map(p=>JSON.stringify(p.staccato))).size,108);
 for(const p of STACCATO_PATTERNS){assert.ok(p.beats.length>=5&&p.beats.length<=8);assert.equal(p.staccato!.gaps.length,p.beats.length-1);assert.ok(p.staccato!.gaps.every(t=>t>=.59&&t<=.65));}
});
test('Every tap phrase is clearable at all speed stages, including BOOST expiry mid-phrase',()=>{
 let cleared=0;
 for(let index=0;index<108;index++)for(const time of [16,30,50,120,600])for(const boost of [0,2,12]) {
  const m=phrase(index,time,boost),ids=new Set(m.objects.filter(o=>!isRunnerPickup(o)).map(o=>o.id));
  for(let i=0;i<12/STEP&&!m.over&&m.objects.some(o=>ids.has(o.id));i++) {
   for(const pickup of m.objects.filter(isRunnerPickup))assert.ok(runnerPickupClear(pickup.x,pickup.y,m.objects));
   m.update(STEP,skilledBasketballInput(m));m.events.length=0;
  }
  assert.equal(m.over,false,`tap ${index} at ${time}s boost ${boost}, y=${m.y}`);
  assert.ok(!m.objects.some(o=>ids.has(o.id)));cleared++;
 }
 assert.equal(cleared,1620);
});
test('Full jumps hit the visible overhead rail, while staying grounded hits the small hurdles',()=>{
 for(let index=0;index<108;index++)for(const mode of ['full','none']) {
  const m=phrase(index,35,0);
  for(let i=0;i<10/STEP&&!m.over;i++){const input=skilledBasketballInput(m);m.update(STEP,mode==='full'?{...input,shortJump:false}:emptyInput());m.events.length=0;}
  assert.ok(m.over,`tap ${index}, ${mode} unexpectedly skipped the phrase`);
 }
});
test('Real short-touch holds can complete the phrases without a keyboard shortcut',()=>{
 for(const hold of [.025,.05,.08])for(let index=0;index<108;index++) {
  const m=phrase(index,55,0),ids=new Set(m.objects.filter(o=>!isRunnerPickup(o)).map(o=>o.id));let launch=-100;
  for(let i=0;i<12/STEP&&!m.over&&m.objects.some(o=>ids.has(o.id));i++) {
   const input=skilledBasketballInput(m,hold);if(input.jump)launch=m.time;
   m.update(STEP,{...input,touchJump:{held:m.time-launch<hold}});m.events.length=0;
  }
  assert.ok(!m.over,`touch hold ${hold}, phrase ${index}`);
  assert.ok(!m.objects.some(o=>ids.has(o.id)));
 }
});
test('Short keyboard jumps match immediate-release touch taps exactly',()=>{
 const keyboard=new BasketballModel(1),touch=new BasketballModel(1);
 for(let i=0;i<80;i++) {
  keyboard.update(STEP,{...emptyInput(),jump:i===0,shortJump:i===0});
  touch.update(STEP,{...emptyInput(),jump:i===0,touchJump:{held:false}});
  assert.equal(keyboard.y,touch.y);assert.equal(keyboard.vy,touch.vy);
 }
});
test('FEVER destroys a long overhead rail once without repeated smash scores',()=>{
 const m=phrase(0,35,0),beam=m.objects.find(o=>o.type==='beam')!;
 m.objects=[beam];beam.x=B.playerX-30;m.y=beam.y+beam.height+8;m.fever=2;let smashes=0;
 for(let i=0;i<30;i++){m.update(STEP,emptyInput());smashes+=m.events.filter(e=>e.kind==='smash').length;m.events.length=0;}
 assert.equal(smashes,1);assert.ok(!m.objects.includes(beam));assert.equal(m.over,false);
});
