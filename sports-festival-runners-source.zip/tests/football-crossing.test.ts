import {test} from 'node:test';
import assert from 'node:assert/strict';
import {FootballModel} from '../src/games/football/model';
import {planRows,fillChunk,routeX,motionOffset,courseCollision,coursePickupClear,type Chunk,type CourseObject} from '../src/games/football/chunks';
import {FOOTBALL as F,STEP} from '../src/core/config';
import {Random,emptyInput} from '../src/core/types';

test('Large dodge phrases require a broad crossing but leave steering time at BOOST speed',()=>{
 for(const speed of [24,35,44])for(const x of [-2.5,0,2.5])for(const kind of ['mediumCrossing','hardCrossing'] as const){
  const entry={z:-2.2,safeX:x,gap:2.3},rows=planRows(0,kind,2.3,entry,new Random(4),false,undefined,speed);
  assert.equal(rows.length,2);assert.ok(Math.abs(rows[1].safeX-rows[0].safeX)>2);
  const path=[entry,...rows];for(let i=1;i<path.length;i++){
   const capacity=(path[i].z-path[i-1].z-2*F.route.rowClearance)/(speed*F.boostMultiplier)*F.steeringSensitivity;
   assert.ok(Math.abs(path[i].safeX-path[i-1].safeX)<=capacity*.81);
  }
  for(const variant of [0,1]){
   const chunk:Chunk={id:0,start:0,kind,rows,safeX:rows[1].safeX,gap:2.3,objects:[],variant};let id=0;
   fillChunk(chunk,(type,x,z,width,depth,height):CourseObject=>({id:id++,type,x,baseX:x,z,width,depth,height,moving:false,amplitude:0,frequency:0,phase:0,passed:false}));
   assert.ok(chunk.objects.some(o=>o.type==='roller'&&o.width===2.2));assert.ok(chunk.objects.some(o=>o.type==='slider'));
   for(const star of chunk.objects.filter(o=>o.type==='star'))assert.ok(coursePickupClear(star.x,star.z,chunk.objects));
   for(let t=0;t<6;t+=.15)for(const o of chunk.objects.filter(o=>o.type!=='star')){
    o.x=o.baseX+motionOffset(o,t);
    for(let z=rows[0].z-2;z<rows[1].z+2;z+=.2)assert.equal(courseCollision(o,routeX(rows,z),z,t),false,`${kind}/${o.type} blocks the route`);
   }
  }
 }
});

test('Actual courses introduce recurring large dodges after the fixed opening with a readable recovery',()=>{
 for(const seed of [1,2,99]){
  const m=new FootballModel(seed),seen=new Map<number,Chunk>();
  for(let i=0;i<90/STEP;i++){
   for(const c of m.chunks)if(c.kind.endsWith('Crossing')){assert.ok(c.start>=12*F.chunkLength);seen.set(c.id,c);}
   const dx=m.nextChallengeRow().safeX-m.x;m.update(STEP,{...emptyInput(),axis:Math.abs(dx)<.06?0:Math.sign(dx),testInvincible:true});m.events.length=0;
  }
  assert.ok(seen.size>=4,`seed ${seed} needs recurring large dodges`);
  for(const c of seen.values())assert.ok(Math.abs(c.rows[1].safeX-c.rows[0].safeX)>1.8);
 }
});
