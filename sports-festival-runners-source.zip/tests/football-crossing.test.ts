import {test} from 'node:test';
import assert from 'node:assert/strict';
import {FootballModel} from '../src/games/football/model';
import {planRows,fillChunk,routeX,motionOffset,courseCollision,coursePickupClear,crossingStyle,CROSSING_STYLES,type Chunk,type CourseObject} from '../src/games/football/chunks';
import {FOOTBALL as F,STEP} from '../src/core/config';
import {Random,emptyInput} from '../src/core/types';

test('Large dodge phrases require a broad crossing but leave steering time at BOOST speed',()=>{
 for(const speed of [24,35,44])for(const x of [-2.5,0,2.5])for(const kind of ['mediumCrossing','hardCrossing'] as const){
  const entry={z:-2.2,safeX:x,gap:2.3},rows=planRows(0,kind,2.3,entry,new Random(4),false,undefined,speed);
  assert.equal(rows.length,2);assert.ok(Math.abs(rows[1].safeX-rows[0].safeX)>2);
  const path=[entry,...rows];for(let i=1;i<path.length;i++){
   const capacity=(path[i].z-path[i-1].z-2*F.route.rowClearance)/(speed*F.boostMultiplier)*F.steeringSensitivity;
   assert.ok(Math.abs(path[i].safeX-path[i-1].safeX)<=capacity*.81);
  }
  for(let variant=0;variant<12;variant++){
   const chunk:Chunk={id:0,start:0,length:rows[1].z+5,kind,rows:rows.map(r=>({...r})),safeX:rows[1].safeX,gap:2.3,objects:[],variant};let id=0;
   fillChunk(chunk,(type,x,z,width,depth,height):CourseObject=>({id:id++,type,x,baseX:x,z,width,depth,height,moving:false,amplitude:0,frequency:0,phase:0,passed:false}));
   const style=crossingStyle(chunk);
   if(style==='ballWall')assert.ok(chunk.objects.some(o=>o.type==='roller'&&o.width===2.2));
   if(style==='doubleBall'){
    const balls=chunk.objects.filter(o=>o.type==='roller');assert.equal(balls.length,2);
    assert.ok(balls.every(o=>o.width===3&&o.frequency>=3.1));assert.ok(chunk.rows.every(r=>r.gap===1.05));
    assert.ok(balls[0].baseX*balls[1].baseX<0);
   }
   if(style==='slidingGates')assert.ok(chunk.objects.filter(o=>o.type==='slider').length>=2);
   if(style==='defenderWall')assert.ok(chunk.objects.some(o=>o.type==='defender'&&o.moving));
   if(style==='rotorWall')assert.ok(chunk.objects.some(o=>o.type==='rotor'&&o.width===2.6));
   if(style==='postChicane')assert.ok(chunk.objects.filter(o=>o.type==='pillar').length>=6);
   for(const star of chunk.objects.filter(o=>o.type==='star'))assert.ok(coursePickupClear(star.x,star.z,chunk.objects));
   for(let t=0;t<6;t+=.15)for(const o of chunk.objects.filter(o=>o.type!=='star')){
    o.x=o.baseX+motionOffset(o,t);
    for(let z=rows[0].z-4;z<rows[1].z+3;z+=.2)assert.equal(courseCollision(o,routeX(rows,z),z,t),false,`${kind}/${o.type} blocks the route`);
   }
  }
 }
});

test('Every sway style forces both edge exits instead of allowing a central shortcut',()=>{
 for(let variant=0;variant<12;variant++){
  const rows=planRows(0,'hardCrossing',2.05,{z:-2.2,safeX:0,gap:2.3},new Random(1),false,undefined,44);
  const c:Chunk={id:0,start:0,length:rows[1].z+5,kind:'hardCrossing',rows,safeX:rows[1].safeX,gap:1.05,objects:[],variant};let id=0;
  fillChunk(c,(type,x,z,width,depth,height):CourseObject=>({id:id++,type,x,baseX:x,z,width,depth,height,moving:false,amplitude:0,frequency:0,phase:0,passed:false}));
  assert.deepEqual(rows.map(r=>Math.abs(r.safeX)),[3.45,3.45]);
  for(const row of rows){
   const rail=c.objects.find(o=>o.type==='wall'&&Math.abs(o.z-(row.z-2.4))<1e-6)!;assert.ok(rail);
   for(let x=-3.9;x<=3.9;x+=.1)if(Math.sign(row.safeX)*x<=3.2)assert.ok(courseCollision(rail,x,rail.z,0));
   assert.equal(courseCollision(rail,row.safeX,rail.z,0),false);
  }
 }
});

test('Actual courses introduce recurring large dodges after the fixed opening with a readable recovery',()=>{
 for(const seed of [1,2,99]){
  const m=new FootballModel(seed),seen=new Map<number,Chunk>();
  for(let i=0;i<90/STEP;i++){
   for(const c of m.chunks)if(c.kind.endsWith('Crossing')){assert.ok(c.start>=12*F.chunkLength);seen.set(c.id,c);}
   const dx=m.nextChallengeRow().safeX-m.x;m.update(STEP,{...emptyInput(),axis:Math.abs(dx)<.06?0:Math.sign(dx),testInvincible:true});m.events.length=0;
  }
  assert.ok(seen.size>=8,`seed ${seed} needs frequent large dodges`);
  const styles=[...seen.values()].map(crossingStyle);assert.ok(new Set(styles).size>=4);
  const firstHard=[...seen.values()].find(c=>c.kind==='hardCrossing');assert.ok(firstHard);assert.equal(crossingStyle(firstHard),'doubleBall');
  const hardStyles=[...seen.values()].filter(c=>c.kind==='hardCrossing').map(crossingStyle);
  assert.ok(hardStyles.filter(s=>s==='doubleBall').length>=Math.floor(hardStyles.length/2));
  for(let i=1;i<styles.length;i++)assert.notEqual(styles[i],styles[i-1]);
  for(const c of seen.values())assert.ok(Math.abs(c.rows[1].safeX-c.rows[0].safeX)>1.8);
 }
});

test('Double giant balls are reserved for hard crossings; all six obstacle combinations are available',()=>{
 const medium=new Set(Array.from({length:30},(_,variant)=>crossingStyle({id:0,kind:'mediumCrossing',variant})));
 const hard=new Set(Array.from({length:30},(_,variant)=>crossingStyle({id:0,kind:'hardCrossing',variant})));
 assert.ok(!medium.has('doubleBall'));assert.deepEqual([...hard].sort(),[...CROSSING_STYLES].sort());
});

test('Ordinary post-opening routes ask for more steering while preserving a conservative BOOST budget',()=>{
 let oldTravel=0,newTravel=0;
 for(let seed=1;seed<=30;seed++){
  const entry={z:-4,safeX:0,gap:2.48};
  const oldRows=planRows(0,'mediumWalls',2.48,entry,new Random(seed));
  const rows=planRows(0,'mediumWalls',2.48,entry,new Random(seed),false,undefined,24);
  for(const [path,old] of [[[entry,...oldRows],true],[[entry,...rows],false]] as const)for(let i=1;i<path.length;i++){
   const distance=Math.abs(path[i].safeX-path[i-1].safeX);if(old)oldTravel+=distance;else newTravel+=distance;
   if(!old)assert.ok(distance<=(path[i].z-path[i-1].z-2*F.route.rowClearance)/(24*F.boostMultiplier)*F.steeringSensitivity*.86);
  }
 }
 assert.ok(newTravel>oldTravel*1.2);
});
