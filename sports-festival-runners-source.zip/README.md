# SPORTS FESTIVAL ARCADE

高校のスポーツフェスティバル向け、単独起動できる2つの無限ランゲームです。
React / TypeScript / Vite、バスケはCanvas 2D、サッカーはThree.jsによる3D描画を使用します。
画像・3D形状・効果音はコードで生成し、欧文フォントも同梱します。実行時の外部APIやCDNは不要です。

## 起動

Node.js 22.12以上を使用してください。

```powershell
npm.cmd install
npm.cmd run dev
```

表示されたローカルURLを開きます。Windowsでは `start-arcade.cmd` をダブルクリックすると、サーバーとブラウザーを起動できます。
`index.html` の直接ダブルクリックではなく、HTTPサーバーを通して利用してください。

## 操作

| ゲーム | スマートフォン | PC |
| --- | --- | --- |
| BASKETBALL RUNNER | 画面をタップしてジャンプ | Space / クリック |
| ROLLING FOOTBALL | 左右へドラッグ | ← → / A D / マウスドラッグ |

どちらも左上のボタン、Esc、Pで一時停止します。別のアプリ・タブへ移ると自動で一時停止します。
一時停止画面と結果画面でサウンドを切り替えられます。BASKETBALLに二段ジャンプはありません。

## ビルド・検証

```powershell
npm.cmd test
npm.cmd run build
npm.cmd run preview
```

参考の合成入力バランス測定：`npm.cmd run balance`。

`dist/` が本番配信用の静的ファイルです。`npm.cmd ci` でロックファイルと同じ依存関係を復元できます。

スマホでテストプレイする場合は、PCとスマホを同じWi-Fi・LANに接続し、`start-mobile.cmd` をダブルクリックします。コマンドからは次を実行します。

```powershell
npm.cmd run mobile
```

本番ビルド後、LAN向けテストサーバーを4173番で起動し、スマホ用URLを表示します。表示された `http://PCのIPv4:4173/` をスマホのSafari / Chromeで開きます。テスト中はPCとサーバーを起動したままにしてください。終了はCtrl+Cです。PCのアドレスが変わった場合は、再起動して新しく表示されたURLを使います。

このサーバーは同じLAN向けで、インターネットには公開しません。学校やゲストWi-Fiの設定で端末間通信が禁止されている場合は、相互に通信できる同じネットワークで試してください。Windowsが通信の許可を表示する場合は、利用するプライベートネットワーク側を選択してください。
本番運用は `dist/` をHTTPSの静的ホスティングへ配置してください。

### GitHub Pages

今回の公開先： https://itsukit0723-netizen.github.io/sports-festival-runners/

公開用リポジトリ： https://github.com/itsukit0723-netizen/sports-festival-runners

このリポジトリには `dist/` の内容をルートへ配置し、Pagesは **Deploy from a branch → main → / (root)** で配信します。更新するときはこの作業フォルダーでビルド後、`index.html`・`favicon.svg`・`.nojekyll`・`assets/`・`licenses/` を同じ構造で置き換えます。ソースコード一式を公開先のルートへそのまま上書きしないでください。

ソースからの自動ビルドへ移行する場合は、次の設定が利用できます。

`.github/workflows/pages.yml` に、テスト・ビルド後にGitHub Pagesへ公開する設定を用意しています。リポジトリの Settings → Pages → Build and deployment → Source で **GitHub Actions** を選び、`main` へソースをpushするかActionsから手動実行します。

公開URLは完了したPages設定画面、またはActionsの `deploy` ジョブのEnvironment URLで確認できます。公開後はPCを起動しておく必要はなく、スマホからHTTPSでアクセスできます。相対パスでビルドするため、リポジトリ名がURLの途中に入る構成にも対応します。

## ゲームの内容

- バスケ：通常速度318〜456、高い障害物（HIGH）・横長のベンチ／マット（LONG）・通常のコーン／ハードルの3系統。約4秒のBOOSTは通常の1.7倍、約4.5秒のFEVERは1.18倍の加速＋無敵破壊＋スコア2倍。コイン列、24枚のBONUS、COMBO、NEAR MISS、残像・破片・スピード線。
- サッカー：通常速度18〜30m/s、左右へ素早くフェイントするディフェンダー、高速スライド壁、狭い壁・穴・回転バー。人物は顔・髪・背番号付きユニフォーム・関節のある手足とフットワークを持つ3Dモデル。スター列、BONUS、BOOST PANEL、FOV変化、残像、NICE DRIBBLE、NEAR MISS。
- 共通：即リトライ、一時停止、合成SE、連続取得時の音程変化、縦画面、safe-area、BEST保存。
- プレイ時間制限はありません。40秒以降も生成・加速・ボーナスが続きます。

## 統合しやすい構成

```text
src/
  App.tsx                        ゲーム選択
  ui/                            React画面 / HUD / 結果
  core/
    config.ts                    ゲームバランス調整値
    director.ts                  生存時間と状態から難易度を選択
    input.ts                     Pointer / キーボード
    audio.ts                     Web Audio合成SE
    storage.ts                   BEST・サウンド設定の永続化
    types.ts                     共通インターフェース・seed付き乱数
  games/
    basketball/model.ts          描画・ブラウザーから独立した状態更新
    basketball/obstacles.ts      通常・高い・横長の障害物定義
    basketball/renderer.ts       Canvas 2D
    football/model.ts            状態更新・生成・プール・衝突
    football/chunks.ts           安全通路付きのチャンクテンプレート
    football/renderer.ts          Three.js・描画プール
    football/defender.ts          人物モデル・関節アニメーション・共有メッシュ
tests/games.test.ts               物理・衝突・安全性・長時間走行
```

ゲーム更新は `requestAnimationFrame` + 1/120秒の固定刻みです。30 / 60 / 120 / 165Hz等でゲーム速度をそろえます。
描画停止時の大きなdeltaは制限し、復帰時の不意の衝突を防ぎます。ReactのHUDは約10Hzで更新します。

### サッカーの生成ルール

26m単位、前方102mまでのチャンクだけを保持します。通常チャンクは3列、Hardは4列で、BONUSを除く全テンプレートの障害物数を以前の3〜8倍にしています。
各列の通路が左右に変わるため、1つの場所に寄ったままの通過が難しくなります。動く壁は対になって動き、各列に安全な通過幅を残します。最大BOOST速度と障害物の奥行きを含めて隣接列・チャンクの継ぎ目を横断できるよう、通路中心の移動量を制限しています。最初に短い助走を取り、開始直後の約6秒は真っ直ぐな経路です。
過ぎたチャンクを破棄し、データと描画オブジェクトを再利用します。危険なチャンクの連続はDirectorで抑制します。

### 保存

```text
sportsFestival.basketballRunner.best
sportsFestival.rollingFootball.best
sportsFestival.sound
```

記録は利用中のブラウザー・オリジンだけに保存されます。端末間の共有ランキングやサーバー保存は含みません。
保存が拒否されるプライベートモードでもゲームは動作します。

## バランスと実機確認

`src/core/config.ts` の速度・ジャンプ・重力・倍率・時間・難易度曲線から調整できます。
バスケは6秒以降に高い障害物、10秒以降に横長を混ぜ、速度と密度を上げます。BOOST／FEVERは横方向の速度だけを上げます。ジャンプの高さ・頂点・落下・着地時刻は通常時と同じです。描画上の回転は毎秒1.7〜2.2radに抑え、縫い目を見やすくしています。横長障害物は従来の約90％（131〜189px）。加速アイテムの直後は次の障害物まで助走を確保します。
サッカーは6秒以降に中難度、18秒以降にHardを混ぜます。密度を3〜4列へ増やした後も、フェイントの合成波形を最大移動幅内に収め、速い壁でも安全通路と次の列までの横断時間を確保します。

自動テストは両ゲーム12seedずつの3分走行、安全通路と最大横断時間、ジャンプ通過幅、衝突、FEVER破壊、BOOST中の衝突、コイン、タイマーを検証します。
検証の詳細と実機で残る確認は `QA.md` に記載します。

**初見の人の平均30〜50秒（中心40秒）は設計目標です。人間の被験者による平均値は未測定です。**
本番前に対象のiPhone Safari / Android Chromeで、初見5〜10人ずつの生存時間と操作感を記録し、曲線を微調整してください。
実機の60fpsも端末別の確認が必要です。

### コイン配置・夜のコート（2026-10-16更新）

バスケは障害物ごとのジャンプ放物線に沿ってコインを並べ、地上列もボールとラベルを含む余白を確保します。障害物が後から生成される場合も既存の取得物と衝突しないよう調整します。サッカーは各障害物の奥行きを抜けるまで通路中央を維持し、動く障害物の最大振れ幅を含む余白を確認してスターを配置します。

サッカーは月明かり・暖色の照明・濃い青緑のコートに統一し、壁は金属フレーム、パッド、琥珀色の反射材付きバリケードへ変更しました。
