# このゲームの作業方針

- ユーザーの継続指示: ゲームを改善したら、GitHub更新を別途頼まれなくても公開版まで最新版へ更新する。
- 対象リポジトリ: https://github.com/itsukit0723-netizen/sports-festival-runners
- 公開URL: https://itsukit0723-netizen.github.io/sports-festival-runners/
- 別リポジトリ `sports-festival-arcade` は別の10ゲームの公開先。今回の2ゲームで上書きしない。
- 現在は本番 `dist/` の内容を公開リポジトリ `main` のルートに置き、Pagesは Deploy from a branch → main → / (root)。公開前に適切な検証と本番ビルドを行い、公開後は配信結果を確認する。
- 公開先へソースをそのまま上書きしない。文化祭アプリへの統合用ソースはこの作業フォルダー。ソースZIPを更新する場合も依存物、個人情報、ローカルの証跡を含めない。
- 2026-10-16時点ではGitHub連携は読み取り可能だがblob書き込みが403だったため、ログイン済みブラウザーのGitHub Upload filesで配信ファイルを更新した。
