@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist node_modules\vite (
  call npm.cmd install
  if errorlevel 1 exit /b 1
)
call npm.cmd run mobile
if errorlevel 1 pause
