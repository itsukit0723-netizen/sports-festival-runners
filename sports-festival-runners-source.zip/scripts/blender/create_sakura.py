"""Build original Sakura Garden assets in Blender; no external asset downloads.
Run: blender --background --python scripts/blender/create_sakura.py
"""
import bpy, math, random, os, json
from mathutils import Vector
import numpy as np
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '../..'))
for folder in ['src/assets','sources/blender','artifacts/blender']:os.makedirs(os.path.join(ROOT,folder),exist_ok=True)
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
random.seed(1942)

def rgba(h):
    h=h.lstrip('#'); a=[int(h[i:i+2],16)/255 for i in (0,2,4)]
    return tuple(((v+.055)/1.055)**2.4 if v>.04045 else v/12.92 for v in a)+(1,)
def mat(name,color,rough=.8,metal=0,glow=0):
    m=bpy.data.materials.new(name);m.use_nodes=True;m.node_tree.nodes.clear()
    p=m.node_tree.nodes.get('Principled BSDF') or m.node_tree.nodes.new('ShaderNodeBsdfPrincipled');p.name='Principled BSDF';out=m.node_tree.nodes.get('Material Output') or m.node_tree.nodes.new('ShaderNodeOutputMaterial');m.node_tree.links.new(p.outputs['BSDF'],out.inputs['Surface']);p.inputs['Base Color'].default_value=rgba(color);p.inputs['Roughness'].default_value=rough;p.inputs['Metallic'].default_value=metal
    if glow:p.inputs['Emission Color'].default_value=rgba(color);p.inputs['Emission Strength'].default_value=glow
    m.diffuse_color=rgba(color);return m
wood=mat('Aged cedar | warm burgundy','#603e45'); bark=mat('Cherry bark','#4d3542');red=mat('Vermilion lacquer','#9e4652',.55)
stone=mat('Weathered granite','#7c8392',.94);darkstone=mat('Stone joint shadow','#4f5869',1)
roofmat=mat('Blue charcoal ceramic','#354457',.46,.12);tileedge=mat('Glazed tile ridges','#536376',.43,.12)
gold=mat('Antique brass','#ba9273',.42,.6);paper=mat('Warm washi lantern','#ffd2a3',.7,0,1.15)
pink=[mat('Blossom '+str(i),c,1) for i,c in enumerate(['#a86586','#ca86a4','#e8adc3','#f2c3d2'])]
moss=mat('Moss in stone joints','#4c655d',1)

def texture(name,array):
    h,w,_=array.shape;im=bpy.data.images.new(name,width=w,height=h,alpha=True);im.pixels.foreach_set(array.astype(np.float32).ravel());im.pack();return im
# An original alpha atlas made of overlapping five-petal flowers: visual detail
# comes from the texture, not thousands of individual high-poly petals.
size=512; yy,xx=np.mgrid[0:size,0:size]; pixels=np.zeros((size,size,4),dtype=np.float32)
rng=random.Random(49)
for i in range(39):
    a=rng.random()*math.tau;r=(rng.random()**.5)*174;cx=256+math.cos(a)*r;cy=256+math.sin(a)*r
    rad=rng.uniform(15,25);rot=rng.random()*math.tau
    for k in range(5):
        angle=rot+k*math.tau/5;px=cx+math.cos(angle)*rad*.63;py=cy+math.sin(angle)*rad*.63
        dx=(xx-px)*math.cos(angle)+(yy-py)*math.sin(angle);dy=-(xx-px)*math.sin(angle)+(yy-py)*math.cos(angle)
        d=(dx/(rad*.78))**2+(dy/(rad*.52))**2;alpha=np.clip((1-d)*9,0,1)
        shade=np.clip(.87+.13*(1-d),.8,1);color=np.array([1,.69+rng.random()*.14,.81+rng.random()*.09])
        mask=alpha>pixels[:,:,3];pixels[mask,:3]=(shade[:,:,None]*color)[mask];pixels[mask,3]=alpha[mask]
    center=(xx-cx)**2+(yy-cy)**2<5.5**2;pixels[center]=[.97,.81,.6,1]
atlas=texture('Original sakura flower atlas',pixels)
flowers=mat('Sakura blossom atlas | cutout','#ffffff',1);nt=flowers.node_tree;p=nt.nodes.get('Principled BSDF');tx=nt.nodes.new('ShaderNodeTexImage');tx.image=atlas;nt.links.new(tx.outputs['Color'],p.inputs['Base Color']);cut=nt.nodes.new('ShaderNodeMath');cut.operation='GREATER_THAN';cut.inputs[1].default_value=.38;nt.links.new(tx.outputs['Alpha'],cut.inputs[0]);nt.links.new(cut.outputs[0],p.inputs['Alpha']);flowers.surface_render_method='DITHERED';flowers.use_backface_culling=False
# UV bark pigment, portable to glTF.
y,x=np.mgrid[0:256,0:128];v=.8+.13*np.sin(x*.8+np.sin(y*.04))+.05*np.sin(y*.6+x*.07);a=np.ones((256,128,4),dtype=np.float32);a[:,:,:3]=np.clip(v[:,:,None]*np.array([.35,.22,.27]),0,1);barktex=texture('Cherry bark pigment',a);t=bark.node_tree.nodes.new('ShaderNodeTexImage');t.image=barktex;bark.node_tree.links.new(t.outputs['Color'],bark.node_tree.nodes.get('Principled BSDF').inputs['Base Color'])
assets=[]
def root(name):
    o=bpy.data.objects.new(name,None);bpy.context.collection.objects.link(o);assets.append(o);return o

def mesh(name,verts,faces,material,parent,uv=None):
    data=bpy.data.meshes.new(name);data.from_pydata(verts,[],faces);data.materials.append(material);data.update()
    if uv:
        layer=data.uv_layers.new(name='UVMap')
        for poly in data.polygons:
            for li in poly.loop_indices:layer.data[li].uv=uv[data.loops[li].vertex_index]
    ob=bpy.data.objects.new(name,data);bpy.context.collection.objects.link(ob);ob.parent=parent;return ob

def box(name,loc,scale,m,parent,bevel=0):
    bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.name=name;o.scale=scale;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(m);o.parent=parent
    if bevel:
        mod=o.modifiers.new('Soft crafted edges','BEVEL');mod.width=bevel;mod.segments=2
        bpy.context.view_layer.objects.active=o;bpy.ops.object.modifier_apply(modifier=mod.name)
    return o

def branch(name,points,radii,m,parent,sides=7):
    vs=[];fs=[];uv=[]
    for i,p in enumerate(points):
        p=Vector(p);t=(Vector(points[min(i+1,len(points)-1)])-Vector(points[max(0,i-1)])).normalized();a=t.cross(Vector((0,1,0))).normalized();b=t.cross(a).normalized()
        for j in range(sides+1):
            angle=j/sides*math.tau;vs.append(p+radii[i]*(a*math.cos(angle)+b*math.sin(angle)));uv.append((j/sides,i*.65))
    for i in range(len(points)-1):
        for j in range(sides):a=i*(sides+1)+j;fs.append((a,a+1,a+sides+2,a+sides+1))
    o=mesh(name,vs,fs,m,parent,uv)
    for p in o.data.polygons:p.use_smooth=True
    return o

def tree(name,seed):
    r=root(name);rng=random.Random(seed)
    branch('Twisting trunk',[(0,0,0),(.12,.08,.7),(.18,-.04,1.5),(-.05,.12,2.3),(.35,.05,3.1)],[.32,.28,.22,.15,.075],bark,r,9)
    centers=[]
    for i in range(9):
        a=i*2.399+rng.random()*.3;reach=rng.uniform(1.1,2.3);end=Vector((math.cos(a)*reach,math.sin(a)*reach,3.5+rng.random()*1.25))
        start=Vector((.1,0,1.7+i%3*.35));mid=start.lerp(end,.5)+Vector((0,0,.35))
        branch('Tapered limb', [start,mid,end],[.115,.075,.018],bark,r)
        for j in range(3):
            tip=end+Vector((math.cos(a+j)*.65,math.sin(a+j)*.65,.2+rng.random()*.45));branch('Fine branch',[mid,end,tip],[.045,.024,.005],bark,r,5);centers.append(tip)
    # Low-poly inner volume prevents transparent cards from looking hollow.
    for i,c in enumerate(centers):
        bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=1,radius=1,location=c);o=bpy.context.object;o.name='Shaded blossom heart';o.scale=(.43,.42,.31);o.parent=r;o.data.materials.append(pink[0])
        for p in o.data.polygons:p.use_smooth=True
    verts=[];faces=[];uv=[]
    for c in centers:
        for j in range(10):
            offset=Vector((rng.uniform(-.6,.6),rng.uniform(-.6,.6),rng.uniform(-.25,.6)));center=c+offset
            normal=Vector((rng.uniform(-1,1),rng.uniform(-1,1),rng.uniform(.1,1))).normalized();u=normal.cross(Vector((0,0,1))).normalized();v=normal.cross(u)
            w=rng.uniform(.65,.98);base=len(verts)
            for x,y in [(-1,-1),(1,-1),(1,1),(-1,1)]:verts.append(center+u*x*w*.65+v*y*w*.65);uv.append(((x+1)/2,(y+1)/2))
            faces.append((base,base+1,base+2,base+3))
    mesh('Detailed blossom sprays',verts,faces,flowers,r,uv)
    for i in range(5):
        a=i*math.tau/5;branch('Exposed roots',[(0,0,.1),(math.cos(a)*.55,math.sin(a)*.55,.05),(math.cos(a)*.9,math.sin(a)*.9,.01)],[.16,.07,.015],bark,r)
    return r

def curved_roof(name,width,depth,z,m,r):
    verts=[];faces=[];nx=24;ny=8
    for j in range(ny+1):
        y=(j/ny-.5)*depth
        for i in range(nx+1):
            x=(i/nx-.5)*width;u=abs(x)/(width/2);h=z+.95*(1-u)**1.2+.24*u**7+.12*(abs(y)/(depth/2))**6
            verts.append((x,y,h))
    for j in range(ny):
        for i in range(nx):k=j*(nx+1)+i;faces.append((k,k+1,k+nx+2,k+nx+1))
    o=mesh(name,verts,faces,m,r);solid=o.modifiers.new('Roof thickness','SOLIDIFY');solid.thickness=.12;bpy.context.view_layer.objects.active=o;bpy.ops.object.modifier_apply(modifier=solid.name)
    for y in np.linspace(-depth/2,depth/2,17):
        pts=[]
        for x in np.linspace(-width/2,width/2,13):u=abs(x)/(width/2);pts.append((x,float(y),z+.95*(1-u)**1.2+.24*u**7+.12*(abs(y)/(depth/2))**6+.035))
        branch('Individual tile seam',pts,[.027]*len(pts),tileedge,r,5)
    branch('Ridge cap',[(0,-depth/2-.12,z+1.05),(0,0,z+1.01),(0,depth/2+.12,z+1.05)],[.09,.085,.09],tileedge,r,8)

A=tree('Sakura_Tree_A',78);B=tree('Sakura_Tree_B',127)
r=root('Sakura_Lantern')
box('Lower granite plinth',(0,0,.13),(.85,.85,.26),darkstone,r,.055);box('Carved base',(0,0,.32),(.59,.59,.15),stone,r,.035)
branch('Tapered stone stem',[(0,0,.38),(0,0,1.03)],[.18,.14],stone,r,8);box('Lantern sill',(0,0,1.08),(.69,.69,.13),stone,r,.025)
box('Washi warm core',(0,0,1.36),(.43,.43,.45),paper,r,.018)
for x in [-.28,.28]:
    for y in [-.28,.28]:box('Carved corner',(x,y,1.36),(.075,.075,.53),stone,r,.015)
curved_roof('Swept stone lantern cap',1,1,1.62,stone,r);branch('Lotus finial',[(0,0,2.6),(0,0,2.81)],[.09,.015],stone,r)
r=root('Sakura_Torii')
for x in [-5.15,5.15]:
    branch('Inclined lacquer pillar',[(x,0,.15),(x*.98,0,3.4),(x*.96,0,6.15)],[.29,.25,.22],red,r,12)
    box('Stone footing',(x,0,.16),(.95,.95,.32),darkstone,r,.06);box('Black protective sleeve',(x,0,.75),(.59,.59,1.1),roofmat,r,.035)
box('Tie beam',(0,0,5.45),(11.2,.32,.28),red,r,.035)
branch('Sweeping top lintel',[(-6.2,0,6.65),(-4.4,0,6.3),(0,0,6.25),(4.4,0,6.3),(6.2,0,6.65)],[.19]*5,roofmat,r,10)
branch('Vermilion lintel',[(-6,0,6.43),(-4.4,0,6.12),(0,0,6.08),(4.4,0,6.12),(6,0,6.43)],[.15]*5,red,r,10)
box('Dedication tablet',(0,-.2,5.93),(.65,.15,.85),roofmat,r,.025)
for x in [-.25,.25]:box('Tablet brass border',(x,-.285,5.93),(.025,.02,.72),gold,r)
# Sacred twisted rope and hanging folded paper, well above the playable volume.
rope=[(-4+i*.25,-.3,4.95-.35*(1-((-4+i*.25)/4)**2)) for i in range(33)]
branch('Shimenawa rope',rope,[.045]*len(rope),gold,r,6)
for x in [-2.4,-.8,.8,2.4]:
    mesh('Folded shide',[(x,-.33,4.75),(x+.18,-.33,4.45),(x+.04,-.38,4.32),(x+.19,-.38,4.08),(x-.03,-.38,4.15),(x-.14,-.33,4.5)],[(0,1,2,3,4,5)],pink[3],r)
r=root('Sakura_Shrine')
for j in range(3):box('Terraced shrine hill',(0,0,-.35-j*.65),(7.8+j*1.2,6+j*1.1,.7),darkstone,r,.05)
for j in range(4):box('Broad stair',(0,-3+j*.35,.12+j*.13),(6.4,.7,.24+j*.1),stone,r,.025)
box('Foundation',(0,0,.48),(6.7,4.8,.8),darkstone,r,.055);box('Timber floor',(0,0,.94),(6.5,4.6,.15),wood,r,.025)
box('Inner hall',(0,.25,2.18),(5.4,3.6,2.5),wood,r,.04)
for x in [-2.9,-1.45,1.45,2.9]:
    for y in [-2,1.95]:branch('Veranda column',[(x,y,1),(x,y,3.45)],[.1,.1],red,r,8)
for x in [-1.9,1.9]:
    box('Window glow',(x,-1.59,2.32),(1.1,.03,1.12),paper,r)
    for k in range(6):box('Wooden window lattice',(x-.5+k*.2,-1.63,2.32),(.035,.06,1.18),wood,r)
    for k in range(4):box('Window cross rail',(x,-1.67,1.8+k*.35),(1.16,.05,.035),wood,r)
for x in [-.6,.6]:
    box('Entrance door',(x,-1.59,2.02),(1.1,.12,2.1),roofmat,r,.025)
    for k in range(5):box('Door panel rib',(x-.4+k*.2,-1.67,2.02),(.035,.035,2),red,r)
box('Transom beam',(0,-1.7,3.25),(5.8,.26,.18),red,r,.02)
for x in [-2.6,-1.3,0,1.3,2.6]:
    box('Bracket block',(x,-1.8,3.45),(.55,.55,.22),wood,r,.02);box('Bracket cap',(x,-1.85,3.65),(.9,.75,.16),red,r,.02)
curved_roof('Main ceramic roof',8.2,6,3.68,roofmat,r)
curved_roof('Entrance canopy',3.8,2.7,3.02,roofmat,r)
# Veranda rail with balusters on the sides, entrance stays readable.
for x in [-3.12,3.12]:
    for y in np.linspace(-2,2,9):box('Baluster',(x,float(y),1.32),(.055,.055,.6),red,r)
    box('Rail cap',(x,0,1.65),(.13,4.3,.1),wood,r,.02)
r=root('Sakura_GardenBed')
box('Stone planting border',(0,0,.05),(3.8,4,.1),darkstone,r,.06)
for i in range(17):
    angle=i*2.399;rr=.6+(i%4)*.32
    bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=1,radius=1,location=(math.cos(angle)*rr,math.sin(angle)*rr,.13));o=bpy.context.object;o.parent=r;o.name='Mossy garden stones';o.scale=(.34,.25,.16);o.data.materials.append(moss if i%3 else stone)
# Consolidate each reusable asset into one mesh (glTF splits by material).
for asset in assets:
    children=[o for o in asset.children if o.type=='MESH']
    bpy.ops.object.select_all(action='DESELECT')
    for o in children:o.select_set(True)
    bpy.context.view_layer.objects.active=children[0];bpy.ops.object.join();o=bpy.context.object;o.name=asset.name+'_Mesh'
    bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
# Export editable library with roots at origin; .glb Y-up maps Blender Z-up.
asset_path=os.path.join(ROOT,'src/assets/sakura-garden.glb')
bpy.ops.export_scene.gltf(filepath=asset_path,export_format='GLB',export_cameras=False,export_lights=False,export_animations=False,export_apply=True,export_yup=True,export_extras=True)
# Scene layout for the editable Blender project and its preview render.
for o in assets:
    o.hide_render=True;o.hide_set(True)
    for child in o.children:child.hide_render=True;child.hide_set(True)
def instance(asset,loc,scale=1,angle=0):
    parent=bpy.data.objects.new('Preview_'+asset.name,None);bpy.context.collection.objects.link(parent);parent.location=loc;parent.scale=(scale,)*3;parent.rotation_euler.z=angle
    for child in asset.children:
        ob=bpy.data.objects.new(child.name,child.data);bpy.context.collection.objects.link(ob);ob.parent=parent;ob.matrix_basis=child.matrix_basis.copy()
    return parent
for side in [-1,1]:
    for i in range(4):
        instance(A if i%2 else B,(side*6.7,i*8,0),1.05,side*(.3+i*.7));instance(assets[2],(side*4.95,i*8+3,0),.8)
instance(assets[3],(0,13,0));instance(assets[4],(-11,33,2),1.3,-.2);instance(assets[4],(11,40,2),1.2,.2)
road=mat('Preview paving','#454754',.85);box('Preview road',(0,20,-.16),(9,75,.25),road,None)
for side in [-1,1]:box('Preview path border',(side*4.65,20,-.1),(.3,75,.3),stone,None,.035)
world=bpy.context.scene.world or bpy.data.worlds.new('Twilight');bpy.context.scene.world=world;world.use_nodes=True;world.node_tree.nodes.clear();bg=world.node_tree.nodes.get('Background') or world.node_tree.nodes.new('ShaderNodeBackground');out=world.node_tree.nodes.get('World Output') or world.node_tree.nodes.new('ShaderNodeOutputWorld');world.node_tree.links.new(bg.outputs[0],out.inputs[0]);bg.inputs[0].default_value=rgba('#39445a');bg.inputs[1].default_value=.45
bpy.ops.object.light_add(type='AREA',location=(-9,-3,13));bpy.context.object.data.energy=1900;bpy.context.object.data.shape='DISK';bpy.context.object.data.size=15
bpy.ops.object.light_add(type='AREA',location=(10,20,10));bpy.context.object.data.energy=1400;bpy.context.object.data.color=(.72,.78,1);bpy.context.object.data.size=12
bpy.ops.object.camera_add(location=(1,-13,6.2));cam=bpy.context.object;cam.rotation_euler=(Vector((0,18,3.1))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.lens=27;bpy.context.scene.camera=cam
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=24;scene.cycles.use_denoising=True;scene.render.resolution_x=1000;scene.render.resolution_y=740;scene.render.resolution_percentage=100;scene.render.image_settings.file_format='PNG';scene.render.filepath=os.path.join(ROOT,'artifacts/blender/sakura-garden-preview.png')
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(ROOT,'sources/blender/sakura-garden.blend'),compress=True)
# Geometry/budget evidence, exported model is the authoritative game asset.
triangles=0
for asset in assets:
    for ob in asset.children:
        ob.data.calc_loop_triangles();triangles+=len(ob.data.loop_triangles)
report={'blender':bpy.app.version_string,'roots':[a.name for a in assets],'triangles':triangles,'glbBytes':os.path.getsize(asset_path),'originalAssets':True}
with open(os.path.join(ROOT,'artifacts/blender/sakura-budget.json'),'w') as f:json.dump(report,f,indent=2)
print('SAKURA_ASSETS',json.dumps(report))
bpy.ops.render.render(write_still=True)
