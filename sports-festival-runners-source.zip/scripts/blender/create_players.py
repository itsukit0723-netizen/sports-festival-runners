"""Original articulated football athlete and curved 32-panel match ball."""
import bpy, math, os, ast, json
import numpy as np
from mathutils import Vector
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),'../..'))
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
with open(os.path.join(ROOT,'scripts/blender/create_sakura.py'),encoding='utf-8-sig') as f:tree=ast.parse(f.read())
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ['rgba','mat','texture','root','mesh','box','branch']],type_ignores=[]),'helpers','exec'))
assets=[]
skin=mat('Warm skin','#cc9777',.68);skinshade=mat('Lips and ear shadow','#a56e5e',.8)
hair=mat('Sculpted midnight hair','#252633',.76);hairlight=mat('Hair sculpt ridges','#383747',.73)
kit=mat('Indigo woven jersey','#626b9c',.83);navy=mat('Midnight shorts and boots','#28374d',.72)
trim=mat('Ivory embroidery and socks','#e8e3d2',.8);mint=mat('Mint stitched crest','#a9d7bb',.65)
eye=mat('Eye whites','#f1e7da',.5);iris=mat('Dark eyes','#26323c',.45);sole=mat('Rubber sole','#96aaa6',.93)
white=mat('Pearl match ball leather','#eee8d9',.49);black=mat('Charcoal pentagon leather','#273743',.55);seam=mat('Recessed graphite seams','#46525b',.88)
# Embedded portable normal map: fine pebbled leather, also a subtle fabric weave.
y,x=np.mgrid[:128,:128];rng=np.random.default_rng(8);h=rng.random((128,128))*.3+np.sin(x*math.pi/2)*np.sin(y*math.pi/2)*.12
dx=np.roll(h,1,1)-np.roll(h,-1,1);dy=np.roll(h,1,0)-np.roll(h,-1,0)
a=np.ones((128,128,4),np.float32);a[:,:,0]=.5+dx*.25;a[:,:,1]=.5+dy*.25;a[:,:,2]=1
im=texture('Original leather micrograin',a);im.colorspace_settings.name='Non-Color'
for m,strength,scale in [(white,.3,12),(black,.3,12),(kit,.16,9),(navy,.12,9)]:
    nt=m.node_tree;t=nt.nodes.new('ShaderNodeTexImage');t.image=im
    uv=nt.nodes.new('ShaderNodeTexCoord');mapping=nt.nodes.new('ShaderNodeVectorMath');mapping.operation='SCALE';mapping.inputs[3].default_value=scale;nt.links.new(uv.outputs['UV'],mapping.inputs[0]);nt.links.new(mapping.outputs[0],t.inputs['Vector'])
    normal=nt.nodes.new('ShaderNodeNormalMap');normal.inputs['Strength'].default_value=strength;nt.links.new(t.outputs['Color'],normal.inputs['Color']);nt.links.new(normal.outputs['Normal'],nt.nodes.get('Principled BSDF').inputs['Normal'])

def joint(name,loc,parent):
    o=bpy.data.objects.new(name,None);bpy.context.collection.objects.link(o);o.parent=parent;o.location=loc;return o
def ell(name,loc,scale,m,parent):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=20,ring_count=12,radius=1);o=bpy.context.object;o.name=name;o.parent=parent;o.location=loc;o.scale=scale;o.data.materials.append(m)
    for p in o.data.polygons:p.use_smooth=True
    return o
def tube(name,points,radii,m,parent):return branch(name,points,radii,m,parent,10)
def rings(name,levels,m,parent):
    vs=[];fs=[];uv=[];n=24
    for k,(z,w,d,cy) in enumerate(levels):
        for j in range(n+1):
            t=j/n*math.tau;vs.append((math.cos(t)*w,cy+math.sin(t)*d,z));uv.append((j/n,k/(len(levels)-1)))
    for k in range(len(levels)-1):
        for j in range(n):i=k*(n+1)+j;fs.append((i,i+1,i+n+2,i+n+1))
    o=mesh(name,vs,fs,m,parent,uv)
    for p in o.data.polygons:p.use_smooth=True
    return o

r=root('Athlete')
rings('Tailored athletic jersey',[(.8,.23,.15,0),(.86,.25,.17,0),(1,.235,.16,0),(1.18,.29,.19,0),(1.32,.315,.175,0),(1.39,.23,.13,0),(1.42,.105,.09,0)],kit,r)
ell('Shorts seat',(0,0,.8),(.265,.18,.14),navy,r)
tube('Neck',[(0,0,1.36),(0,0,1.53)],[.085,.085],skin,r)
tube('Contrast collar',[(-.11,-.075,1.40),(0,-.108,1.365),(.11,-.075,1.40)],[.014,.014,.014],trim,r)
for s in [-1,1]:
    tube('Tailored side seam',[(s*.22,-.1,.86),(s*.245,-.13,1.09),(s*.28,-.105,1.3)],[.009,.009,.009],trim,r)
    for j in range(3):tube('Shoulder stripe',[(s*(.18+j*.025),-.09,1.38),(s*(.26+j*.025),-.09,1.34)],[.008,.008],trim,r)
    for j in range(3):tube('Fabric fold',[(s*(.16+j*.02),-.155,.89),(s*(.12+j*.02),-.165,.95)],[.004,.001],navy,r)
box('Embroidered crest',(-.14,-.177,1.27),(.055,.012,.065),mint,r,.012)
box('Number seven top',(.04,-.192,1.20),(.135,.012,.025),trim,r,.004)
o=box('Number seven stem',(.045,-.184,1.115),(.024,.012,.17),trim,r,.004);o.rotation_euler.y=.3
head=joint('head',(0,0,1.65),r)
rings('Sculpted jaw cheeks and cranium',[(-.22,.075,.08,-.01),(-.19,.12,.13,-.015),(-.10,.17,.16,0),(.01,.185,.167,0),(.11,.18,.155,.005),(.20,.12,.115,.01),(.23,.015,.015,.01)],skin,head)
ell('Cropped hair crown',(0,.018,.14),(.188,.163,.12),hair,head)
for s in [-1,1]:
    ell('Ear',(s*.181,0,-.015),(.031,.039,.055),skin,head);ell('Inner ear',(s*.202,-.022,-.016),(.009,.017,.028),skinshade,head)
    ell('Eye socket',(s*.071,-.153,.006),(.040,.020,.027),skinshade,head)
    ell('Eye',(s*.071,-.169,.006),(.031,.012,.019),eye,head);ell('Iris',(s*.068,-.180,.004),(.012,.004,.014),iris,head)
    ell('Eye glint',(s*.068-.004,-.184,.009),(.003,.002,.003),eye,head)
    tube('Eyebrow',[(s*.04,-.165,.052),(s*.075,-.173,.06),(s*.105,-.153,.052)],[.008,.01,.005],hair,head)
    tube('Side fade',[(s*.176,.015,.12),(s*.18,.035,-.035)],[.025,.009],hair,head)
ell('Nose bridge',(0,-.162,-.025),(.027,.032,.055),skin,head);ell('Nose tip',(0,-.191,-.059),(.029,.022,.023),skin,head)
tube('Relaxed mouth',[(-.037,-.151,-.121),(0,-.164,-.124),(.037,-.151,-.121)],[.004,.005,.004],skinshade,head)
for i in range(9):
    x=(i-4)*.035;tube('Swept hair locks',[(x,-.10,.15),(x-.025,-.055,.232),(x-.045,.06,.22)],[.013,.018,.008],hairlight if i%3==0 else hair,head)
for s in [-1,1]:
    arm=joint('leftArm' if s<0 else 'rightArm',(s*.29,0,1.32),r)
    tube('Jersey sleeve',[(0,0,.015),(s*.115,.008,-.105)],[.113,.095],kit,arm)
    tube('Sleeve cuff',[(s*.10,.008,-.09),(s*.125,.008,-.117)],[.097,.092],trim,arm)
    tube('Upper arm',[(s*.12,.008,-.11),(s*.20,-.025,-.22)],[.08,.066],skin,arm)
    ell('Elbow',(s*.20,-.025,-.22),(.07,.07,.07),skin,arm)
    tube('Tapered forearm',[(s*.20,-.025,-.22),(s*.33,-.16,-.08)],[.067,.043],skin,arm)
    ell('Palm',(s*.355,-.17,-.065),(.055,.035,.073),skin,arm)
    for j in range(4):tube('Separated fingers',[(s*(.33+j*.016),-.18,-.035),(s*(.34+j*.016),-.18,.005+(j in [1,2])*.014)],[.008,.006],skin,arm)
    ell('Thumb',(s*.315,-.195,-.07),(.015,.024,.03),skin,arm)
    leg=joint('leftLeg' if s<0 else 'rightLeg',(s*.155,0,.81),r)
    tube('Short leg',[(0,0,0),(s*.048,-.005,-.19)],[.139,.121],navy,leg)
    tube('Shorts piping',[(s*.044,-.006,-.176),(s*.049,-.005,-.195)],[.122,.122],trim,leg)
    tube('Thigh',[(s*.05,-.005,-.19),(s*.095,-.035,-.31)],[.104,.078],skin,leg)
    ell('Kneecap',(s*.095,-.07,-.31),(.074,.065,.075),skin,leg)
    tube('Calf',[(s*.095,-.035,-.32),(s*.14,-.015,-.47),(s*.18,-.02,-.65)],[.078,.081,.045],trim,leg)
    for z in [-.425,-.45]:tube('Sock stripe',[(s*.13,-.02,z),(s*.134,-.019,z-.012)],[.083,.082],kit,leg)
    ell('Rubber outsole',(s*.18,-.09,-.748),(.114,.213,.029),sole,leg)
    ell('Football boot',(s*.18,-.085,-.701),(.11,.20,.066),navy,leg)
    ell('Toe cap',(s*.18,-.208,-.711),(.102,.07,.045),kit,leg)
    for j in range(4):tube('Ivory boot laces',[(s*.18-.04,-.075-j*.024,-.64-j*.007),(s*.18+.04,-.086-j*.024,-.64-j*.007)],[.004,.004],trim,leg)
    for xx in [-.065,.065]:
        for yy in [-.19,.02]:ell('Boot stud',(s*.18+xx,yy,-.777),(.017,.019,.015),sole,leg)

# A real truncated icosahedron: twelve pentagons plus twenty hexagons.
ball=root('MatchBall');bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=1,radius=1);tmp=bpy.context.object
v=[p.co.copy() for p in tmp.data.vertices];faces=[list(p.vertices) for p in tmp.data.polygons];bpy.data.objects.remove(tmp,do_unlink=True)
neighbors={i:set() for i in range(12)}
for f in faces:
    for i in f:
        for j in f:
            if i!=j:neighbors[i].add(j)
polygons=[]
for i,nn in neighbors.items():polygons.append(([v[i]*2/3+v[j]/3 for j in nn],black))
for a,b,c in faces:polygons.append(([v[a]*2/3+v[b]/3,v[b]*2/3+v[a]/3,v[b]*2/3+v[c]/3,v[c]*2/3+v[b]/3,v[c]*2/3+v[a]/3,v[a]*2/3+v[c]/3],white))
ell('Dark seam foundation',(0,0,0),(.997,.997,.997),seam,ball)
for index,(points,m) in enumerate(polygons):
    center=sum(points,Vector())/len(points);n=center.normalized();u=n.cross(Vector((.013,0,1))).normalized();w=n.cross(u)
    points.sort(key=lambda p:math.atan2((p-center).dot(w),(p-center).dot(u)))
    points=[p.lerp(center,.018).normalized() for p in points];coords=[];ff=[];uv=[]
    def tri(a,b,c,depth):
        if depth:
            ab=(a+b).normalized();bc=(b+c).normalized();ca=(c+a).normalized()
            for t in [(a,ab,ca),(ab,b,bc),(ca,bc,c),(ab,bc,ca)]:tri(*t,depth-1)
        else:
            k=len(coords)
            for p in [a,b,c]:coords.append(p);uv.append((p.dot(u)*.5+.5,p.dot(w)*.5+.5))
            ff.append((k,k+1,k+2))
    for i in range(len(points)):tri(n,points[i],points[(i+1)%len(points)],2)
    o=mesh(('Pentagon' if len(points)==5 else 'Hexagon')+str(index),coords,ff,m,ball,uv)
    for p in o.data.polygons:p.use_smooth=True

# Batch each articulated joint by material, retaining the named transform pivots.
for parent in [r,head]+[o for o in r.children if o.type=='EMPTY' and o!=head]+[ball]:
    children=[o for o in parent.children if o.type=='MESH']
    if not children:continue
    bpy.ops.object.select_all(action='DESELECT')
    for o in children:o.select_set(True)
    bpy.context.view_layer.objects.active=children[0];bpy.ops.object.join();o=bpy.context.object;o.name=parent.name+'_surface'
    # Preserve the parent pivot when exporting joined meshes.
    bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
path=os.path.join(ROOT,'src/assets/football-players.glb')
# The obstacle has its own copper/graphite leather panels, distinct from the
# player's ivory match ball, while sharing the curved 32-panel topology.
hazard=root('HazardBall')
copper=white.copy();copper.name='Copper orange obstacle leather';copper.node_tree.nodes.get('Principled BSDF').inputs['Base Color'].default_value=rgba('#ce7847');copper.diffuse_color=rgba('#ce7847')
graphite=black.copy();graphite.name='Graphite obstacle panels';graphite.node_tree.nodes.get('Principled BSDF').inputs['Base Color'].default_value=rgba('#23313f')
for child in ball.children:
    clone=child.copy();clone.data=child.data.copy();bpy.context.collection.objects.link(clone);clone.parent=hazard
    for i,m in enumerate(clone.data.materials):
        if m==white:clone.data.materials[i]=copper
        elif m==black:clone.data.materials[i]=graphite
    clone.name='Obstacle curved leather panels'
bpy.ops.export_scene.gltf(filepath=path,export_format='GLB',export_cameras=False,export_lights=False,export_animations=False,export_apply=True,export_yup=True)
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(ROOT,'sources/blender/football-players.blend'))
budget={'bytes':os.path.getsize(path),'triangles':sum(sum(len(p.vertices)-2 for p in o.data.polygons) for o in bpy.data.objects if o.type=='MESH'),'panels':len(polygons)}
with open(os.path.join(ROOT,'artifacts/blender/players-budget.json'),'w') as f:json.dump(budget,f)
print(budget)
