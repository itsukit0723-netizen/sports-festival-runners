"""Original stadium trophy. Grounded origin, joined materials, portable GLB."""
import bpy, math, os, json
from mathutils import Vector
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),'../..'))
OUT=os.path.join(ROOT,'artifacts/trophy-20261027')
os.makedirs(OUT,exist_ok=True)
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)

def material(name,color,metal=0,rough=.5):
    m=bpy.data.materials.new(name);m.use_nodes=True
    rgb=tuple(int(color[i:i+2],16)/255 for i in (1,3,5))
    # Blender's material node expects linear light.
    rgba=tuple(v/12.92 if v<.04045 else ((v+.055)/1.055)**2.4 for v in rgb)+(1,)
    m.diffuse_color=rgba;p=m.node_tree.nodes.get('Principled BSDF')
    p.inputs['Base Color'].default_value=rgba;p.inputs['Metallic'].default_value=metal;p.inputs['Roughness'].default_value=rough
    return m
gold=material('Brushed champagne gold','#e9bc62',.78,.29)
rim=material('Polished rolled gold','#ffdea0',.85,.2)
inside=material('Warm cup interior','#bc8136',.7,.38)
navy=material('Midnight enamel plinth','#182437',.2,.37)
stone=material('Warm limestone pedestal','#b6b0a1',.05,.78)
dark=material('Inlaid football panels','#453323',.48,.37)

def mesh(name,verts,faces,mat):
    data=bpy.data.meshes.new(name);data.from_pydata(verts,[],faces);data.update()
    o=bpy.data.objects.new(name,data);bpy.context.collection.objects.link(o);o.data.materials.append(mat)
    for p in data.polygons:p.use_smooth=True
    return o
def lathe(name,profile,mat,n=64):
    v=[(r*math.cos(j*math.tau/n),r*math.sin(j*math.tau/n),z) for r,z in profile for j in range(n)]
    f=[]
    for i in range(len(profile)-1):
        for j in range(n):a=i*n+j;b=i*n+(j+1)%n;f.append((a,b,b+n,a+n))
    return mesh(name,v,f,mat)
def torus(name,r,minor,z,mat):
    bpy.ops.mesh.primitive_torus_add(major_segments=64,minor_segments=8,location=(0,0,z),major_radius=r,minor_radius=minor)
    o=bpy.context.object;o.name=name;o.data.materials.append(mat)
    for p in o.data.polygons:p.use_smooth=True
    return o
def cylinder(name,r,depth,z,mat,vertices=32):
    bpy.ops.mesh.primitive_cylinder_add(vertices=vertices,radius=r,depth=depth,location=(0,0,z))
    o=bpy.context.object;o.name=name;o.data.materials.append(mat)
    bevel=o.modifiers.new('Soft machined edges','BEVEL');bevel.width=.025;bevel.segments=2
    bpy.context.view_layer.objects.active=o;bpy.ops.object.modifier_apply(modifier=bevel.name)
    for p in o.data.polygons:p.use_smooth=abs(p.normal.z)<.8
    return o
def tube(name,points,radius,mat):
    curve=bpy.data.curves.new(name,'CURVE');curve.dimensions='3D';curve.resolution_u=16;curve.bevel_depth=radius;curve.bevel_resolution=2
    spline=curve.splines.new('BEZIER');spline.bezier_points.add(len(points)-1)
    for b,co in zip(spline.bezier_points,points):b.co=co;b.handle_left_type=b.handle_right_type='AUTO'
    o=bpy.data.objects.new(name,curve);bpy.context.collection.objects.link(o);o.data.materials.append(mat)
    bpy.context.view_layer.objects.active=o;o.select_set(True);bpy.ops.object.convert(target='MESH');o.select_set(False)
    return o
def text(name,body,loc,size,mat):
    curve=bpy.data.curves.new(name,'FONT');curve.body=body;curve.align_x='CENTER';curve.size=size;curve.extrude=.001;curve.resolution_u=3
    o=bpy.data.objects.new(name,curve);bpy.context.collection.objects.link(o);o.location=loc;o.rotation_euler=(math.pi/2,0,0);o.data.materials.append(mat)
    bpy.context.view_layer.objects.active=o;o.select_set(True);bpy.ops.object.convert(target='MESH');o.select_set(False)
    return o
def plaque():
    bpy.ops.mesh.primitive_cube_add(size=1,location=(0,-.655,.54));o=bpy.context.object;o.name='Inset festival plaque';o.dimensions=(.78,.045,.22);o.data.materials.append(navy)
    bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
    bevel=o.modifiers.new('Plaque edges','BEVEL');bevel.width=.009;bevel.segments=2;bpy.ops.object.modifier_apply(modifier=bevel.name)

# Stable plinth: flat underside is exactly at z=0.
cylinder('Octagonal lower foot',.79,.14,.07,navy,8)
cylinder('Gold foot reveal',.73,.045,.1625,rim,8)
cylinder('Carved limestone pedestal',.65,.69,.53,stone,8)
cylinder('Pedestal gilded cap',.72,.11,.93,gold,8)
cylinder('Enamel trophy base',.59,.13,1.05,navy,32)
cylinder('Thin golden base ring',.58,.04,1.135,rim)

# Curved foot and stem; ornamental flutes physically join the bowl.
lathe('Trumpet foot and neck',[(0,1.15),(.44,1.15),(.43,1.2),(.32,1.26),(.2,1.34),(.13,1.49),(.125,1.73),(.18,1.85),(.27,1.94),(0,1.94)],gold)
torus('Collar',.15,.022,1.72,rim)
for j in range(10):
    a=j*math.tau/10;tube('Fine stem flute',[(math.cos(a)*.135,math.sin(a)*.135,1.42),(math.cos(a)*.13,math.sin(a)*.13,1.69)],.009,rim)

# Continuous open bowl: outer wall, thick rolled lip and inner wall.
lathe('Sculpted outer bowl',[(0,1.84),(.23,1.84),(.33,1.94),(.44,2.09),(.53,2.29),(.59,2.5),(.63,2.72),(.65,2.92),(.64,2.98)],gold)
lathe('Visible bowl interior',[(.64,2.98),(.59,2.94),(.57,2.72),(.53,2.51),(.45,2.28),(.33,2.08),(.2,1.98),(0,1.97)],inside)
torus('Rolled rim',.633,.033,2.97,rim)
torus('Lower bowl accent',.367,.014,2.0,rim)
for j in range(16):
    a=j*math.tau/16;tube('Embossed cup ray',[(math.cos(a)*.35,math.sin(a)*.35,1.99),(math.cos(a)*.46,math.sin(a)*.46,2.17),(math.cos(a)*.54,math.sin(a)*.54,2.34)],.008,rim)

# Both ends of each handle enter the actual bowl surface. No detached rings.
for s in [-1,1]:
    tube('Connected scroll handle',[(s*.63,0,2.87),(s*.87,0,2.94),(s*1.03,0,2.73),(s*.96,0,2.43),(s*.78,0,2.23),(s*.48,0,2.2)],.047,gold)
    tube('Polished handle inlay',[(s*.67,-.039,2.87),(s*.86,-.039,2.89),(s*.98,-.039,2.71),(s*.9,-.039,2.44),(s*.74,-.039,2.28),(s*.5,-.039,2.22)],.011,rim)

# Small football relief, sunk into the cup front; a separate display plaque.
bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=2,radius=.19,location=(0,-.535,2.43));ball=bpy.context.object;ball.name='Football medallion';ball.scale=(1,.45,1);ball.data.materials.append(rim);ball.data.materials.append(dark)
for i,p in enumerate(ball.data.polygons):p.material_index=1 if i%11 in (0,1) else 0;p.use_smooth=False
text('Champion engraving','CHAMPION',(0,-.612,1.045),.085,rim)
plaque()
text('Festival pedestal engraving','FESTIVAL',(0,-.681,.505),.096,rim)

# Merge by material to keep clones cheap; all objects retain a grounded origin.
for m in list(bpy.data.materials):
    pieces=[o for o in bpy.context.scene.objects if o.type=='MESH' and m in list(o.data.materials) and len(o.data.materials)==1]
    if not pieces:continue
    bpy.ops.object.select_all(action='DESELECT')
    for o in pieces:o.select_set(True)
    bpy.context.view_layer.objects.active=pieces[0];bpy.ops.object.join();o=bpy.context.object;o.name='Trophy '+m.name
root=bpy.data.objects.new('GoldenTrophy',None);bpy.context.collection.objects.link(root)
for o in list(bpy.context.scene.objects):
    if o.type=='MESH':o.parent=root

asset=os.path.join(ROOT,'src/assets/golden-trophy.glb')
bpy.ops.export_scene.gltf(filepath=asset,export_format='GLB',export_cameras=False,export_lights=False,export_animations=False,export_apply=True,export_yup=True)
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(ROOT,'sources/blender/golden-trophy.blend'))
stats={'bytes':os.path.getsize(asset),'triangles':sum(sum(len(p.vertices)-2 for p in o.data.polygons) for o in bpy.context.scene.objects if o.type=='MESH')}
with open(os.path.join(OUT,'asset-budget.json'),'w') as f:json.dump(stats,f)
print(stats)
