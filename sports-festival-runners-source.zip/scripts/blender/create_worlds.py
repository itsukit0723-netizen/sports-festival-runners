"""Original Blender asset library for neon city, ice canyon, orbital dock and ember ruins."""
import bpy, math, random, os, json, ast
import numpy as np
from mathutils import Vector
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),'../..'))
for folder in ['src/assets','sources/blender','artifacts/blender']:os.makedirs(os.path.join(ROOT,folder),exist_ok=True)
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
# Reuse our language-independent modeling helpers, without running the sakura build.
with open(os.path.join(ROOT,'scripts/blender/create_sakura.py'),encoding='utf-8-sig') as f:tree=ast.parse(f.read())
helpers=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ['rgba','mat','texture','root','mesh','box','branch']]
exec(compile(ast.Module(body=helpers,type_ignores=[]),'sakura_helpers','exec'))
assets=[];random.seed(20261018)
steel=mat('City charcoal steel','#263b50',.48,.38);concrete=mat('City cornice limestone','#7d8d98',.82);glass=mat('Blue storefront glazing','#31566b',.23,.48)
warm=mat('Warm apartment windows','#e4bd88',.55,0,.65);cyan=mat('Mint neon','#9be8dd',.4,.2,1.2);pink=mat('Rose neon','#e7a3c5',.4,0,1)
stone=mat('Basalt masonry','#554651',.92);edge=mat('Carved weathered edge','#96766c',.9);gold=mat('Ember engravings','#c48d63',.75,.1);lava=mat('Molten orange core','#ffb866',.6,0,1.4);lavared=mat('Cooling lava crust','#b75a3e',.95,0,.3)
ice=mat('Glacier blue facets','#77afc8',.24,.12);iceDark=mat('Deep blue ice','#355b7a',.4,.08);snow=mat('Snow ridgelines','#c5e0e6',.92);iceGlow=mat('Crystal heart','#b8f1ed',.28,.15,.45)
alloy=mat('Station titanium','#7087a3',.37,.58);navy=mat('Station graphite','#27344e',.55,.38);panel=mat('Photovoltaic blue','#3a5e88',.32,.45);orbitGlow=mat('Station ion light','#c0c7ff',.38,.15,1.1)

def ico(name,loc,scale,m,parent,seed=1,sub=1):
    rng=random.Random(seed);bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=sub,radius=1,location=loc);o=bpy.context.object;o.name=name;o.parent=parent;o.scale=scale;o.data.materials.append(m)
    for v in o.data.vertices:v.co*=rng.uniform(.84,1.12)
    return o

def torus(name,loc,major,minor,m,parent,rot=(0,0,0)):
    bpy.ops.mesh.primitive_torus_add(major_radius=major,minor_radius=minor,major_segments=48,minor_segments=6,location=loc,rotation=rot);o=bpy.context.object;o.name=name;o.parent=parent;o.data.materials.append(m);return o

def arch(name,radius,height,thickness,depth,m,parent):
    vs=[];fs=[];steps=28
    for i in range(steps+1):
        a=i/steps*math.pi
        for rad,y in [(radius+thickness,-depth/2),(radius+thickness,depth/2),(radius,-depth/2),(radius,depth/2)]:vs.append((math.cos(a)*rad,y,height+math.sin(a)*rad))
    for i in range(steps):
        k=i*4;fs.extend([(k,k+4,k+5,k+1),(k+2,k+3,k+7,k+6),(k,k+2,k+6,k+4),(k+1,k+5,k+7,k+3)])
    fs.extend([(0,1,3,2),(steps*4,steps*4+2,steps*4+3,steps*4+1)]);mesh(name,vs,fs,m,parent)
    for side in [-1,1]:box(name+' pier',(side*(radius+thickness/2),0,height/2),(thickness,depth,height),m,parent,.035)

def city(name,height,variant):
    r=root(name);box('Recessed masonry tower',(0,0,height/2),(6,3.5,height),steel,r,.08)
    box('Stone podium',(0,0,.3),(6.3,3.8,.6),concrete,r,.035)
    for x in [-2.5,-1.25,0,1.25,2.5]:
        box('Storefront glazing',(x,-1.78,1.5),(1.05,.045,2.1),glass,r)
        box('Shop mullion',(x-.58,-1.83,1.5),(.07,.09,2.2),concrete,r,.01)
    box('Projecting canopy',(0,-2.05,2.78),(6.5,1,.16),steel,r,.035);box('Canopy neon',(0,-2.55,2.72),(6.2,.035,.035),cyan,r)
    for level in range(int((height-3)/1.5)):
        z=3.7+level*1.5
        for j,x in enumerate([-2.3,-1.15,0,1.15,2.3]):
            box('Inset window shadow',(x,-1.78,z),(.88,.06,1.05),navy,r,.025)
            box('Warm recessed window',(x,-1.83,z),(.67,.025,.83),warm if (level+j+variant)%4 else glass,r)
            box('Window lintel',(x,-1.92,z+.55),(1,.18,.09),concrete,r,.015)
            box('Window divider',(x,-1.86,z),(.025,.025,.86),steel,r)
        if level%2==variant%2:
            box('Balcony slab',(0,-2,z-.6),(4.9,.8,.12),concrete,r,.025)
            branch('Balcony handrail',[(-2.4,-2.35,z-.1),(2.4,-2.35,z-.1)],[.025,.025],steel,r,5)
            for x in np.linspace(-2.3,2.3,13):box('Balcony baluster',(float(x),-2.35,z-.35),(.035,.035,.5),steel,r)
    box('Deep roof cornice',(0,0,height),(6.5,4,.25),concrete,r,.04)
    box('Roof setback',(0,.2,height+.5),(4.5,2.4,.8),steel,r,.05)
    for x in [-1.2,1.2]:box('Roof HVAC unit',(x,.3,height+1.12),(1.25,1.2,.5),concrete,r,.04)
    box('Vertical neon casing',(-3.12,-1.85,4.6),(.4,.28,2.6),steel,r,.03)
    for z in [3.7,4.3,4.9,5.5]:box('Neon glyph',(-3.13,-2.02,z),(.22,.035,.36),pink if variant else cyan,r,.025)
    return r
city('City_Facade_A',10,0);city('City_Facade_B',13,1)
r=root('City_Street')
branch('Curved streetlight',[(0,0,.1),(0,0,3.5),(-.25,0,4.1),(-.75,0,4.3)],[.065,.055,.05,.04],steel,r,8)
box('Lamp shade',(-.75,0,4.25),(.65,.35,.12),steel,r,.035);box('Lamp diffuser',(-.75,0,4.18),(.48,.26,.025),warm,r)
box('Planter',(1.1,0,.25),(1.1,1,.5),concrete,r,.08)
foliage=mat('Planter foliage','#4b7168',1)
for i in range(7):ico('Planter greenery',(1.1+math.sin(i)*.3,math.cos(i)*.25,.65),(.3,.3,.3),foliage,r,i)
r=root('City_Clocktower')
for i in range(4):box('Art deco setback',(0,0,3+i*5),(9-i*1.5,6-i*.8,6),steel,r,.08)
for x in [-2.6,2.6]:box('Vertical stone rib',(x,-2.6,9),(.35,.4,18),concrete,r,.025)
for z in [3,7,11,15]:box('Illuminated floor line',(0,-3.1,z),(7,.04,.1),warm,r)
torus('Clock bezel',(0,-2.1,20),1.6,.08,gold,r,(math.pi/2,0,0))
bpy.ops.mesh.primitive_cylinder_add(vertices=48,radius=1.5,depth=.06,location=(0,-2.1,20),rotation=(math.pi/2,0,0));o=bpy.context.object;o.parent=r;o.data.materials.append(navy)
branch('Clock minute hand',[(0,-2.18,20),(.1,-2.18,21.2)],[.045,.045],warm,r);branch('Clock hour hand',[(0,-2.2,20),(-.85,-2.2,19.6)],[.06,.06],warm,r)
for i in range(12):a=i*math.tau/12;box('Clock tick',(math.sin(a)*1.3,-2.18,20+math.cos(a)*1.3),(.08,.04,.12),gold,r)
branch('Spire',[(0,0,22),(0,0,27)],[.3,.03],concrete,r,8)

for variant in [0,1]:
    r=root('Ice_Cliff_'+('A' if not variant else 'B'))
    for j in range(5):
        h=5+(j*3+variant*2)%6;z=j*2.1-4.2
        ico('Sculpted glacier face',(.8+j%2*.7,z,h*.42),(2.1,1.8,h*.62),iceDark if j%2 else ice,r,j+variant*13,2)
        for k in range(3):ico('Stratified ice shelf',(.6,z,1.5+k*1.5),(2,1.7,.13),snow,r,j+k)
        branch('Frozen vertical seam',[(-.8,z,.5),(-.9,z+.12,2),(-.65,z,3.5),(-.3,z+.2,5)],[.025]*4,iceGlow,r,5)
r=root('Ice_Crystals')
for i in range(7):
    a=i*2.399;h=1.6+i%3*.6;x=math.cos(a)*.55;y=math.sin(a)*.6
    branch('Hexagonal crystal',[(x,y,0),(x+.15,y,h*.8),(x+.18,y,h)],[.18,.18,.005],ice if i%2 else iceGlow,r,5)
ico('Snow crystal footing',(0,0,.06),(.9,.85,.12),snow,r,7)
r=root('Ice_Arch');arch('Glacial bridge',6.4,3.6,1.1,3.5,iceDark,r)
for i in range(13):a=i/12*math.pi;ico('Snow on bridge crest',(math.cos(a)*7.2,0,3.6+math.sin(a)*7.2),(1,1.8,.3),snow,r,i)
r=root('Ice_Mountain')
for i in range(5):
    x=(i-2)*5;h=12+i*7%13
    ico('Asymmetric mountain',(x,i%2*3,h*.35),(7,7,h*.7),iceDark,r,i,1)
    ico('Glacier summit',(x,i%2*3,h*.8),(3.1,3.1,h*.22),snow,r,i+11,1)

r=root('Orbit_Dock')
box('Dock foundation',(1,0,-.2),(4,12,.5),navy,r,.06)
for j in range(4):
    y=j*3-4.5;box('Outer structural wall',(2.5,y,1.7),(.45,2.8,3.4),alloy,r,.04)
    branch('Swept structural rib',[(2.5,y,.4),(2.3,y,2.4),(.8,y,4),(-.8,y,4.5)],[.15]*4,alloy,r,8)
    branch('Rib ion strip',[(2.2,y-.12,2.5),(.8,y-.12,3.85),(-.7,y-.12,4.35)],[.035]*3,orbitGlow,r,5)
    box('Recessed equipment panel',(2.23,y,1.6),(.06,2.4,2.3),navy,r,.02)
    for k in range(4):box('Panel vent',(2.17,y,1+k*.34),(.04,1.7,.05),panel,r)
    box('Dock edge light',(-.6,y,.09),(.08,1.9,.04),orbitGlow,r)
for z in [.6,.85]:branch('Routed service pipe',[(1.7,-5,.3),(1.7,-3,z),(2,-1,z),(2,4,z),(2.5,5,.3)],[.08]*5,alloy,r,7)
r=root('Orbit_Gantry');arch('Open orbital arch',10.2,4.3,.38,.65,alloy,r);arch('Ion rim',10.05,4.3,.06,.72,orbitGlow,r)
for i in range(11):a=i*math.pi/10;box('Gantry docking block',(math.cos(a)*10.4,0,4.3+math.sin(a)*10.4),(.7,1,.7),navy,r,.04)
r=root('Orbit_Satellite')
box('Satellite core',(0,0,1.2),(1.6,1.1,1.4),alloy,r,.12)
for side in [-1,1]:
    box('Solar array frame',(side*2.6,0,1.2),(3.3,.12,2.3),alloy,r,.04)
    for j in range(5):
        for k in range(3):box('Individual solar cell',(side*2.6+(j-2)*.59,-.075,.55+k*.65),(.53,.025,.58),panel,r,.015)
branch('Communications mast',[(0,0,1.8),(0,0,3)],[.06,.04],alloy,r,6)
torus('Antenna hoop',(0,0,2.8),.4,.035,orbitGlow,r)
r=root('Orbit_Planet')
y,x=np.mgrid[0:256,0:512];bands=.5+.2*np.sin(y*.11+np.sin(x*.025)*.7)+.07*np.sin(y*.7);a=np.ones((256,512,4),np.float32);a[:,:,:3]=np.clip(bands[:,:,None]*np.array([.75,.82,1.05])+.14,0,1);image=texture('Original banded planet',a)
pm=mat('Planet atmosphere','#ffffff',1);p=pm.node_tree.nodes.get('Principled BSDF');tx=pm.node_tree.nodes.new('ShaderNodeTexImage');tx.image=image;pm.node_tree.links.new(tx.outputs['Color'],p.inputs['Base Color'])
bpy.ops.mesh.primitive_uv_sphere_add(segments=48,ring_count=24,radius=9);o=bpy.context.object;o.parent=r;o.name='Banded planet';o.data.materials.append(pm)
for p in o.data.polygons:p.use_smooth=True
# Broad annulus with separated bands instead of a thin torus.
for inner,outer in [(11.8,13),(13.4,16.5),(17,17.5)]:
    vs=[];fs=[]
    for i in range(97):
        a=i/96*math.tau
        for rr in [inner,outer]:vs.append((math.cos(a)*rr,math.sin(a)*rr*.5,math.sin(a)*rr*.28))
    for i in range(96):k=i*2;fs.append((k,k+1,k+3,k+2))
    ringmat=mat('Planet ring '+str(inner),'#b6a7c4',1);ringmat.use_backface_culling=False;mesh('Inclined dust ring',vs,fs,ringmat,r)

r=root('Ember_Colonnade')
for y in [-4,4]:
    box('Basalt plinth',(0,y,.2),(1.8,1.7,.4),stone,r,.08)
    branch('Fluted basalt shaft',[(0,y,.4),(0,y,3.6)],[.5,.45],stone,r,8)
    for z,w in [(3.5,1.2),(3.8,1.55)]:box('Carved capital',(0,y,z),(w,1.6,.3),edge,r,.035)
    for z in [1,1.6,2.2,2.8]:box('Inset rune',(-.49,y-.05,z),(.025,.34,.09),gold,r)
# Arch turned along the avenue; the whole arcade stays beside the road.
sub=bpy.data.objects.new('Arcade arch transform',None);bpy.context.collection.objects.link(sub);sub.parent=r;sub.rotation_euler.z=math.pi/2
arch('Weathered arcade arch',3.5,1,.45,1.1,stone,sub)
# Reparent transformed mesh children with transforms applied for batching.
for child in list(sub.children):world=child.matrix_world.copy();bpy.context.view_layer.update();world=child.matrix_world.copy();child.parent=r;child.matrix_world=world
bpy.data.objects.remove(sub,do_unlink=True)
box('Ruined arcade footing',(.25,0,.06),(2.8,10,.22),stone,r,.06)
for i in range(6):ico('Broken fallen stone',(1.2+math.sin(i)*.4,i*1.5-4,.3),(.6,.55,.35),edge,r,i)
r=root('Ember_River')
vs=[];fs=[]
for i in range(25):
    y=i*.5-6;x=math.sin(i*.28)*.25
    for side in [-1,1]:vs.append((x+side*.48,y,.04))
for i in range(24):k=i*2;fs.append((k,k+1,k+3,k+2))
mesh('Continuous molten channel',vs,fs,lava,r)
for side in [-1,1]:
    for i in range(8):ico('Cooling basalt banks',(side*.7+math.sin(i)*.1,i*1.55-5.5,.04),(.32,.9,.15),stone,r,i)
for i in range(10):ico('Floating lava crust',(math.sin(i*4)*.25,i*1.1-5,.065),(.15,.28,.025),lavared,r,i)
r=root('Ember_Temple')
for level in range(6):
    box('Terraced temple',(0,0,.8+level*1.45),(14-level*1.8,12-level*1.5,1.5),stone,r,.06)
    box('Carved ledge',(0,-6+level*.75,1.55+level*1.45),(13.8-level*1.8,.14,.12),edge,r,.025)
    for k in range(3):box('Ascending staircase',(0,-6.5+level*.75+k*.22,.25+level*1.45+k*.46),(2.4,.8,.42),edge,r,.025)
arch('Sanctuary arch',.85,1,.3,1,edge,r)
for x in [-3.5,3.5]:
    box('Brazier pedestal',(x,-6,.7),(.9,.9,1.4),stone,r,.04);ico('Brazier flame',(x,-6,1.7),(.18,.18,.6),lava,r,4)
r=root('Ember_Volcano')
vs=[];fs=[];steps=32
for height,rad in [(0,17),(6,11),(14,5),(13,3.4)]:
    for i in range(steps):a=i/steps*math.tau;radius=rad*(1+.09*math.sin(i*5));vs.append((math.cos(a)*radius,math.sin(a)*radius,height+.4*math.sin(i*3)))
for level in range(3):
    for i in range(steps):j=(i+1)%steps;fs.append((level*steps+i,level*steps+j,(level+1)*steps+j,(level+1)*steps+i))
mesh('Open volcanic crater',vs,fs,stone,r);torus('Luminous crater lip',(0,0,13.7),3.5,.18,lava,r)
for i in range(5):
    a=i*2.399;branch('Molten fissure',[(math.cos(a)*4,math.sin(a)*4,13.6),(math.cos(a)*7,math.sin(a)*7,9),(math.cos(a+.08)*10,math.sin(a+.08)*10,5)],[.06,.1,.03],lavared,r,5)
# Join by asset. Blender's exporter emits one primitive per material.
for asset in assets:
    children=[o for o in asset.children if o.type=='MESH'];bpy.ops.object.select_all(action='DESELECT')
    for o in children:o.select_set(True)
    bpy.context.view_layer.objects.active=children[0];bpy.ops.object.join();o=bpy.context.object;o.name=asset.name+'_Mesh';bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
path=os.path.join(ROOT,'src/assets/arcade-worlds.glb')
bpy.ops.export_scene.gltf(filepath=path,export_format='GLB',export_cameras=False,export_lights=False,export_animations=False,export_apply=True,export_yup=True)
triangles=0
for asset in assets:
    for ob in asset.children:ob.data.calc_loop_triangles();triangles+=len(ob.data.loop_triangles)
# An editable asset board, organized into four named areas after export.
for world,prefix in enumerate(['City_','Ice_','Orbit_','Ember_']):
    for i,asset in enumerate(a for a in assets if a.name.startswith(prefix)):asset.location=(world*45,i*24,0)
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(ROOT,'sources/blender/arcade-worlds.blend'),compress=True)
report={'blender':bpy.app.version_string,'roots':[a.name for a in assets],'triangles':triangles,'glbBytes':os.path.getsize(path)}
with open(os.path.join(ROOT,'artifacts/blender/worlds-budget.json'),'w') as f:json.dump(report,f,indent=2)
print('WORLD_ASSETS',json.dumps(report))
