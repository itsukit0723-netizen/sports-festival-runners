import fs from 'node:fs';import path from 'node:path';
const stage=path.resolve(process.argv[2]??'artifacts/runner-source-20261025');fs.mkdirSync(stage,{recursive:true});
const excluded=new Set(['node_modules','dist','.git','artifacts','.firebase','dodgeball']);
function copy(source,dest){fs.cpSync(source,dest,{recursive:true,filter:p=>!excluded.has(path.basename(p))&&!/\.blend\d+$/.test(p)&&!/^\.env/.test(path.basename(p))});}
for(const item of ['src','scripts','tests','sources','.github'])copy(item,path.join(stage,item));
for(const file of ['package.json','package-lock.json','tsconfig.json','vite.config.ts','index.html','README.md','QA.md','QA-AUDIT-20261025.md','GOLDEN-TIME.md','start-arcade.cmd','start-mobile.cmd','.gitignore','AGENTS.md'])fs.copyFileSync(file,path.join(stage,file));
fs.mkdirSync(path.join(stage,'public'),{recursive:true});for(const item of ['.nojekyll','favicon.svg','licenses'])copy('public/'+item,path.join(stage,'public',item));
const packageFile=path.join(stage,'package.json'),p=JSON.parse(fs.readFileSync(packageFile,'utf8'));delete p.scripts['test:dodgeball'];delete p.scripts['validate:dodgeball'];fs.writeFileSync(packageFile,JSON.stringify(p,null,2)+'\n');
console.log('Two-game source staged. Local integration sources retained.');
