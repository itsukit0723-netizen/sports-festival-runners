import os from 'node:os';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
const root = fileURLToPath(new URL('../', import.meta.url));
const port = 4173;
const addresses = Object.entries(os.networkInterfaces()).flatMap(([name, entries]) =>
  (entries ?? []).filter(entry => entry.family === 'IPv4' && !entry.internal && /^(192\.168\.|10\.|172\.(1[6-9]|2\d|3[01])\.)/.test(entry.address))
    .map(entry => ({ name, address: entry.address }))
).sort((a, b) => Number(/virtual|vpn|vEthernet|docker|wsl/i.test(a.name)) - Number(/virtual|vpn|vEthernet|docker|wsl/i.test(b.name)));
console.log('\nSPORTS FESTIVAL ARCADE / スマホ用テストサーバー\n');
console.log('スマホをPCと同じWi-Fi・LANに接続して、次のURLを開いてください。');
for (const { name, address } of addresses) console.log(`  http://${address}:${port}/  (${name})`);
if (!addresses.length) console.log('  LANのIPv4アドレスを検出できませんでした。PCのネットワーク接続を確認してください。');
console.log(`\nPC用: http://localhost:${port}/`);
console.log('テスト中はPCとこのサーバーを起動したままにしてください。終了は Ctrl+C。\n');
// Serve only the production dist directory, rather than the source checkout.
const server = spawn(process.execPath, [fileURLToPath(new URL('../node_modules/vite/bin/vite.js', import.meta.url)), 'preview', '--host', '0.0.0.0', '--port', String(port), '--strictPort'], { cwd: root, stdio: 'inherit' });
server.on('error', error => { console.error(error.message); process.exitCode = 1; });
server.on('exit', code => { process.exitCode = code ?? 0; });
process.on('SIGINT', () => server.kill('SIGINT'));
process.on('SIGTERM', () => server.kill('SIGTERM'));
