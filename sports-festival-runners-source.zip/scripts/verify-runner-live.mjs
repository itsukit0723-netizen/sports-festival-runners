import fs from 'node:fs';import crypto from 'node:crypto';
const files=JSON.parse(fs.readFileSync('artifacts/manifest-20261023.json','utf8')),base='https://itsukit0723-netizen.github.io/sports-festival-runners/';
const results=await Promise.all(files.map(async f=>{const res=await fetch(base+f.path+'?release=20261023',{cache:'no-store'});if(!res.ok)throw Error(`${f.path}: ${res.status}`);const b=Buffer.from(await res.arrayBuffer()),sha=crypto.createHash('sha1').update('blob '+b.length+'\0').update(b).digest('hex');return {path:f.path,match:sha===f.sha};}));
fs.writeFileSync('artifacts/live-check-20261023.json',JSON.stringify(results,null,2));const mismatches=results.filter(r=>!r.match);console.log(JSON.stringify({verified:results.length,mismatches}));if(mismatches.length)process.exit(1);
