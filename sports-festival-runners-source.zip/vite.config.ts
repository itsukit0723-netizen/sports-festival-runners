import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
export default defineConfig({
  base: './',
  plugins: [react()],
  build: { rollupOptions: { output: { manualChunks: id => id.includes('node_modules/three/') ? 'three' : undefined } } },
  server: { host: '127.0.0.1' },
});
