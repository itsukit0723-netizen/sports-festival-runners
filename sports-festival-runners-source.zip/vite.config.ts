import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { cpSync, mkdirSync } from 'node:fs';
import { resolve } from 'node:path';
// Only these public files belong to the two-game Pages release. Other local
// game integrations can remain in public/ without entering the shipped build.
export const RUNNER_PUBLIC_FILES = ['.nojekyll', 'favicon.svg', 'licenses'] as const;
export default defineConfig(({ command }) => ({
  base: './',
  publicDir: command === 'serve' ? 'public' : false,
  plugins: [react(), {
    name: 'runner-public-files',
    apply: 'build',
    writeBundle(options) {
      const output = resolve(options.dir ?? 'dist');
      mkdirSync(output, { recursive: true });
      for (const file of RUNNER_PUBLIC_FILES) cpSync(resolve('public', file), resolve(output, file), { recursive: true });
    },
  }],
  build: { rollupOptions: { output: { manualChunks: id => id.includes('node_modules/three/') ? 'three' : undefined } } },
  server: { host: '127.0.0.1' },
}));
