# Blender制作データ：夜桜の参道

- `sakura-garden.blend`：Blender 5.2.2 LTSで制作した編集用プロジェクト。桜2種類、石灯籠、鳥居、神社、植栽床と、参道の確認用レイアウトを収録。
- `../../scripts/blender/create_sakura.py`：外部素材を使わず、形状と花・木肌の画像を生成する制作スクリプト。Blenderのバックグラウンド実行で再生成できる。
- `../../src/assets/sakura-garden.glb`：ゲーム用の6種類の再利用モデル。花の透過と木肌の画像を内包。約1.29MB、全モデル合計19,170三角形。

ゲームでの表示はThree.js側の照明と配置で仕上げています。Blenderのレンダリングプレビューとブラウザーの描画は同一ではありません。

再生成例：`blender --background --python scripts/blender/create_sakura.py`。Store版の場合はBlenderの実行エイリアスへ同じ引数を渡してください。出力は作業フォルダー内の上記ファイルと `artifacts/blender/` に保存されます。

桜のモデルの読み込み中・失敗時は通常ゲームの既存の桜背景を維持します。鑑賞用 `?preview=sakura` は読み込み完了を待ってから走行し、スコアを保存しません。
