# Blender制作データ：夜桜の参道

- `sakura-garden.blend`：Blender 5.2.2 LTSで制作した編集用プロジェクト。桜2種類、石灯籠、鳥居、神社、植栽床と、参道の確認用レイアウトを収録。
- `../../scripts/blender/create_sakura.py`：外部素材を使わず、形状と花・木肌の画像を生成する制作スクリプト。Blenderのバックグラウンド実行で再生成できる。
- `../../src/assets/sakura-garden.glb`：ゲーム用の6種類の再利用モデル。花の透過と木肌の画像を内包。約1.29MB、全モデル合計19,170三角形。

ゲームでの表示はThree.js側の照明と配置で仕上げています。Blenderのレンダリングプレビューとブラウザーの描画は同一ではありません。

再生成例：`blender --background --python scripts/blender/create_sakura.py`。Store版の場合はBlenderの実行エイリアスへ同じ引数を渡してください。出力は作業フォルダー内の上記ファイルと `artifacts/blender/` に保存されます。

桜のモデルの読み込み中・失敗時は通常ゲームの既存の桜背景を維持します。鑑賞用 `?preview=sakura` は読み込み完了を待ってから走行し、スコアを保存しません。

## 残り4世界のBlender制作

`arcade-worlds.blend` はネオン街・氷の峡谷・宇宙回廊・溶岩遺跡の編集用モデル集です。17種類のモデルを、世界ごとのエリアへ並べています。

- ネオン街：店舗とバルコニーのある建物2種、街灯と植栽、時計塔。
- 氷の峡谷：氷壁2種、結晶、雪の積もった橋、山並み。
- 宇宙回廊：設備パネルと配管のあるドック、巨大ゲート、衛星、模様付き惑星と多重リング。
- 溶岩遺跡：彫り込みのある列柱とアーチ、溶岩水路、階段状神殿、火口のある火山。

`../../scripts/blender/create_worlds.py` で再生成します。このスクリプトは同じフォルダーの `create_sakura.py` から自作の形状生成ヘルパーだけを読み取ります。出力 `../../src/assets/arcade-worlds.glb` は約3.22MB、39,446三角形。全17モデルをゲーム内で繰り返し配置し、同じ形状と材質を共有します。

`?preview=worlds` で5世界の自動切り替え、`?preview=city` / `ice` / `orbit` / `ember` / `sakura` で個別表示できます。プレビューはスコアを保存しません。

football-players.blend: 関節付きの人と32パネルのボール。scripts/blender/create_players.py で再生成。
HazardBall: 障害物専用の銅色／黒パネル球。白いMatchBallとは別ルート、単位半径1。
