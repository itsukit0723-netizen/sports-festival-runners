@echo off
cd /d "%~dp0"
if not exist node_modules\vite (
  call npm.cmd install
  if errorlevel 1 exit /b 1
)
echo Open the Local URL shown below in your browser.
call npm.cmd run dev -- --open
