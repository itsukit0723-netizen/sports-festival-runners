export interface GoldenSetting { enabled: boolean; eventId: string; revision: string; updatedAt: number }
export interface GoldenRun extends GoldenSetting { readonly multiplier: 1 | 2; readonly preview: boolean }
export const GOLDEN_OFF: GoldenRun = Object.freeze({ enabled:false,eventId:'none',revision:'none',updatedAt:0,multiplier:1,preview:false });
export function captureGolden(value: unknown, preview=false): GoldenRun {
  if(value == null)return GOLDEN_OFF;
  const v=value as GoldenSetting;
  if(typeof v.enabled!=='boolean'||typeof v.eventId!=='string'||!v.eventId||v.eventId.length>80||typeof v.revision!=='string'||!v.revision||v.revision.length>80||!Number.isFinite(v.updatedAt)||v.updatedAt<0)throw Error('イベント情報を取得できませんでした。通信を確認して、もう一度開始してください。');
  return Object.freeze({enabled:v.enabled,eventId:v.eventId,revision:v.revision,updatedAt:v.updatedAt,multiplier:v.enabled?2:1,preview});
}
export const goldenScore=(raw:number,run:GoldenRun)=>Math.floor(Math.max(0,raw))*run.multiplier;
export const goldenNotice=(text:string,run:GoldenRun)=>text.replace(/\+(\d+)/g,(_,n)=>'+'+(Number(n)*run.multiplier));
export function goldenRecord(raw:number,run:GoldenRun){return {golden:run.enabled,baseScore:Math.floor(Math.max(0,raw)),scoreMultiplier:run.multiplier,goldenEventId:run.enabled?run.eventId:'none',goldenRevision:run.revision,score:goldenScore(raw,run)};}
let reader:()=>Promise<unknown>=async()=>null;
/** The host app supplies its own trusted, shared event service. A fresh read is required for EVERY retry. */
export function configureGoldenReader(next:()=>Promise<unknown>){reader=next;}
export async function goldenAtStart():Promise<GoldenRun>{
  if(typeof location!=='undefined'&&new URLSearchParams(location.search).get('golden')==='preview')return captureGolden({enabled:true,eventId:'preview',revision:'preview',updatedAt:0},true);
  return captureGolden(await reader());
}
