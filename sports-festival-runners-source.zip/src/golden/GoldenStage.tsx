import {useEffect,useState} from 'react';
import type {GameId,GameStats} from '../core/types';
import {goldenAtStart,type GoldenRun} from './policy';
import './golden.css';
export function GoldenLobby(){
 const [enabled,setEnabled]=useState(false);
 useEffect(()=>{let alive=true;const refresh=()=>void goldenAtStart().then(v=>{if(alive)setEnabled(v.enabled);}).catch(()=>{if(alive)setEnabled(false);});refresh();const timer=setInterval(refresh,5000);window.addEventListener('focus',refresh);return()=>{alive=false;clearInterval(timer);window.removeEventListener('focus',refresh);};},[]);
 return enabled?<div className="golden-lobby" role="status"><span>✦ LIVE EVENT</span><strong>GOLDEN TIME</strong><p>バスケ・サッカーの新しいプレイは、豪華演出＋スコア2倍。</p></div>:null;
}
export function GoldenStage({run,game,stats,paused}:{run:GoldenRun;game:GameId;stats:GameStats;paused:boolean}){
 if(!run.enabled)return null;
 const football=game==='rollingFootball';
 return <div className={`golden-stage ${football?'golden-field':'golden-court'} ${paused?'golden-paused':''} ${stats.over?'golden-finale':''}`} aria-hidden="true">
  <div className="golden-edge"/><div className="golden-corner golden-corner-left"/><div className="golden-corner golden-corner-right"/>
  <div className="golden-motes">{Array.from({length:22},(_,i)=><i key={i} style={{left:`${i<11?2+i%4*2:90+i%4*2}%`,top:`${(i*31)%95}%`,animationDelay:`${-i*.71}s`,animationDuration:`${4+i%5}s`}}/>)}</div>
  <div className="golden-live"><span className="golden-live-dot"/>GOLDEN TIME <b>×2</b></div>
  {stats.time<2.4&&!stats.over&&<div className="golden-entrance"><svg viewBox="0 0 320 90"><path d="m15 60 45-8-20-13 53 8-12-24 49 25 30-32 30 32 49-25-12 24 53-8-20 13 45 8-50 12H65z" fill="none" stroke="currentColor" strokeWidth="2"/><path d="m140 33 20-22 20 22-20 22z" fill="currentColor"/></svg><small>THE FESTIVAL SPECIAL</small><strong>GOLDEN<br/>TIME<span>✦</span></strong><em>{football?'CHAMPIONS PARADE':'CROWN COURT'}</em><p>獲得スコア ×2</p></div>}
  {!stats.over&&stats.combo>=5&&<div className="golden-chain" key={Math.floor(stats.combo/5)}><span>✦</span> {stats.combo} <small>GOLD CHAIN</small></div>}
  {stats.over&&<div className="golden-result-rays"/>}
 </div>;
}
