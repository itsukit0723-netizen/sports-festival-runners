import {configureGoldenReader} from './policy';
export const GOLDEN_DATABASE='https://sports-festival-three-2026-default-rtdb.asia-southeast1.firebasedatabase.app';
/** Replace the URL/path here when the festival host app takes over event management. */
export function connectGoldenService(databaseUrl=GOLDEN_DATABASE,eventPath='events/goldenTime'){
 configureGoldenReader(async()=>{
  const response=await fetch(databaseUrl+'/'+eventPath+'.json',{cache:'no-store',signal:AbortSignal.timeout(8000)});
  if(!response.ok)throw Error('イベント状態を確認できませんでした。通信を確認して、もう一度開始してください。');
  return response.json();
 });
}
connectGoldenService();
