import { lazy, Suspense, useState } from 'react';
import { getBest, getSound, saveSound } from './core/storage';
import type { GameId } from './core/types';
import { Icon } from './ui/Icon';
import { CardArt } from './ui/CardArt';
const GameView = lazy(() => import('./ui/GameView'));
const SakuraPreview = lazy(() => import('./ui/SakuraPreview'));
const showSakura = new URLSearchParams(window.location.search).get('preview') === 'sakura';
export default function App() {
  const [game, setGame] = useState<GameId | null>(null);
  const [sound, setSound] = useState(getSound);
  const [bests, setBests] = useState(() => ({ basketballRunner: getBest('basketballRunner'), rollingFootball: getBest('rollingFootball') }));
  const toggleSound = () => setSound(previous => { saveSound(!previous); return !previous; });
  if (showSakura) return <Suspense fallback={<div className="loading-screen">桜の世界を準備しています…</div>}><SakuraPreview/></Suspense>;
  if (game) return <Suspense fallback={<div className="loading-screen"><span className="brand-mark"><Icon name="bolt" size={32}/></span><p>GETTING THE GAME READY…</p></div>}><GameView id={game} best={bests[game]} sound={sound} onToggleSound={toggleSound} onBest={score => setBests(b => ({ ...b, [game]: score }))} onHome={() => setGame(null)}/></Suspense>;
  return <div className="lobby">
    <header className="site-header">
      <a className="brand" href="#" aria-label="Sports Festival Arcade ホーム"><span className="brand-mark"><Icon name="bolt" size={25}/></span><span>SPORTS FESTIVAL<span className="brand-sub">THE ARCADE COLLECTION</span></span></a>
      <div className="header-right"><span className="edition">PLAY FOR THE MOMENT.</span><button className="sound-toggle" onClick={toggleSound} aria-label={sound ? 'サウンドをオフにする' : 'サウンドをオンにする'} aria-pressed={sound}><Icon name={sound ? 'sound' : 'mute'} size={17}/><span>SOUND {sound ? 'ON' : 'OFF'}</span></button></div>
    </header>
    <main>
      <section className="hero">
        <div className="eyebrow"><span className="status-dot"/> LESS RULES. MORE PLAY.</div>
        <h1>SPORTS FESTIVAL<br/><span>ARCADE<span className="hero-spark">✳</span></span></h1>
        <div className="hero-bottom"><p>ひと息ついたら、ひと勝負。<br className="mobile-break"/>指先で、自己ベストのその先へ。</p><span className="hero-note"><span>2 GAMES</span><span>∞ POSSIBILITIES</span></span></div>
        <div className="hero-orbit" aria-hidden="true"><div/><span>LET’S<br/>PLAY.</span><Icon name="arrow" size={48}/></div>
      </section>
      <section className="game-selection" aria-label="ゲームを選ぶ">
        <div className="section-label"><span><i/> SELECT YOUR GAME</span><span>CHOOSE. PLAY. REPEAT.</span></div>
        <div className="cards">
          <article className="game-card basketball-card">
            <div className="art-wrap"><CardArt/><span className="art-badge">01 <span>/ ONE-TAP RUNNER</span></span><span className="genre-label">JUMP INTO IT ↗</span></div>
            <div className="card-body"><div className="card-heading"><span className="game-category">THE COURT IS CALLING</span><span className="difficulty-dots" aria-label="シンプル操作"><i/><i/><i/></span></div>
              <h2>BASKETBALL<br/>RUNNER<span className="title-arrow">↗</span></h2><p className="game-description">跳んで、集めて、突き進め！</p>
              <div className="card-meta"><span className="control-hint"><Icon name="tap" size={18}/><span>タップでジャンプ <span className="desktop-key">/ SPACE</span></span></span><span className="best-score"><Icon name="trophy" size={14}/><span>BEST <b>{bests.basketballRunner.toLocaleString()}</b></span></span></div>
              <button className="play-button" onClick={() => setGame('basketballRunner')} aria-label="BASKETBALL RUNNERをプレイ"><span><Icon name="play" size={18}/>PLAY NOW</span><Icon name="arrow" size={21}/></button>
            </div>
          </article>
          <article className="game-card football-card">
            <div className="art-wrap"><CardArt football/><span className="art-badge">02 <span>/ 3D ENDLESS ROLL</span></span><span className="genre-label">FIND YOUR FLOW ↗</span></div>
            <div className="card-body"><div className="card-heading"><span className="game-category">MAKE YOUR OWN WAY</span><span className="difficulty-dots" aria-label="シンプル操作"><i/><i/><i/></span></div>
              <h2>ROLLING<br/>FOOTBALL<span className="title-arrow">↗</span></h2><p className="game-description">転がって、避けて、どこまでも！</p>
              <div className="card-meta"><span className="control-hint"><Icon name="move" size={19}/><span>左右ドラッグ <span className="desktop-key">/ ← →</span></span></span><span className="best-score"><Icon name="trophy" size={14}/><span>BEST <b>{bests.rollingFootball.toLocaleString()}</b></span></span></div>
              <button className="play-button" onClick={() => setGame('rollingFootball')} aria-label="ROLLING FOOTBALLをプレイ"><span><Icon name="play" size={18}/>PLAY NOW</span><Icon name="arrow" size={21}/></button>
            </div>
          </article>
        </div>
      </section>
      <div className="play-manifesto"><span className="manifesto-symbol">✳</span><div><strong>ちょっとの挑戦が、いちばん楽しい。</strong><p>インストール不要。好きなゲームを選んで、すぐにプレイ。</p></div><span className="manifesto-detail">QUICK PLAY.<br/>BIG ENERGY.</span></div>
    </main>
    <footer className="site-footer"><span>© SPORTS FESTIVAL ARCADE</span><span>MADE FOR THE LOVE OF THE GAME <span className="footer-dot">●</span></span><span>記録はこのブラウザーに保存されます</span></footer>
  </div>;
}
