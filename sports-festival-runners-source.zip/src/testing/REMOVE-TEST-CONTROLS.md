# テスト無敵の撤去

一時的に無効にする場合は `TemporaryInvincibility.tsx` の `ENABLE_TEMP_TEST_CONTROLS` をfalseにします。表示も無敵入力も無効になります。状態は保存せず、ゲーム選択・リトライでOFFに戻ります。一度でもONにしたプレイはBESTに保存しません。

完全削除する場合:

1. `ui/GameView.tsx` の TEMP TEST CONTROLS インポート・hook・ボタンを削除し、`testControls.apply(input)`を元のinputに戻す。BEST保存時の`testControls.used.current`条件も削除する。
2. `core/types.ts` の `GameInput.testInvincible` を削除する。
3. `basketball/model.ts` と `football/model.ts` の `input.testInvincible` 条件を削除し、通常の衝突判定へ戻す。
4. `tests/games.test.ts` の TEMP TEST CONTROLS 節とこの `testing/` フォルダーを削除する。ほかの長時間検証で使っている `testInvincible` 入力は、同ファイルの通常ジャンプ／安全通路の操作に置き換える。`rg "testInvincible|testControls|TemporaryInvincibility" src tests` で参照が残っていないことを確認する。
5. テスト・本番ビルド後、GitHub PagesとソースZIPも更新する。

通常のFEVERアイテムとは独立しています。テスト無敵は速度・ジャンプ・アイテム時間・障害物生成を変えません。
