// TEMP TEST CONTROLS: flip this one flag off to hide the UI and disable its input.
// Full removal instructions: src/testing/REMOVE-TEST-CONTROLS.md.
import { useEffect, useRef, useState } from 'react';
import type { GameInput, GameStats } from '../core/types';
import './temporary-controls.css';
export const ENABLE_TEMP_TEST_CONTROLS = true;

export function useTemporaryInvincibility(run: number) {
  const [active, setActive] = useState(false);
  const activeRef = useRef(false), used = useRef(false);
  useEffect(() => { activeRef.current = false; used.current = false; setActive(false); }, [run]);
  const toggle = () => {
    activeRef.current = ENABLE_TEMP_TEST_CONTROLS && !activeRef.current;
    used.current ||= activeRef.current; setActive(activeRef.current);
  };
  const apply = (input: GameInput): GameInput => ({ ...input, testInvincible: ENABLE_TEMP_TEST_CONTROLS && activeRef.current });
  return { active, toggle, apply, used };
}

export function TemporaryInvincibilityButton({ active, toggle, stats }: {
  active: boolean; toggle(): void; stats: GameStats;
}) {
  if (!ENABLE_TEMP_TEST_CONTROLS) return null;
  return <div className="temporary-invincibility">
    <button type="button" aria-label="テスト用の無敵を切り替える" aria-pressed={active}
      onPointerDown={e => e.stopPropagation()}
      onKeyDown={e => { if (e.code === 'Space' || e.code === 'Enter') e.stopPropagation(); }}
      onClick={e => { e.stopPropagation(); toggle(); e.currentTarget.blur(); }}
      >
      無敵 {active ? 'ON' : 'OFF'} <span>TEST</span>
    </button>
    <div className="temporary-meta">
      {stats.time.toFixed(1)}秒 · SPEED {Math.round(stats.speed)}
    </div>
  </div>;
}
