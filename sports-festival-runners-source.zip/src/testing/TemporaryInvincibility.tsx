// TEMP TEST CONTROLS: flip this one flag off to hide the UI and disable its input.
// Full removal instructions: src/testing/REMOVE-TEST-CONTROLS.md.
import { useEffect, useRef, useState } from 'react';
import type { GameInput, GameStats } from '../core/types';
export const ENABLE_TEMP_TEST_CONTROLS = true;

export function useTemporaryInvincibility(run: number) {
  const [active, setActive] = useState(false);
  const activeRef = useRef(false), used = useRef(false);
  useEffect(() => { activeRef.current = false; used.current = false; setActive(false); }, [run]);
  const toggle = () => {
    activeRef.current = ENABLE_TEMP_TEST_CONTROLS && !activeRef.current;
    used.current ||= activeRef.current; setActive(activeRef.current);
  };
  const apply = (input: GameInput): GameInput => ({ ...input, testInvincible: ENABLE_TEMP_TEST_CONTROLS && activeRef.current });
  return { active, toggle, apply, used };
}

export function TemporaryInvincibilityButton({ active, toggle, stats }: {
  active: boolean; toggle(): void; stats: GameStats;
}) {
  if (!ENABLE_TEMP_TEST_CONTROLS) return null;
  return <div style={{ position: 'absolute', top: 77, right: 12, zIndex: 4, textAlign: 'right', pointerEvents: 'auto' }}>
    <button type="button" aria-label="テスト用の無敵を切り替える" aria-pressed={active}
      onPointerDown={e => e.stopPropagation()}
      onKeyDown={e => { if (e.code === 'Space' || e.code === 'Enter') e.stopPropagation(); }}
      onClick={e => { e.stopPropagation(); toggle(); e.currentTarget.blur(); }}
      style={{ minHeight: 44, padding: '8px 12px', border: '1px solid #d3f88a88', borderRadius: 8,
        background: active ? '#d3f88a' : '#162731dc', color: active ? '#172217' : '#e9eedb', fontSize: 12, fontWeight: 700 }}>
      無敵 {active ? 'ON' : 'OFF'} <span style={{ fontSize: 9, opacity: .75 }}>TEST</span>
    </button>
    <div style={{ marginTop: 5, color: '#f4eed8', background: '#182835bf', borderRadius: 4, padding: '3px 6px', fontSize: 10 }}>
      {stats.time.toFixed(1)}秒 · SPEED {Math.round(stats.speed)}
    </div>
  </div>;
}
