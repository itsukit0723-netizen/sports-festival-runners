import type { GameId } from './types';
const key = (id: GameId) => `sportsFestival.${id}.best`;
export function getBest(id: GameId) {
  try { const n = Number(localStorage.getItem(key(id))); return Number.isFinite(n) ? Math.max(0, n) : 0; }
  catch { return 0; }
}
export function saveBest(id: GameId, score: number) {
  const best = Math.max(getBest(id), Math.floor(score));
  try { localStorage.setItem(key(id), String(best)); } catch { /* Private / full storage: run remains playable. */ }
  return best;
}
export function getSound() { try { return localStorage.getItem('sportsFestival.sound') !== 'off'; } catch { return true; } }
export function saveSound(on: boolean) { try { localStorage.setItem('sportsFestival.sound', on ? 'on' : 'off'); } catch { /* optional preference */ } }
