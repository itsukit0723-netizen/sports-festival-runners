import type { GameId } from './types';
const key = (id: GameId, golden=false) => `sportsFestival.${id}.${golden?'golden.best':'best'}`;
export function getBest(id: GameId, golden=false) {
  try { const n = Number(localStorage.getItem(key(id,golden))); return Number.isFinite(n) ? Math.max(0, n) : 0; }
  catch { return 0; }
}
export function saveBest(id: GameId, score: number, golden=false) {
  const best = Math.max(getBest(id,golden), Math.floor(score));
  try { localStorage.setItem(key(id,golden), String(best)); } catch { /* Private / full storage: run remains playable. */ }
  return best;
}
export function getSound() { try { return localStorage.getItem('sportsFestival.sound') !== 'off'; } catch { return true; } }
export function saveSound(on: boolean) { try { localStorage.setItem('sportsFestival.sound', on ? 'on' : 'off'); } catch { /* optional preference */ } }
