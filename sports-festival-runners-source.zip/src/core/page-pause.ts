// Focus can move to browser chrome, an embedded frame or another control while
// the game remains visible. Only leaving the page warrants automatic pause.
export function bindPagePause(doc: EventTarget & { hidden: boolean }, page: EventTarget, pause: () => void) {
  const hide = () => { if (doc.hidden) pause(); };
  const leave = () => pause();
  doc.addEventListener('visibilitychange', hide);
  page.addEventListener('pagehide', leave);
  return () => { doc.removeEventListener('visibilitychange', hide); page.removeEventListener('pagehide', leave); };
}
