export type GameId = 'basketballRunner' | 'rollingFootball';
export type EffectKind = 'jump' | 'land' | 'coin' | 'boost' | 'fever' | 'smash' | 'near' | 'dribble' | 'bonus' | 'over';
export interface GameEvent { kind: EffectKind; x?: number; y?: number; z?: number; value?: number }
export interface GameInput { jump: boolean; axis: number; drag: number;
  /** Touch/pen only. Absent for the original full-height mouse/keyboard jump. */
  touchJump?: { held: boolean; pressure?: number };
  /** TEMP TEST CONTROLS: remove together with src/testing/. */
  testInvincible?: boolean;
}
export interface GameStats {
  routeHint?: string;
  time: number; score: number; coins: number; combo: number;
  speed: number; boost: number; fever: number; bonus: number; over: boolean;
}
export interface GameModel extends GameStats {
  update(dt: number, input: GameInput): void;
  events: GameEvent[];
}
export interface GameRenderer {
  render(dt: number, events: GameEvent[]): void;
  resize(): void;
  dispose(): void;
}
export class Random {
  constructor(private seed = (Math.random() * 0xffffffff) >>> 0) {}
  next() { this.seed = (Math.imul(this.seed, 1664525) + 1013904223) >>> 0; return this.seed / 4294967296; }
  pick<T>(items: readonly T[]): T { return items[Math.floor(this.next() * items.length)]; }
}
export const clamp = (v: number, lo: number, hi: number) => Math.max(lo, Math.min(hi, v));
export const emptyInput = (): GameInput => ({ jump: false, axis: 0, drag: 0 });
