import { Random } from './types';

// A shuffled deck visits every recipe before reshuffling, and avoids the last
// six recipes across a reshuffle. Randomness changes courses, never physics.
export class PatternDeck<T extends { id: string }> {
  private bag: T[] = [];
  private recent: string[] = [];
  constructor(private recipes: readonly T[], private random: Random) {
    if (recipes.length < 8) throw new Error('A pattern deck needs at least eight recipes');
  }
  next(): T {
    if (!this.bag.length) {
      this.bag = [...this.recipes];
      for (let i = this.bag.length - 1; i > 0; i--) {
        const j = Math.floor(this.random.next() * (i + 1));
        [this.bag[i], this.bag[j]] = [this.bag[j], this.bag[i]];
      }
    }
    const index = this.bag.findIndex(recipe => !this.recent.includes(recipe.id));
    const [recipe] = this.bag.splice(index, 1);
    this.recent = [...this.recent, recipe.id].slice(-6);
    return recipe;
  }
}

export const OPENING_SECONDS = 15;
export const OPENING_SEED = 1;
