import type { GameId, GameInput } from './types';
export class InputController {
  private keys = new Set<string>();
  private jumped = false;
  private delta = 0;
  private pointer: number | null = null;
  private lastX = 0;
  private touchJump: GameInput['touchJump'];
  private abort = new AbortController();
  constructor(private element: HTMLElement, private game: GameId, private pause: () => void, private activate: () => void) {
    const options = { signal: this.abort.signal };
    window.addEventListener('keydown', this.keydown, options);
    window.addEventListener('keyup', this.keyup, options);
    element.addEventListener('pointerdown', this.down, options);
    element.addEventListener('pointermove', this.move, options);
    element.addEventListener('pointerup', this.up, options);
    element.addEventListener('pointercancel', this.up, options);
    element.addEventListener('lostpointercapture', this.up, options);
    window.addEventListener('blur', this.reset, options);
  }
  private keydown = (e: KeyboardEvent) => {
    const buttonSpace = e.code === 'Space' && e.target instanceof HTMLButtonElement;
    if (!buttonSpace && ['Space', 'ArrowLeft', 'ArrowRight', 'KeyA', 'KeyD', 'Escape', 'KeyP'].includes(e.code)) e.preventDefault();
    if ((e.code === 'Escape' || e.code === 'KeyP') && !e.repeat) { this.pause(); return; }
    if (['ArrowLeft', 'ArrowRight', 'KeyA', 'KeyD'].includes(e.code)) this.activate();
    if (e.code === 'Space' && !e.repeat && !(e.target instanceof HTMLButtonElement)) { this.jumped = true; this.touchJump = undefined; this.activate(); }
    this.keys.add(e.code);
  };
  private keyup = (e: KeyboardEvent) => { this.keys.delete(e.code); };
  private down = (e: PointerEvent) => {
    if (e.target instanceof Element && e.target.closest('button')) return;
    if (this.pointer !== null || e.button !== 0) return;
    e.preventDefault(); this.activate(); this.pointer = e.pointerId; this.lastX = e.clientX;
    this.element.setPointerCapture(e.pointerId);
    if (this.game === 'basketballRunner') {
      this.jumped = true;
      this.touchJump = e.pointerType === 'touch' || e.pointerType === 'pen' ? { held: true } : undefined;
      this.pressure(e);
    }
  };
  private move = (e: PointerEvent) => {
    if (this.pointer !== e.pointerId) return;
    this.pressure(e);
    this.delta += (e.clientX - this.lastX) / this.element.clientWidth;
    this.lastX = e.clientX;
  };
  private pressure(e: PointerEvent) {
    // W3C specifies a constant .5 on hardware without pressure sensing. Do not
    // mistake that sentinel (or contact size) for a measurement of finger force.
    if (this.touchJump && Number.isFinite(e.pressure) && e.pressure > 0 && Math.abs(e.pressure - .5) > .01) {
      this.touchJump.pressure = Math.max(this.touchJump.pressure ?? 0, Math.min(1, e.pressure));
    }
  }
  private up = (e: PointerEvent) => {
    if (this.pointer !== e.pointerId) return;
    if (this.touchJump) this.touchJump.held = false;
    if (e.type === 'pointercancel') this.jumped = false;
    this.pointer = null;
  };
  reset = () => { this.keys.clear(); this.jumped = false; this.delta = 0; this.pointer = null; this.touchJump = undefined; };
  read(): GameInput {
    const input: GameInput = { jump: this.jumped, drag: this.delta, touchJump: this.touchJump ? { ...this.touchJump } : undefined,
      axis: Number(this.keys.has('ArrowRight') || this.keys.has('KeyD')) - Number(this.keys.has('ArrowLeft') || this.keys.has('KeyA')) };
    this.jumped = false; this.delta = 0; return input;
  }
  dispose() { this.abort.abort(); }
}
