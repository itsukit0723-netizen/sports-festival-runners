// All world distances, timers, and balance values live here. Basketball units = px;
// football units = metres. No run time limit: the director keeps generating forever.
export const BASKETBALL = {
  width: 420, height: 760, ground: 584, playerX: 85, radius: 20,
  baseSpeed: 318, maxSpeed: 780, gravity: 1950, jumpForce: 730,
  visualRollRate: 4.8, maxVisualRollRate: 7.2,
  boostMultiplier: 1.7, feverSpeedMultiplier: 1.18, boostDuration: 4, feverDuration: 4.5,
  bonusDuration: 5.2, bonusFrequency: 25, firstBonus: 14,
  coinSpacing: 32, comboWindow: 1.35, coinScore: 18, nearScore: 70,
  obstacles: {
    normal: { coneWidth: 30, hurdleWidth: 42, coneHeight: 52, hurdleHeight: 64 },
    high: { width: 30, startHeight: 108, maxHeight: 116 },
    long: { seconds: .416, minWidth: 131, maxWidth: 189, matHeight: 26, benchHeight: 34 },
  },
  // time, speed added, seconds between obstacles
  difficultyCurve: [
    { at: 0, speed: 0, gap: 2.05 }, { at: 8, speed: 24, gap: 1.75 },
    { at: 16, speed: 50, gap: 1.5 }, { at: 25, speed: 78, gap: 1.3 },
    { at: 30, speed: 115, gap: 1.18 }, { at: 40, speed: 155, gap: 1.1 },
    { at: 50, speed: 225, gap: 1.02 }, { at: 60, speed: 285, gap: .98 },
    { at: 75, speed: 355, gap: .95 }, { at: 90, speed: 420, gap: .92 },
    { at: 120, speed: 462, gap: .92 },
  ],
} as const;
export const FOOTBALL = {
  forwardSpeed: 18, maxForwardSpeed: 44, steeringSensitivity: 11.8,
  dragSensitivity: 12.5, courseWidth: 8.8, ballRadius: 0.42,
  boostMultiplier: 1.35, boostDuration: 3.8, chunkLength: 26,
  bonusFrequency: 25, firstBonus: 15, hardChunkStartTime: 18,
  visibleDistance: 102, comboWindow: 1.3, tokenScore: 22,
  maxParticles: 88, poolSize: 120,
  introChunks: 3, introRunway: 24,
  challengeRows: { normal: [4, 12.6666667, 21.3333333], hard: [4, 10.5, 17, 23.5] },
  route: { maxCenter: 2.65, normalStep: 1.25, hardStep: .9, rowClearance: 1.25, maxObstacleDepth: 1.45, transitionSafety: .74 },
  moving: { defenderAmplitude: 1.6, defenderFrequency: 4.8, barAmplitude: .8, barFrequency: 4.5, wallAmplitude: 1.05, wallFrequency: 5.4, hardWallAmplitude: 1.25, hardWallFrequency: 6.2 },
  difficultyCurve: [
    { at: 0, speed: 18 }, { at: 8, speed: 20 }, { at: 18, speed: 23 },
    { at: 30, speed: 26 }, { at: 50, speed: 32 }, { at: 70, speed: 36 },
    { at: 100, speed: 40 }, { at: 140, speed: 44 },
  ],
} as const;
export const STEP = 1 / 120;
