import { BASKETBALL as B, FOOTBALL as F } from './config';
import { Random, clamp } from './types';
export class DifficultyDirector {
  private hardStreak = 0;
  constructor(private random: Random) {}
  basketball(time: number) {
    if (time >= B.endless.at) {
      const elapsed = time - B.endless.at;
      return {
        speed: B.endless.speed + (B.maxSpeed - B.endless.speed) * -Math.expm1(-elapsed / B.endless.speedTimeConstant),
        gap: B.endless.minGap + (B.endless.gap - B.endless.minGap) * Math.exp(-elapsed / B.endless.gapTimeConstant),
      };
    }
    const curve = B.difficultyCurve;
    for (let i = 1; i < curve.length; i++) if (time < curve[i].at) {
      const a = curve[i - 1], b = curve[i], blend = clamp((time - a.at) / (b.at - a.at), 0, 1);
      return { speed: B.baseSpeed + a.speed + (b.speed - a.speed) * blend, gap: a.gap + (b.gap - a.gap) * blend };
    }
    const last = curve[curve.length - 1];
    return { speed: Math.min(B.maxSpeed, B.baseSpeed + last.speed), gap: last.gap };
  }
  football(time: number, recovering = false): 'easy' | 'medium' | 'hard' {
    if (time < 6 || recovering) { this.hardStreak = 0; return 'easy'; }
    if (this.hardStreak >= 2) { this.hardStreak = 0; return 'medium'; }
    const roll = this.random.next();
    if (time >= F.hardChunkStartTime && roll < clamp(.45 + (time - F.hardChunkStartTime) / 140, .45, .82)) {
      this.hardStreak++; return 'hard';
    }
    this.hardStreak = 0;
    return time < 12 && roll < .2 ? 'easy' : 'medium';
  }
}
