import { BASKETBALL as B, FOOTBALL as F } from './config';
import { Random, clamp } from './types';
export class DifficultyDirector {
  private hardStreak = 0;
  constructor(private random: Random) {}
  basketball(time: number) {
    let stage: (typeof B.difficultyCurve)[number] = B.difficultyCurve[0];
    for (const candidate of B.difficultyCurve) if (time >= candidate.at) stage = candidate;
    return { speed: Math.min(B.maxSpeed, B.baseSpeed + stage.speed + Math.max(0, time - 70) * .2), gap: stage.gap };
  }
  football(time: number, recovering = false): 'easy' | 'medium' | 'hard' {
    if (time < 6 || recovering) { this.hardStreak = 0; return 'easy'; }
    if (this.hardStreak >= 2) { this.hardStreak = 0; return 'medium'; }
    const roll = this.random.next();
    if (time >= F.hardChunkStartTime && roll < clamp(.55 + (time - F.hardChunkStartTime) / 100, .55, .82)) {
      this.hardStreak++; return 'hard';
    }
    this.hardStreak = 0;
    return time < 12 && roll < .2 ? 'easy' : 'medium';
  }
}
