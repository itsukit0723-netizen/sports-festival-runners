import { clamp, type GameEvent } from './types';

// Presentation time only: never changes simulation dt, position or collision.
export class GameFeel {
  time = 0; rush = 0; impact = 0; jump = 0; land = 0; reward = 0; near = 0;
  constructor(public reducedMotion = false) {}
  update(dt: number, events: readonly GameEvent[], intensity: number) {
    const step = clamp(dt, 0, .05);
    this.time += step;
    this.rush += (clamp(intensity, 0, 1) - this.rush) * (1 - Math.exp(-step * 6));
    this.impact *= Math.exp(-step * 15); this.jump *= Math.exp(-step * 12);
    this.land *= Math.exp(-step * 14); this.reward *= Math.exp(-step * 8); this.near *= Math.exp(-step * 5);
    for (const event of events) {
      if (event.kind === 'jump') this.jump = 1;
      if (event.kind === 'land') { this.land = 1; this.impact = Math.max(this.impact, .25); }
      if (event.kind === 'near' || event.kind === 'dribble') { this.near = 1; this.impact = Math.max(this.impact, .5); }
      if (event.kind === 'boost' || event.kind === 'fever') this.impact = Math.max(this.impact, .8);
      if (event.kind === 'smash' || event.kind === 'over') this.impact = 1;
      if (event.kind === 'coin') this.reward = Math.max(this.reward, event.reward === 'landing' ? .8 : .18);
    }
  }
  get motion() { return this.reducedMotion ? 0 : 1; }
  basketballCamera(_height: number) {
    return { zoom: 1, y: 0 };
  }
  footballCamera(_steer: number) {
    // Stable lens and horizon. Reward pulses belong to the ball, never the camera.
    return { fov: 52, bank: 0, height: 5.1, distance: 9, lookAhead: -8 };
  }
}
