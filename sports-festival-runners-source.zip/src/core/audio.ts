import type { EffectKind } from './types';
export class ArcadeAudio {
  private context?: AudioContext;
  private roll?: OscillatorNode;
  private rollGain?: GainNode;
  enabled = true;
  unlock() {
    try { this.context ??= new AudioContext(); if (this.context.state !== 'running') void this.context.resume().catch(() => {}); } catch { /* Silent play is supported. */ }
  }
  setEnabled(on: boolean) { this.enabled = on; if (this.rollGain) this.rollGain.gain.value = 0; }
  private tone(frequency: number, duration: number, volume = .08, type: OscillatorType = 'sine', delay = 0, end?: number) {
    const c = this.context;
    if (!c || !this.enabled || c.state !== 'running') return;
    const oscillator = c.createOscillator(), gain = c.createGain(), at = c.currentTime + delay;
    oscillator.type = type; oscillator.frequency.setValueAtTime(frequency, at);
    if (end) oscillator.frequency.exponentialRampToValueAtTime(end, at + duration);
    gain.gain.setValueAtTime(volume, at); gain.gain.exponentialRampToValueAtTime(.001, at + duration);
    oscillator.connect(gain); gain.connect(c.destination); oscillator.start(at); oscillator.stop(at + duration + .02);
    oscillator.onended = () => { oscillator.disconnect(); gain.disconnect(); };
  }
  play(kind: EffectKind, combo = 0) {
    switch (kind) {
      case 'coin': { const f = 620 * 2 ** (Math.min(combo % 12, 11) / 12); this.tone(f, .09, .055); this.tone(f * 1.5, .12, .025, 'sine', .025); break; }
      case 'jump': this.tone(260, .14, .055, 'triangle', 0, 620); break;
      case 'land': this.tone(110, .09, .04, 'sine', 0, 55); break;
      case 'over': this.tone(160, .24, .09, 'triangle', 0, 45); this.tone(220, .18, .05, 'sine', .12, 65); break;
      case 'smash': this.tone(85, .17, .09, 'sawtooth', 0, 32); this.tone(330, .09, .04, 'square'); break;
      case 'boost': [330, 440, 660, 880].forEach((f, i) => this.tone(f, .13, .04, 'triangle', i * .045)); break;
      case 'fever': case 'bonus': [523, 659, 784, 1047].forEach((f, i) => this.tone(f, .25, .04, 'sine', i * .07)); break;
      case 'near': case 'dribble': this.tone(780, .12, .045); this.tone(1175, .18, .04, 'sine', .06); break;
    }
  }
  rolling(speed: number, active: boolean) {
    const c = this.context;
    if (!c || c.state !== 'running') return;
    if (!this.roll) {
      this.roll = c.createOscillator(); this.rollGain = c.createGain(); this.roll.type = 'triangle';
      this.roll.connect(this.rollGain); this.rollGain.connect(c.destination); this.rollGain.gain.value = 0; this.roll.start();
    }
    this.roll.frequency.value = 38 + speed * 1.5;
    this.rollGain!.gain.setTargetAtTime(active && this.enabled ? .008 : 0, c.currentTime, .08);
  }
  dispose() { this.roll?.stop(); void this.context?.close().catch(() => {}); }
}
