import type { EffectKind, RewardKind } from './types';
export class ArcadeAudio {
  private context?: AudioContext;
  private roll?: OscillatorNode;
  private rollGain?: GainNode;
  private wind?: AudioBufferSourceNode; private windGain?: GainNode; private windFilter?: BiquadFilterNode;
  enabled = true;
  golden = false;
  goldenFanfare(finale=false) {
    const notes=finale?[523.25,659.25,783.99,1046.5]:[392,523.25,659.25,783.99,1046.5];
    notes.forEach((note,i)=>{this.tone(note,.32,.027,'triangle',i*.085);this.tone(note*1.5,.25,.012,'sine',i*.085+.02);});
  }
  private lastComboAccent = -1;
  unlock() {
    try { this.context ??= new AudioContext(); if (this.context.state !== 'running') void this.context.resume().catch(() => {}); } catch { /* Silent play is supported. */ }
  }
  setEnabled(on: boolean) { this.enabled = on; if (this.rollGain) this.rollGain.gain.value = 0; if (this.windGain) this.windGain.gain.value = 0; }
  private tone(frequency: number, duration: number, volume = .08, type: OscillatorType = 'sine', delay = 0, end?: number) {
    const c = this.context;
    if (!c || !this.enabled || c.state !== 'running') return;
    const oscillator = c.createOscillator(), gain = c.createGain(), at = c.currentTime + delay;
    oscillator.type = type; oscillator.frequency.setValueAtTime(frequency, at);
    if (end) oscillator.frequency.exponentialRampToValueAtTime(end, at + duration);
    gain.gain.setValueAtTime(volume, at); gain.gain.exponentialRampToValueAtTime(.001, at + duration);
    oscillator.connect(gain); gain.connect(c.destination); oscillator.start(at); oscillator.stop(at + duration + .02);
    oscillator.onended = () => { oscillator.disconnect(); gain.disconnect(); };
  }
  play(kind: EffectKind, combo = 0) {
    switch (kind) {
      case 'portal': this.tone(120, .2, .028, 'sine', 0, 380); [330, 495, 660, 990].forEach((note, i) => this.tone(note, .24, .028, 'sine', .04+i*.045)); break;
      case 'coin': {
        if(this.golden)this.tone(1244,.16,.012,'triangle',.015);
        const f = 620 * 2 ** (Math.min(combo % 12, 11) / 12); this.tone(f, .09, .055); this.tone(f * 1.5, .12, .025, 'sine', .025);
        const at = this.context?.currentTime ?? 0;
        if (combo > 0 && combo % 8 === 0 && at - this.lastComboAccent > .25) {
          this.lastComboAccent = at; [880, 1100, 1320].forEach((note, i) => this.tone(note, .13, .022, 'sine', i * .035));
        }
        break;
      }
      case 'jump': this.tone(260, .14, .055, 'triangle', 0, 620); break;
      case 'land': this.tone(155, .09, .04, 'sine', 0, 48); break;
      case 'over': this.tone(160, .24, .09, 'triangle', 0, 45); this.tone(220, .18, .05, 'sine', .12, 65); break;
      case 'smash': this.tone(85, .17, .09, 'sawtooth', 0, 32); this.tone(330, .09, .04, 'square'); break;
      case 'boost': this.tone(65, .3, .045, 'sine', 0, 150); [330, 440, 660, 880].forEach((f, i) => this.tone(f, .13, .04, 'triangle', i * .045)); break;
      case 'fever': case 'bonus': [523, 659, 784, 1047].forEach((f, i) => this.tone(f, .25, .04, 'sine', i * .07)); break;
      case 'near': case 'dribble': this.tone(130, .1, .03, 'sine', 0, 70); this.tone(780, .1, .04); this.tone(1175, .16, .035, 'sine', .045); break;
    }
  }
  rolling(speed: number, active: boolean) {
    const c = this.context;
    if (!c || c.state !== 'running') return;
    if (!this.roll) {
      this.roll = c.createOscillator(); this.rollGain = c.createGain(); this.roll.type = 'triangle';
      this.roll.connect(this.rollGain); this.rollGain.connect(c.destination); this.rollGain.gain.value = 0; this.roll.start();
    }
    this.roll.frequency.value = 38 + speed * 1.5;
    this.rollGain!.gain.setTargetAtTime(active && this.enabled ? .008 : 0, c.currentTime, .08);
  }
  playReward(kind: RewardKind) {
    if (kind === 'landing') {
      this.tone(220, .16, .045, 'triangle', 0, 440);
      [880, 1320, 1760].forEach((note, i) => this.tone(note, .2, .028, 'sine', .02 + i * .035));
      return;
    }
    const notes = [784, 1047, 1568];
    notes.forEach((frequency, i) => this.tone(frequency, .14, .035, 'sine', i * .045));
  }
  surge(intensity: number, active: boolean) {
    const c = this.context;
    if (!c || c.state !== 'running') return;
    const level = Math.max(0, Math.min(1, intensity));
    if (!this.wind && level > 0 && active && this.enabled) {
      const buffer = c.createBuffer(1, c.sampleRate * 2, c.sampleRate), samples = buffer.getChannelData(0);
      for (let i = 0; i < samples.length; i++) samples[i] = Math.random() * 2 - 1;
      this.wind = c.createBufferSource(); this.wind.buffer = buffer; this.wind.loop = true;
      this.windFilter = c.createBiquadFilter(); this.windFilter.type = 'bandpass'; this.windFilter.Q.value = .65;
      this.windGain = c.createGain(); this.windGain.gain.value = 0;
      this.wind.connect(this.windFilter); this.windFilter.connect(this.windGain); this.windGain.connect(c.destination); this.wind.start();
    }
    if (this.windGain && this.windFilter) {
      this.windFilter.frequency.setTargetAtTime(650 + level * 1100, c.currentTime, .15);
      this.windGain.gain.setTargetAtTime(active && this.enabled ? level * .018 : 0, c.currentTime, .12);
    }
  }
  dispose() { this.roll?.stop(); this.wind?.stop(); void this.context?.close().catch(() => {}); }
}
