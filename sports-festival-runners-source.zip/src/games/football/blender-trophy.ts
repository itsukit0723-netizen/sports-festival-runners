import * as THREE from 'three';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';
import url from '../../assets/golden-trophy.glb?url';

/** One asset and reflection map, shared by every grounded display bay. */
export class BlenderTrophy {
  ready=false;
  private disposed=false;
  private source?:THREE.Group;
  private reflection?:THREE.CubeTexture;
  constructor(onReady:(model:THREE.Object3D)=>void) {
    void new GLTFLoader().loadAsync(url).then(gltf=>{
      this.source=gltf.scene;
      if(this.disposed){this.release();return;}
      const model=gltf.scene.getObjectByName('GoldenTrophy');
      if(!model)throw Error('Incomplete trophy asset');
      // Local, neutral studio reflections keep gold readable without changing
      // the stadium lights or the materials of any gameplay obstacle.
      const faces=Array.from({length:6},(_,i)=>{
        const canvas=document.createElement('canvas');canvas.width=canvas.height=128;const c=canvas.getContext('2d')!;
        const gradient=c.createLinearGradient(0,0,0,128);gradient.addColorStop(0,'#a4a9b3');gradient.addColorStop(.46,'#545e70');gradient.addColorStop(1,'#252c39');
        c.fillStyle=gradient;c.fillRect(0,0,128,128);
        c.fillStyle=i===2?'#fff7dd':'#e4e7ed';c.fillRect(i%2?78:19,9,20,87);
        c.fillStyle='#abb2bf';c.fillRect(i%2?19:87,24,8,65);return canvas;
      });
      this.reflection=new THREE.CubeTexture(faces);this.reflection.colorSpace=THREE.SRGBColorSpace;this.reflection.needsUpdate=true;
      model.traverse(o=>{if(o instanceof THREE.Mesh){
        for(const m of Array.isArray(o.material)?o.material:[o.material])if(m instanceof THREE.MeshStandardMaterial){m.envMap=this.reflection!;m.envMapIntensity=.9;m.needsUpdate=true;}
      }});
      onReady(model);this.ready=true;
    }).catch(error=>{if(!this.disposed)console.warn('Trophy model unavailable; keeping grounded fallback.',error);});
  }
  private release(){
    const geos=new Set<THREE.BufferGeometry>(),mats=new Set<THREE.Material>();
    this.source?.traverse(o=>{if(o instanceof THREE.Mesh){geos.add(o.geometry);for(const m of Array.isArray(o.material)?o.material:[o.material])mats.add(m);}});
    geos.forEach(g=>g.dispose());mats.forEach(m=>m.dispose());this.reflection?.dispose();this.source=undefined;this.reflection=undefined;
  }
  dispose(){this.disposed=true;this.release();}
}
