import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import worldsUrl from '../../assets/arcade-worlds.glb?url';
import { WORLD_MODEL_PLACEMENTS } from './world-model-layouts';
import type { WorldId } from './worlds';

export class BlenderWorlds {
  ready=false; failed=false;
  private disposed=false;
  private source?:THREE.Group;
  private groups=new Map<WorldId,THREE.Group>();
  private moving:{group:THREE.Object3D;offset:number;period:number}[]=[];
  constructor(scene:THREE.Scene){
    for(const world of ['city','ice','orbit','ember'] as const){const group=new THREE.Group();group.visible=false;scene.add(group);this.groups.set(world,group);}
    void new GLTFLoader().loadAsync(worldsUrl).then(gltf=>{
      this.source=gltf.scene;if(this.disposed){this.release();return;}
      for(const p of WORLD_MODEL_PLACEMENTS){
        const original=gltf.scene.getObjectByName(p.name);if(!original)throw new Error(`Missing world model ${p.name}`);
        const model=original.clone(true);model.position.set(p.x,p.y,p.z);model.scale.setScalar(p.scale);model.rotation.y=p.rotation;
        if(p.name==='Orbit_Planet')model.traverse(o=>{if(o instanceof THREE.Mesh)for(const m of Array.isArray(o.material)?o.material:[o.material])m.fog=false;});
        this.groups.get(p.world)!.add(model);
        if(p.offset!==undefined)this.moving.push({group:model,offset:p.offset,period:p.period!});
      }
      this.ready=true;
    }).catch(error=>{if(!this.disposed){this.failed=true;console.warn('Blender worlds unavailable; retaining existing scenery.',error);}});
  }
  update(world:WorldId,distance:number){
    for(const [id,group]of this.groups)group.visible=this.ready&&id===world;
    for(const tile of this.moving)tile.group.position.z=12-((tile.offset-distance)%tile.period+tile.period)%tile.period;
  }
  private release(){
    if(!this.source)return;
    const geometries=new Set<THREE.BufferGeometry>(),materials=new Set<THREE.Material>(),textures=new Set<THREE.Texture>();
    this.source.traverse(o=>{if(o instanceof THREE.Mesh){geometries.add(o.geometry);for(const material of Array.isArray(o.material)?o.material:[o.material]){materials.add(material);for(const value of Object.values(material))if(value instanceof THREE.Texture)textures.add(value);}}});
    geometries.forEach(g=>g.dispose());materials.forEach(m=>m.dispose());textures.forEach(t=>{t.dispose();(t.image as {close?:()=>void}|undefined)?.close?.();});this.source=undefined;
  }
  dispose(){this.disposed=true;for(const group of this.groups.values())group.removeFromParent();this.release();}
}
