import * as THREE from 'three';
import {FOOTBALL as F} from '../../core/config';

/** Flat white sideline, dark outside apron, then a low curb: three distinct layers. */
export class PitchEdges {
  readonly group=new THREE.Group();
  private geometries:THREE.BufferGeometry[]=[];
  private materials:THREE.Material[]=[];
  private texture:THREE.CanvasTexture;
  private caps:THREE.MeshStandardMaterial[]=[];
  constructor(){
    const canvas=document.createElement('canvas');canvas.width=128;canvas.height=256;const c=canvas.getContext('2d')!;
    c.fillStyle='#152231';c.fillRect(0,0,128,256);c.strokeStyle='#a8a58b';c.lineWidth=13;
    for(let y=-128;y<384;y+=96){c.beginPath();c.moveTo(8,y);c.lineTo(120,y+75);c.stroke();}
    this.texture=new THREE.CanvasTexture(canvas);this.texture.colorSpace=THREE.SRGBColorSpace;this.texture.wrapS=this.texture.wrapT=THREE.RepeatWrapping;this.texture.repeat.set(1,32);
    const box=new THREE.BoxGeometry(1,1,1);this.geometries.push(box);
    const mat=(color:string)=>{const m=new THREE.MeshStandardMaterial({color,roughness:.86,metalness:.03});this.materials.push(m);return m;};
    const line=mat('#f3ead6'),outside=mat('#ffffff');outside.map=this.texture;
    const body=mat('#263649'),cap=mat('#b8bdba');this.caps.push(cap);
    const add=(name:string,m:THREE.Material,x:number,y:number,w:number,h:number)=>{const o=new THREE.Mesh(box,m);o.name=name;o.position.set(x,y,-47);o.scale.set(w,h,120);this.group.add(o);};
    for(const side of [-1,1]){
      add(`Sideline-${side}`,line,side*(F.courseWidth/2-.08),-.025,.105,.025);
      add(`OutsideApron-${side}`,outside,side*(F.courseWidth/2+.33),-.1,.66,.12);
      add(`OuterCurb-${side}`,body,side*(F.courseWidth/2+.82),.035,.26,.25);
      add(`CurbCap-${side}`,cap,side*(F.courseWidth/2+.82),.17,.28,.025);
    }
  }
  setGolden(enabled:boolean){for(const m of this.caps)m.color.set(enabled?'#b7a076':'#b8bdba');}
  update(distance:number){this.texture.offset.y=-distance/3.75;}
  dispose(){this.geometries.forEach(g=>g.dispose());this.materials.forEach(m=>m.dispose());this.texture.dispose();this.group.removeFromParent();}
}
