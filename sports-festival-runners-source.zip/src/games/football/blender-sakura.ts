import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import sakuraUrl from '../../assets/sakura-garden.glb?url';

// The original .blend and generation script live alongside the integration
// source. Reusable meshes share geometry/materials; only transforms are cloned.
export class BlenderSakura {
  ready = false;
  failed = false;
  private disposed = false;
  private source?: THREE.Group;
  private group = new THREE.Group();
  private moving: { group: THREE.Object3D; offset: number; period: number }[] = [];
  constructor(scene: THREE.Scene) {
    this.group.visible = false; scene.add(this.group);
    void new GLTFLoader().loadAsync(sakuraUrl).then(gltf => {
      this.source = gltf.scene;
      if (this.disposed) { this.releaseSource(); return; }
      const asset = (name: string, x: number, y: number, z: number, scale = 1, rotation = 0) => {
        const original = gltf.scene.getObjectByName(name);
        if (!original) throw new Error(`Missing Blender asset: ${name}`);
        const instance = original.clone(true); instance.position.set(x, y, z); instance.scale.setScalar(scale); instance.rotation.y = rotation;
        this.group.add(instance); return instance;
      };
      for (const side of [-1, 1]) for (let i = 0; i < 7; i++) {
        const tree = asset(i % 2 ? 'Sakura_Tree_A' : 'Sakura_Tree_B', side * (7.05 + i % 3 * .25), 0, 0, 1.12 - i % 3 * .06, side * (i * .83 + .3));
        this.moving.push({group:tree, offset:i * 20 + (side === -1 ? 7 : 0),period:140});
        const lantern = asset('Sakura_Lantern', side * 5.25, 0, 0, .8);
        this.moving.push({group:lantern, offset:i * 20 + 5,period:140});
        const bed = asset('Sakura_GardenBed', side * 7.05, -.08, 0, 1);
        this.moving.push({group:bed,offset:i * 20,period:140});
      }
      const torii = asset('Sakura_Torii', 0, 0, 0);
      this.moving.push({group:torii,offset:43,period:140});
      // Shrines are landmarks outside the playable road, not collision gates.
      asset('Sakura_Shrine', -14.3, 3.05, -52, 1.6, .18);
      asset('Sakura_Shrine', 15.1, 3.24, -68, 1.7, -.2);
      this.ready = true;
    }).catch(error => { if (!this.disposed) { this.failed = true; console.warn('Sakura model unavailable; using procedural scenery.', error); } });
  }
  update(visible: boolean, distance: number) {
    this.group.visible = visible && this.ready;
    if (!this.group.visible) return;
    for (const tile of this.moving) tile.group.position.z = 12 - ((tile.offset - distance) % tile.period + tile.period) % tile.period;
  }
  private releaseSource() {
    if (!this.source) return;
    const geometries = new Set<THREE.BufferGeometry>(), materials = new Set<THREE.Material>(), textures = new Set<THREE.Texture>();
    this.source.traverse(o => {
      if (!(o instanceof THREE.Mesh)) return;
      geometries.add(o.geometry);
      for (const material of Array.isArray(o.material) ? o.material : [o.material]) { materials.add(material); for (const value of Object.values(material)) if (value instanceof THREE.Texture) textures.add(value); }
    });
    geometries.forEach(g => g.dispose()); materials.forEach(m => m.dispose());
    textures.forEach(t => { t.dispose(); const bitmap = t.image as { close?: () => void } | undefined; bitmap?.close?.(); });
    this.source = undefined;
  }
  dispose() { this.disposed = true; this.group.removeFromParent(); this.releaseSource(); }
}
