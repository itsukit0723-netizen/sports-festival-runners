import { FOOTBALL as F } from '../../core/config';

// Distance to the actual movement segment: no square-corner attraction and no
// missed contact when a quick drag crosses a star between simulation steps.
export function collectsStar(ax:number,az:number,bx:number,bz:number,x:number,z:number) {
  const dx=bx-ax,dz=bz-az,lengthSquared=dx*dx+dz*dz;
  const t=lengthSquared>0?Math.max(0,Math.min(1,((x-ax)*dx+(z-az)*dz)/lengthSquared)):0;
  return (ax+t*dx-x)**2+(az+t*dz-z)**2<=F.starPickupRadius**2;
}
