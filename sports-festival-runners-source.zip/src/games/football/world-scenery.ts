import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { WORLD_IDS, type WorldId } from './worlds';
import { BlenderSakura } from './blender-sakura';

type Add = (g: THREE.BufferGeometry, color: string, x: number, y: number, z: number, sx: number, sy: number, sz: number, glow?: boolean, rz?: number, rx?: number, ry?: number) => void;

// Detailed scenery is baked by material. The road and every collision volume
// remain owned by the game model; all roadside structures start outside x=4.4.
export class WorldScenery {
  private tiles: { world: WorldId; index: number; group: THREE.Group }[] = [];
  private horizons = new Map<WorldId, THREE.Group>();
  private atmosphere = new Map<WorldId, THREE.Points>();
  private textures: THREE.Texture[] = [];
  private materials: THREE.Material[] = [];
  private time = 0;
  surfaceMaterial!: (world: WorldId, color: string, glow?: boolean) => THREE.MeshStandardMaterial;
  private planet?: THREE.Mesh;
  private blenderSakura: BlenderSakura;
  constructor(scene: THREE.Scene, keep: <T extends THREE.BufferGeometry>(g: T) => T, _material: (color: string, glow?: boolean) => THREE.MeshStandardMaterial) {
    this.blenderSakura = new BlenderSakura(scene);
    const sources: THREE.BufferGeometry[] = [];
    const source = <T extends THREE.BufferGeometry>(g: T) => { sources.push(g); return g; };
    const box = source(new THREE.BoxGeometry(1, 1, 1));
    const sphere = source(new THREE.SphereGeometry(1, 18, 12));
    const rock = source(new THREE.IcosahedronGeometry(1, 1));
    const cylinder = source(new THREE.CylinderGeometry(1, 1, 1, 12));
    const hex = source(new THREE.CylinderGeometry(.85, 1, 1, 6));
    const crystal = source(new THREE.CylinderGeometry(0, 1, 1, 5, 1));
    const ring = source(new THREE.TorusGeometry(1, .035, 8, 64));
    const plane = keep(new THREE.PlaneGeometry(1, 1));
    const beam = (add: Add, a: THREE.Vector3, b: THREE.Vector3, r: number, color: string) => {
      const midpoint = a.clone().add(b).multiplyScalar(.5), d = b.clone().sub(a);
      const e = new THREE.Euler().setFromQuaternion(new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), d.clone().normalize()), 'XYZ');
      add(cylinder, color, midpoint.x, midpoint.y, midpoint.z, r, d.length(), r, false, e.z, e.x, e.y);
    };
    // Curved roof with a real raised ridge and swept eaves, rather than slabs.
    const roofShape = new THREE.Shape(); roofShape.moveTo(-1, 0); roofShape.quadraticCurveTo(-.6, -.14, 0, .45); roofShape.quadraticCurveTo(.6, -.14, 1, 0); roofShape.lineTo(1, -.1); roofShape.quadraticCurveTo(.5, -.15, 0, .31); roofShape.quadraticCurveTo(-.5, -.15, -1, -.1); roofShape.closePath();
    const roof = source(new THREE.ExtrudeGeometry(roofShape, { depth: 1, bevelEnabled: false, curveSegments: 12 })); roof.translate(0, 0, -.5);
    const archShape = new THREE.Shape(); archShape.moveTo(-1.4, 0); archShape.lineTo(-1.4, 1.5); archShape.absarc(0, 1.5, 1.4, Math.PI, 0, true); archShape.lineTo(1.4, 0); archShape.lineTo(1.05, 0); archShape.lineTo(1.05, 1.5); archShape.absarc(0, 1.5, 1.05, 0, Math.PI, false); archShape.lineTo(-1.05, 0); archShape.closePath();
    const arch = source(new THREE.ExtrudeGeometry(archShape, { depth: .5, bevelEnabled: true, bevelSize: .035, bevelThickness: .03, bevelSegments: 1, curveSegments: 20 }));
    // Blossoms have an irregular surface and vertical depth instead of flat disks.
    const crown = source(new THREE.SphereGeometry(1, 14, 10));
    const cv = crown.getAttribute('position');
    for (let i = 0; i < cv.count; i++) { const x = cv.getX(i), y = cv.getY(i), z = cv.getZ(i); const noise = 1 + .13 * Math.sin(x * 12 + z * 8) * Math.cos(y * 11 - z * 4); cv.setXYZ(i, x * noise, y * noise, z * noise); } crown.computeVertexNormals();
    const petalShape = new THREE.Shape();
    for (let i = 0; i <= 40; i++) { const a = i / 40 * Math.PI * 2, r = .62 + .3 * Math.cos(a * 5); if (!i) petalShape.moveTo(Math.cos(a) * r, Math.sin(a) * r); else petalShape.lineTo(Math.cos(a) * r, Math.sin(a) * r); }
    const flower = source(new THREE.ShapeGeometry(petalShape));
    const grains = new Map<WorldId, THREE.CanvasTexture>();
    for (const world of WORLD_IDS) {
      const canvas = document.createElement('canvas'); canvas.width = canvas.height = 128; const c = canvas.getContext('2d')!;
      c.fillStyle = '#ececec'; c.fillRect(0, 0, 128, 128);
      for (let j = 0; j < 1000; j++) { const x = (j * 43.71) % 128, y = (j * 71.17) % 128; c.fillStyle = j % 3 ? '#a9acb018' : '#ffffff35'; c.fillRect(x, y, world === 'ice' ? 1 : 3, 1); }
      if (world === 'ember' || world === 'city') { c.strokeStyle = '#757b852e'; for (let y = 0; y < 128; y += 32) { c.beginPath(); c.moveTo(0, y); c.lineTo(128, y); for (let x = (y % 64 ? 16 : 0); x < 128; x += 32) { c.moveTo(x, y); c.lineTo(x, y + 32); } c.stroke(); } }
      const t = new THREE.CanvasTexture(canvas); t.colorSpace = THREE.SRGBColorSpace; t.wrapS = t.wrapT = THREE.RepeatWrapping; this.textures.push(t); grains.set(world, t);
    }
    const cache = new Map<string, THREE.MeshStandardMaterial>();
    const material = (world: WorldId, color: string, glow: boolean) => {
      const key = world + color + glow;
      if (!cache.has(key)) {
        const metal = world === 'orbit' || world === 'city';
        const m = new THREE.MeshStandardMaterial({ color, roughness: glow ? .4 : world === 'ice' ? .28 : metal ? .48 : .9, metalness: metal ? .32 : world === 'ice' ? .12 : .02,
          ...(glow ? { emissive: color, emissiveIntensity: .85 } : { map: grains.get(world), bumpMap: grains.get(world), bumpScale: world === 'ice' ? .025 : .055 }), side: THREE.DoubleSide });
        cache.set(key, m); this.materials.push(m);
      }
      return cache.get(key)!;
    };
    this.surfaceMaterial = (world, color, glow = false) => material(world, color, glow);
    const bake = (world: WorldId, build: (add: Add) => void) => {
      const batches = new Map<string, THREE.BufferGeometry[]>(), group = new THREE.Group(), transform = new THREE.Object3D();
      build((g, color, x, y, z, sx, sy, sz, glow = false, rz = 0, rx = 0, ry = 0) => {
        transform.position.set(x, y, z); transform.scale.set(sx, sy, sz); transform.rotation.set(rx, ry, rz); transform.updateMatrix();
        const key = `${color}/${glow}`, list = batches.get(key) ?? [];
        const geometry = g.index ? g.toNonIndexed() : g.clone(); geometry.applyMatrix4(transform.matrix);
        // Extrusions and tubes share the same position/normal/UV layout.
        list.push(geometry); batches.set(key, list);
      });
      for (const [key, list] of batches) {
        const [color, glow] = key.split('/'), geometry = mergeGeometries(list, false)!;
        group.add(new THREE.Mesh(keep(geometry), material(world, color, glow === 'true'))); list.forEach(g => g.dispose());
      }
      return group;
    };
    const sign = (word: string, color: string) => {
      const canvas = document.createElement('canvas'); canvas.width = 256; canvas.height = 128; const c = canvas.getContext('2d')!;
      c.fillStyle = '#101e2b'; c.fillRect(0, 0, 256, 128); c.strokeStyle = color; c.lineWidth = 5; c.strokeRect(8, 8, 240, 112);
      c.fillStyle = color; c.shadowColor = color; c.shadowBlur = 14; c.font = 'bold 43px sans-serif'; c.textAlign = 'center'; c.fillText(word, 128, 79);
      const map = new THREE.CanvasTexture(canvas); map.colorSpace = THREE.SRGBColorSpace; this.textures.push(map);
      const m = new THREE.MeshBasicMaterial({ map, side: THREE.DoubleSide }); this.materials.push(m); return m;
    };
    const signs = [sign('ARCADE', '#93e5df'), sign('PLAY', '#e7b4cb')];
    for (const world of WORLD_IDS) {
      for (let index = 0; index < 16; index++) {
        const side = index % 2 ? -1 : 1, variant = (index >> 1) % 4;
        const group = bake(world, add => {
          if (world === 'city') {
            const h = 7 + variant * 2.1;
            add(box, '#263346', side * 2.1, h / 2, 0, 3.8, h, 9);
            // Recessed storefronts, projecting cornices and inset upper windows.
            add(box, '#122837', -.02 * side, 1.35, 0, .15, 2.5, 8.1);
            for (let j = 0; j < 5; j++) {
              add(box, '#9a967f', -.18 * side, 1.35, j * 1.8 - 3.6, .22, 2.5, .09);
              add(box, '#355367', -.12 * side, 1.4, j * 1.8 - 2.85, .05, 2.2, 1.4);
            }
            add(box, '#59666e', -.45 * side, 2.85, 0, 1.4, .18, 9.5);
            for (let level = 0; level < 4 + variant; level++) {
              const y = 3.6 + level * 1.35;
              add(box, '#52616d', -.02 * side, y - .35, 0, .3, .13, 8.7);
              for (let j = 0; j < 5; j++) {
                add(box, '#101f31', -.05 * side, y, j * 1.7 - 3.4, .18, .9, 1.1);
                add(box, (j + level + variant) % 4 ? '#d6ba83' : '#527083', -.16 * side, y + .05, j * 1.7 - 3.4, .045, .65, .82, true);
                add(box, '#79888d', -.2 * side, y + .05, j * 1.7 - 3.4, .05, .7, .035);
              }
            }
            add(box, '#65757c', side * 1.8, h + .15, 0, 4.5, .28, 9.6);
            add(box, '#435765', side * 2, h + .6, 0, 2.8, .6, 6.8);
            add(box, '#182c3b', side * 2, h + 1.1, 1.5, 1.1, .55, 1.4);
            add(box, '#a2dcd0', -.5 * side, 2.72, 0, .045, .045, 8.5, true);
            // Graceful street lamps and concrete planters, off the road.
            beam(add, new THREE.Vector3(-side * .8, 0, 3), new THREE.Vector3(-side * .8, 3.3, 3), .055, '#526572');
            beam(add, new THREE.Vector3(-side * .8, 3.3, 3), new THREE.Vector3(-side * 1.15, 3.5, 3), .055, '#526572');
            add(sphere, '#f2cf9a', -side * 1.15, 3.45, 3, .2, .1, .2, true);
            add(box, '#52606b', -.4 * side, .3, -3.4, 1.2, .6, .8);
            for (let j = 0; j < 4; j++) add(rock, '#446761', -.4 * side, .7, -3.7 + j * .2, .5, .3, .3);
          } else if (world === 'sakura') {
            // Each branch follows a curved 3D spline, with smaller branch forks.
            for (let branch = 0; branch < 6; branch++) {
              const a = branch * 2.399 + variant * .45, x = Math.cos(a) * 1.6, z = Math.sin(a) * 1.8;
              const path = new THREE.CatmullRomCurve3([new THREE.Vector3(0, .1, 0), new THREE.Vector3(side * .25, 1.6, .1), new THREE.Vector3(x * .4, 3.1, z * .4), new THREE.Vector3(x, 4.3 + branch % 2 * .4, z)]);
              const branchGeo = source(new THREE.TubeGeometry(path, 7, branch ? .11 : .24, 6, false)); add(branchGeo, '#604552', 0, 0, 0, 1, 1, 1);
              for (let j = 0; j < 5; j++) {
                const angle = j * 2.399 + branch, px = x + Math.cos(angle) * .68, pz = z + Math.sin(angle) * .72;
                const py = 4.25 + branch % 2 * .4 + Math.sin(j * 1.7 + variant) * .45;
                add(crown, ['#a86386', '#d996b1', '#edb9cb'][(j + branch) % 3], px, py, pz, .78, .62, .75, false, .1 * j);
                for (let k = 0; k < 4; k++) add(flower, '#f6cad7', px + Math.sin(k * 4) * .55, py + Math.cos(k * 3) * .42, pz + .58, .09, .09, .09, false, k, .2);
              }
            }
            // Carved lantern: pedestal, glowing paper, posts and swept roof.
            add(box, '#646274', -side * .8, .13, -4, .95, .25, .95);
            add(hex, '#777385', -side * .8, .7, -4, .22, 1.2, .22);
            add(box, '#f6c397', -side * .8, 1.5, -4, .48, .55, .48, true);
            for (const x of [-.31, .31]) for (const z of [-.31, .31]) add(box, '#665b6c', -side * .8 + x, 1.5, -4 + z, .065, .7, .065);
            add(roof, '#555367', -side * .8, 1.85, -4, .55, .6, 1.1);
            add(sphere, '#887183', -side * .8, 2.15, -4, .11, .15, .11);
            for (let j = 0; j < 20; j++) add(flower, '#d6a2b6', -side * .6 + Math.sin(j * 3) * .8, .04, j * .5 - 5, .08, .08, .08, false, j, -Math.PI / 2);
          } else if (world === 'ice') {
            for (let j = 0; j < 5; j++) {
              const h = 5 + (j * 3 + variant) % 6, x = side * (1.9 + j % 2 * 1.2), z = j * 2.3 - 5;
              add(rock, ['#31546d', '#486e89', '#5b879c'][j % 3], x, h * .35, z, 2.7, h * .7, 2.5, false, side * .12, .1 * j);
              // Multiple shelves reveal the stratified glacier rather than cones.
              for (let k = 0; k < 3; k++) add(rock, '#9cbfc8', x - side * .45, 1.5 + k * 1.4, z, 2.3, .16, 2.4, false, -.05 * side);
              add(crystal, '#87bfd1', side * .05, 1.9, z + .4, .8, 4.8, .7, false, side * .28, .1 * variant);
              add(crystal, '#c1e5e7', -.3 * side, 1.45, z + .65, .3, 3.6, .3, false, side * .28);
              add(crystal, '#539bb8', side * .7, 1, z + 1, .45, 2.7, .45, false, -.3 * side);
            }
            add(rock, '#a7cbd1', 0, .05, 0, 2.3, .18, 7);
          } else if (world === 'orbit') {
            add(box, '#28334c', side * 2, -.3, 0, 4.5, .6, 12);
            add(box, '#515d7c', side * 3.3, 1.6, 0, .45, 3.2, 11);
            for (let j = 0; j < 4; j++) {
              const z = j * 3 - 4.5;
              add(box, '#8493b1', side * 1.5, 2.4, z, 3.7, .2, .35, false, side * .58);
              add(box, '#a4b6e9', side * .03, 1.4, z, .08, 1.5, .12, true, side * .58);
              add(box, '#18243d', side * 3, 1.55, z, .14, 2.4, 2.6);
              for (let k = 0; k < 3; k++) add(box, '#7496b2', side * 2.88, 1 + k * .5, z, .06, .08, 1.6, k === 1);
              add(box, '#a3a5d9', -.35 * side, .08, z, .12, .04, 1.8, true);
              add(hex, '#6b7b9e', side * 1.7, .5, z, .5, 1, .5);
              add(ring, '#a1bbdc', side * 1.7, 1.05, z, .5, .5, .5, true, 0, Math.PI / 2);
            }
            // Curved service pipes give the station a constructed silhouette.
            for (let j = 0; j < 2; j++) { const path = new THREE.CatmullRomCurve3([new THREE.Vector3(side * 2, .5, -5), new THREE.Vector3(side * 2, 1, -3), new THREE.Vector3(side * 2.5, 1, 3), new THREE.Vector3(side * 3, .3, 5)]); add(source(new THREE.TubeGeometry(path, 12, .09 + j * .05, 6, false)), '#70829b', 0, j * .22, 0, 1, 1, 1); }
          } else {
            // Rounded stone arches, keystones and entablatures, not plain pillars.
            add(arch, '#65535b', side * 1.2, 0, -3, 1.2, 1.5, 2, false, 0, 0, Math.PI / 2);
            for (const z of [-4.5, 4.5]) {
              add(hex, '#413b46', side * 1.2, 2, z, .65, 4, .65);
              add(box, '#82706c', side * 1.2, .2, z, 1.6, .4, 1.6);
              add(box, '#82706c', side * 1.2, 3.8, z, 1.5, .35, 1.5);
              add(box, '#51424d', side * 1.2, 4.15, z, 1.8, .35, 1.8);
              for (let j = 0; j < 4; j++) add(box, '#b18467', side * .53, 1 + j * .6, z, .03, .08, .5);
            }
            add(box, '#4a3b45', side * 1.2, .08, 0, 3.5, .3, 11);
            for (let j = 0; j < 5; j++) {
              const z = j * 2.2 - 4.5;
              add(rock, '#493b47', side * (1.5 + j % 2), .4, z, .9, .6, .7, false, j);
              add(box, '#f6ac61', -.8 * side + Math.sin(j) * .16, .28, z, .6, .04, 2.4, true);
              add(box, '#b8613c', -.8 * side, .255, z, 1.2, .04, 2.4, true);
            }
            add(box, '#5c4b52', -.5 * side, .7, 2.8, .7, 1.4, .7);
            add(sphere, '#ffd39a', -.5 * side, 1.7, 2.8, .12, .35, .12, true);
          }
        });
        group.position.x = side * 6.4;
        if (world === 'city' && index % 4 < 2) { const board = new THREE.Mesh(plane, signs[variant % 2]); board.position.set(-side * .2, 3.6, 4.65); board.scale.set(1.5, .75, 1); group.add(board); }
        group.visible = false; scene.add(group); this.tiles.push({ world, index, group });
      }
      const horizon = bake(world, add => {
        if (world === 'sakura') {
          for (const side of [-1, 1]) {
            for (let level = 0; level < 4; level++) {
              const y = 1 + level * 3.2;
              add(box, '#7f5c6b', side * 14, y + 1, -65, 5.5 - level * .6, 2.7, 7 - level * .7);
              add(roof, '#3f435c', side * 14, y + 2.5, -65, 4.5 - level * .5, 2.5, 10 - level);
              for (let j = 0; j < 3; j++) add(box, '#dab29d', side * 14 + j * 1.2 - 1.2, y + 1.2, -61.4 + level * .35, .6, 1.2, .035, true);
            }
            add(hex, '#735569', side * 14, 14, -65, .13, 4, .13);
          }
        } else if (world === 'ice') {
          for (const side of [-1, 1]) for (let j = 0; j < 8; j++) {
            const h = 14 + j * 7 % 15;
            add(crystal, '#547c96', side * (14 + j * 5), h / 2, -72 - j * 4, 9, h, 9, false, -side * .13);
            add(crystal, '#a3c7d4', side * (14 + j * 5), h * .77, -72 - j * 4, 4.1, h * .46, 4.1, false, -side * .13);
          }
          add(arch, '#456d89', 0, 0, -80, 8, 6.5, 12);
        } else if (world === 'orbit') {
          for (let j = 0; j < 4; j++) {
            add(ring, '#5e7296', 0, 9, -35 - j * 20, 14, 14, 1);
            add(ring, '#93a8d4', 0, 9, -35 - j * 20, 13.7, 13.7, 1, true);
            for (let k = 0; k < 8; k++) { const a = k / 8 * Math.PI * 2; add(box, '#8394ad', Math.cos(a) * 14, 9 + Math.sin(a) * 14, -35 - j * 20, 1.1, .5, 1, false, a); }
          }
        } else if (world === 'ember') {
          for (const side of [-1, 1]) {
            for (let j = 0; j < 6; j++) {
              add(box, '#62505a', side * 17, j * 1.7, -69, 22 - j * 2.8, 1.7, 20 - j * 2.8);
              add(box, '#ab7d62', side * 17, j * 1.7 + .85, -58.9 - j * 1.4, 21 - j * 2.8, .1, .15);
              // Actual ascending staircase on the near face of each temple.
              for (let k = 0; k < 3; k++) add(box, '#8b6a63', side * 17, j * 1.7 + k * .52, -57.8 - j * 1.4 - k * .4, 2.6, .4, .8);
            }
            add(arch, '#9a7566', side * 17, 8.5, -63, 1, 1.1, 1);
          }
          add(crystal, '#3a3444', -27, 9, -100, 25, 22, 20);
          add(ring, '#f5b36b', -27, 18.7, -100, 4, 4, 4, true, 0, Math.PI / 2);
        } else {
          for (const side of [-1, 1]) for (let j = 0; j < 10; j++) {
            const h = 12 + j * 7 % 22, x = side * (16 + j * 3.5);
            add(box, '#24354c', x, h / 2, -65 - j * 3, 3.2, h, 6);
            add(box, '#526576', x, h + .1, -65 - j * 3, 3.6, .25, 6.4);
            for (let k = 0; k < 8; k++) add(box, '#8aa6b6', x, 2 + k * 2.5, -61.9 - j * 3, 1.6, .13, .04, true);
          }
        }
      });
      if (world === 'orbit') {
        const canvas = document.createElement('canvas'); canvas.width = 512; canvas.height = 256; const c = canvas.getContext('2d')!;
        const grad = c.createLinearGradient(0, 0, 0, 256); grad.addColorStop(0, '#6a77b0'); grad.addColorStop(.3, '#b1bbd1'); grad.addColorStop(.48, '#657caa'); grad.addColorStop(.62, '#c6adac'); grad.addColorStop(1, '#424b86'); c.fillStyle = grad; c.fillRect(0, 0, 512, 256);
        for (let j = 0; j < 130; j++) { c.strokeStyle = j % 2 ? '#d8d6d72b' : '#313e7130'; c.lineWidth = 1 + j % 3; c.beginPath(); for (let x = 0; x <= 512; x += 4) { const y = j * 2 + Math.sin(x * .025 + j * .6) * 3; if (!x) c.moveTo(x, y); else c.lineTo(x, y); } c.stroke(); }
        const map = new THREE.CanvasTexture(canvas); map.colorSpace = THREE.SRGBColorSpace; this.textures.push(map);
        const mat = new THREE.MeshStandardMaterial({ map, roughness: 1, fog: false, emissive: '#242e51', emissiveIntensity: .35 }); this.materials.push(mat);
        this.planet = new THREE.Mesh(keep(new THREE.SphereGeometry(10, 48, 32)), mat); this.planet.position.set(-19, 22, -91); this.planet.rotation.z = -.22; horizon.add(this.planet);
        const rings = new THREE.Mesh(keep(new THREE.RingGeometry(12, 19, 96, 6)), new THREE.MeshBasicMaterial({ color: '#a4a0bf', side: THREE.DoubleSide, transparent: true, opacity: .55, fog: false })); this.materials.push(rings.material); rings.position.copy(this.planet.position); rings.rotation.set(1.15, .2, -.25); horizon.add(rings);
      }
      // Landmark in the traversed space: high torii, station gantry or ruin arch.
      if (world === 'sakura') {
        const gate = bake(world, add => {
          for (const side of [-1, 1]) { add(cylinder, '#8b515f', side * 5.15, 3.2, 0, .2, 6.4, .2, false, side * .04); add(box, '#463d51', side * 5.15, .15, 0, .7, .3, .7); }
          add(roof, '#4b4359', 0, 6.4, 0, 6.1, 1.1, 1.2); add(box, '#a6717c', 0, 5.6, 0, 11, .23, .26); add(box, '#d4a69b', 0, 5.9, .1, .45, .9, .12);
        }); scene.add(gate); gate.visible = false; this.tiles.push({world, index: 0, group: gate});
      }
      horizon.visible = false; scene.add(horizon); this.horizons.set(world, horizon);
      // Sparse slow atmosphere is decoration, never a screen flash or obstacle.
      if (world !== 'city') {
        const positions: number[] = [], count = world === 'orbit' ? 180 : 55;
        for (let j = 0; j < count; j++) { positions.push(Math.sin(j * 24.31) * (world === 'orbit' ? 55 : 8), 1 + (j * 1.73 % (world === 'orbit' ? 45 : 8)), -((j * 3.71) % 100)); }
        const geo = keep(new THREE.BufferGeometry()); geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
        const mat = new THREE.PointsMaterial({ color: world === 'sakura' ? '#f5c3d4' : world === 'ember' ? '#ffc38a' : '#bbdfef', size: world === 'sakura' ? .065 : .04, transparent: true, opacity: .65, depthWrite: false, fog: world !== 'orbit' }); this.materials.push(mat);
        const points = new THREE.Points(geo, mat); scene.add(points); points.visible = false; this.atmosphere.set(world, points);
      }
    }
    sources.forEach(g => g.dispose());
  }
  get sakuraFailed() { return this.blenderSakura.failed; }
  get sakuraReady() { return this.blenderSakura.ready; }
  update(world: WorldId, distance: number, dt = 0) {
    this.time += Math.max(0, dt);
    const blender = this.blenderSakura.ready && world === 'sakura';
    this.blenderSakura.update(blender, distance);
    for (const tile of this.tiles) {
      tile.group.visible = tile.world === world && !(blender && tile.world === 'sakura');
      tile.group.position.z = 12 - (((tile.index >> 1) * 18 - distance) % 144 + 144) % 144;
    }
    for (const [id, horizon] of this.horizons) horizon.visible = id === world && !(blender && id === 'sakura');
    for (const [id, points] of this.atmosphere) { points.visible = id === world; points.position.y = Math.sin(this.time * .12) * .3; points.position.z = (distance * .08) % 5; }
    if (this.planet) this.planet.rotation.y = this.time * .012;
  }
  dispose() { this.blenderSakura.dispose(); this.materials.forEach(m => m.dispose()); this.textures.forEach(t => t.dispose()); }
}
