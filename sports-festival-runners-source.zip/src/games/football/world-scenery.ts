import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { WORLD_IDS, type WorldId } from './worlds';

// Scenery never enters the playable 8.8m road. Bake details by material so
// architectural detail does not mean one draw call for every window or petal.
export class WorldScenery {
  private tiles: { world: WorldId; index: number; group: THREE.Group }[] = [];
  private horizons = new Map<WorldId, THREE.Group>();
  constructor(scene: THREE.Scene, keep: <T extends THREE.BufferGeometry>(g: T) => T, material: (color: string, glow?: boolean) => THREE.MeshStandardMaterial) {
    const box = new THREE.BoxGeometry(1, 1, 1), sphere = new THREE.SphereGeometry(1, 12, 8);
    const rock = new THREE.IcosahedronGeometry(1, 1), pillar = new THREE.CylinderGeometry(.75, 1, 1, 7);
    const ring = new THREE.TorusGeometry(1, .035, 6, 48);
    const bake = (build: (add: (g: THREE.BufferGeometry, color: string, x: number, y: number, z: number, sx: number, sy: number, sz: number, glow?: boolean, rz?: number, rx?: number) => void) => void) => {
      const batches = new Map<string, THREE.BufferGeometry[]>(), group = new THREE.Group();
      const transform = new THREE.Object3D();
      build((g, color, x, y, z, sx, sy, sz, glow = false, rz = 0, rx = 0) => {
        transform.position.set(x, y, z); transform.scale.set(sx, sy, sz); transform.rotation.set(rx, 0, rz); transform.updateMatrix();
        const key = `${color}/${glow}`, list = batches.get(key) ?? [];
        list.push(g.clone().applyMatrix4(transform.matrix)); batches.set(key, list);
      });
      for (const [key, list] of batches) {
        const [color, glow] = key.split('/');
        const geometry = mergeGeometries(list, false)!; keep(geometry);
        group.add(new THREE.Mesh(geometry, material(color, glow === 'true'))); list.forEach(g => g.dispose());
      }
      return group;
    };
    for (const world of WORLD_IDS) {
      for (let index = 0; index < 16; index++) {
        const side = index % 2 ? -1 : 1, variant = (index >> 1) % 4;
        const group = bake(add => {
          if (world === 'city') {
            // Layered art-deco towers, recessed windows, awnings and brass trim.
            const h = 7 + variant * 2.3;
            add(box, '#24384c', side * 2, h / 2, 0, 3.2, h, 8);
            add(box, '#344c60', side * 2, h + .25, 0, 2.6, .5, 7.2);
            add(box, '#152a3b', 0, 1.5, 0, .3, 3, 7.8);
            add(box, '#678483', -.2 * side, 2.9, 0, 1.5, .12, 8.2);
            for (let level = 0; level < 5 + variant; level++) {
              add(box, '#51626c', side * .36, 1 + level * 1.25, 0, .12, .06, 7.6);
              for (let j = 0; j < 5; j++) add(box, (j + level + variant) % 4 ? '#b49b79' : '#45616c', side * .37, 1.4 + level * 1.25, j * 1.4 - 2.8, .05, .55, .65, true);
            }
            add(box, '#82c7be', -side * .45, 4.2, -2.8, .12, 2.1, .6, true);
            add(box, '#b4a382', -side * .3, .18, 0, .9, .18, 8);
          } else if (world === 'sakura') {
            // Curved branching silhouette and many small blossom clusters.
            add(pillar, '#3b303d', side * .4, 1.7, 0, .42, 3.5, .42, false, -side * .18);
            for (let branch = 0; branch < 5; branch++) {
              const a = branch * 2.4 + variant, x = Math.cos(a) * 1.2, z = Math.sin(a) * 1.4;
              add(pillar, '#624755', x * .5, 3.3, z * .5, .16, 2.4, .16, false, -x * .5);
              for (let j = 0; j < 7; j++) {
                const angle = j * 2.399 + branch;
                add(sphere, ['#a76686', '#d99bb6', '#e5b7c7'][(j + branch) % 3], x + Math.cos(angle) * .85, 4.2 + Math.sin(j * 1.7) * .45, z + Math.sin(angle) * .9, .7, .38, .65);
              }
            }
            add(box, '#67666b', 0, .1, 0, 2.8, .2, 3.3);
            // Stone lantern with roof, luminous paper core and cap.
            add(box, '#77717a', -side * .8, .6, -3.6, .35, 1.2, .35);
            add(box, '#ffca9a', -side * .8, 1.35, -3.6, .45, .45, .45, true);
            add(box, '#55515f', -side * .8, 1.65, -3.6, .8, .13, .8);
            add(pillar, '#55515f', -side * .8, 1.8, -3.6, .2, .25, .2);
            for (let j = 0; j < 12; j++) add(sphere, '#c58b9e', -side + Math.sin(j * 3) * .5, .04, j * .65 - 4, .1, .015, .06);
          } else if (world === 'ice') {
            // Stratified canyon faces and polished, asymmetric crystal veins.
            for (let j = 0; j < 4; j++) {
              const h = 4 + (j * 3 + variant) % 5;
              add(rock, ['#365770', '#4e7791', '#658ca2'][j % 3], side * (1.5 + j * .7), h * .42, j * 2 - 3, 2.3, h * .7, 2.1);
              add(pillar, '#8ac5d6', side * (j * .4), 1.8 + j * .3, j * 1.5 - 2, .5, 3.7 + j, .6, false, side * (.2 + j * .06));
              add(box, '#c2edf0', -side * .3, 1 + j * .85, j * 1.5 - 2, .045, 1.8, .12, true, side * .2);
            }
            add(box, '#a6c8d1', 0, .12, 0, 2.8, .2, 9);
            for (let j = 0; j < 5; j++) add(box, '#567d96', 0, .23, j * 1.8 - 3.6, 2.5, .025, .055, false, .025);
          } else if (world === 'orbit') {
            // Orbital dock: segmented ribs, inset panels, light strips and pods.
            add(box, '#353b58', side * 1.5, -.2, 0, 4, .5, 10);
            add(box, '#555879', side * 2.5, 2.2, 0, .5, 4.4, 9);
            for (let j = 0; j < 4; j++) {
              add(box, '#9399b1', side * 1, 2.7, j * 2.5 - 3.75, 3, .18, .23, false, side * .55);
              add(box, '#b2acf1', -.25 * side, .07, j * 2.5 - 3.75, .1, .04, 1.3, true);
              add(box, '#171f38', side * 2.2, 1.8, j * 2.5 - 3.75, .15, 1.3, 1.8);
              add(box, '#88bcd1', side * 2.1, 2.1, j * 2.5 - 3.75, .04, .12, .9, true);
            }
            add(sphere, '#687993', side * 1.5, 1.1, 1.2, .9, .65, 1.7);
            add(ring, '#c7c1eb', side * 1.5, 1.1, 1.2, 1, 1, 1, true, 0, Math.PI / 2);
          } else {
            // Basalt colonnade, engraved temple masonry and lava channels.
            for (let j = 0; j < 5; j++) {
              const h = 2 + (variant + j * 2) % 5;
              add(pillar, '#39343d', side * (1 + j % 2), h / 2, j * 1.9 - 4, .8, h, .8);
              add(pillar, '#69515a', side * (1 + j % 2), h, j * 1.9 - 4, .82, .15, .82);
              add(box, '#e59656', -.3 * side, .28, j * 1.9 - 4, .4, .05, 1.6, true);
            }
            add(box, '#3c3039', side * 1.5, .1, 0, 3.7, .3, 10);
            for (let j = 0; j < 3; j++) {
              add(box, '#95725e', -side * .6, .6 + j * .32, 0, .055, .06, 5);
              add(box, '#e6a36a', -side * .65, 1.2 + j * .25, 2.8, .04, .13, .15, true);
            }
          }
        });
        group.position.x = side * 6.3; group.visible = false;
        scene.add(group); this.tiles.push({ world, index, group });
      }
      const horizon = bake(add => {
        if (world === 'orbit') {
          add(sphere, '#8587b4', -18, 19, -92, 11, 11, 11);
          add(ring, '#b7a6cd', -18, 19, -90, 19, 6, 19, true, -.3);
          for (let j = 0; j < 65; j++) add(sphere, '#bcc5e8', Math.sin(j * 7) * 65, 11 + (j * 13 % 41), -95, .09, .09, .09, true);
          for (let j = 0; j < 4; j++) add(ring, '#596482', 0, 8, -45 - j * 16, 15, 15, 1);
        } else if (world === 'sakura') {
          // Layered shrine roofs beyond the avenue, not a wall across the road.
          for (const side of [-1, 1]) for (let j = 0; j < 4; j++) {
            add(box, '#4c3e55', side * 17, 2 + j * 3, -77, 7 - j, 2, 9 - j);
            add(box, '#383649', side * 17, 3.5 + j * 3, -77, 10 - j, .45, 12 - j);
            add(box, '#b88d87', side * 17, 2.8 + j * 3, -72 + j * .5, 6 - j, .15, .12);
          }
        } else if (world === 'ember') {
          for (const side of [-1, 1]) for (let j = 0; j < 6; j++) {
            add(box, '#51434a', side * 16, j * 1.8, -75, 24 - j * 3, 1.8, 22 - j * 3);
            add(box, '#c38257', side * 16, j * 1.8 + .92, -64 - j * 1.5, 23 - j * 3, .055, .08, true);
          }
          for (let j = 0; j < 30; j++) add(sphere, '#d59b72', Math.sin(j * 5) * 40, 2 + j % 10, -55 - j, .05, .08, .05, true);
        } else {
          for (const side of [-1, 1]) for (let j = 0; j < 10; j++) {
            const h = 9 + (j * 7 % 19), x = side * (15 + j * 3.2);
            add(world === 'ice' ? rock : box, world === 'ice' ? '#486b84' : '#26364e', x, h / 2, -65 - j * 3, world === 'ice' ? 6 : 3, h, 6);
            if (world === 'city') for (let k = 0; k < 6; k++) add(box, '#708b98', x, 2 + k * 2.8, -61 - j * 3, 1.4, .15, .04, true);
            else add(rock, '#8daebe', x, h + .1, -65 - j * 3, 4, .8, 4);
          }
        }
      });
      horizon.visible = false; scene.add(horizon); this.horizons.set(world, horizon);
    }
    [box, sphere, rock, pillar, ring].forEach(g => g.dispose());
  }
  update(world: WorldId, distance: number) {
    for (const tile of this.tiles) {
      tile.group.visible = tile.world === world;
      tile.group.position.z = 12 - (((tile.index >> 1) * 18 - distance) % 144 + 144) % 144;
    }
    for (const [id, horizon] of this.horizons) horizon.visible = id === world;
  }
}
