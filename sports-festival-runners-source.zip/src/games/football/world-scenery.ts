import * as THREE from 'three';
import { WORLD_IDS, type WorldId } from './worlds';

// Decorative geometry stays outside the playable road. No new camera motion.
export class WorldScenery {
  private tiles: { world: WorldId; index: number; group: THREE.Group }[] = [];
  constructor(scene: THREE.Scene, keep: <T extends THREE.BufferGeometry>(g: T) => T, material: (color: string, glow?: boolean) => THREE.MeshStandardMaterial) {
    const trunk = keep(new THREE.CylinderGeometry(.18, .32, 3, 6));
    const crystal = keep(new THREE.ConeGeometry(1, 1, 5));
    const sphere = keep(new THREE.IcosahedronGeometry(1, 1));
    const torus = keep(new THREE.TorusGeometry(1.2, .08, 5, 32));
    const box = keep(new THREE.BoxGeometry(1, 1, 1));
    for (const world of WORLD_IDS.filter(w => w !== 'city')) for (let index = 0; index < 20; index++) {
      const group = new THREE.Group(), side = index % 2 ? -1 : 1;
      const add = (geo: THREE.BufferGeometry, color: string, x: number, y: number, z: number, sx = 1, sy = 1, sz = 1, glow = false) => {
        const mesh = new THREE.Mesh(geo, material(color, glow)); mesh.position.set(x, y, z); mesh.scale.set(sx, sy, sz); group.add(mesh); return mesh;
      };
      if (world === 'sakura') {
        add(trunk, '#5b4856', 0, 1.5, 0);
        add(sphere, '#a16b91', -.5, 3.3, 0, 1.5, .8, 1.2);
        add(sphere, '#d197b6', .6, 3.8, .2, 1.3, .75, 1.1);
        add(sphere, '#ba82a4', 0, 3.5, -.6, 1.4, .8, 1.2);
      } else if (world === 'ice') {
        add(crystal, '#7196b6', 0, 2, 0, 1.4, 4, 1.1).rotation.z = side * .15;
        add(crystal, '#a2dbe8', side, 1.2, -.4, .7, 2.4, .8).rotation.z = -side * .2;
        add(box, '#38566d', 0, .15, 0, 2.8, .3, 2);
      } else if (world === 'orbit') {
        add(torus, '#b5a1ec', 0, 2.7, 0, 1.4, 1.4, 1.4, true).rotation.y = side * .5;
        add(sphere, index % 3 ? '#6d679b' : '#ad8997', 0, 2.7, 0, .8, .8, .8);
        for (let j = 0; j < 3; j++) add(sphere, '#ddd8ff', side * (1.5 + j * .3), 4.5 + j, -.5, .05, .05, .05, true);
      } else {
        add(crystal, '#473d48', 0, 1.6, 0, 1.8, 3.2, 1.5);
        add(crystal, '#634853', side, 1, -.5, 1, 2, 1);
        add(box, '#c47e55', 0, .14, .7, .12, .05, 2.5, true);
        add(box, '#e4a06c', .4, .17, -.2, 1, .05, .1, true);
      }
      group.position.x = side * (6.8 + index % 3 * .35); group.visible = false;
      scene.add(group); this.tiles.push({ world, index, group });
    }
  }
  update(world: WorldId, distance: number) {
    for (const tile of this.tiles) {
      tile.group.visible = tile.world === world;
      tile.group.position.z = 8 - (((tile.index >> 1) * 12 - distance) % 120 + 120) % 120;
    }
  }
}
