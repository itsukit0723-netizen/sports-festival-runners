import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import url from '../../assets/football-players.glb?url';

/** One shared asset per renderer; clones share buffers and materials. */
export class BlenderPlayers {
  ready = false;
  private disposed = false;
  private source?: THREE.Group;
  constructor(onReady: (athlete: THREE.Object3D, ball: THREE.Object3D) => void) {
    void new GLTFLoader().loadAsync(url).then(gltf => {
      this.source = gltf.scene;
      if (this.disposed) { this.release(); return; }
      const athlete = gltf.scene.getObjectByName('Athlete'), ball = gltf.scene.getObjectByName('MatchBall');
      if (!athlete || !ball || ['head','leftArm','rightArm','leftLeg','rightLeg'].some(name => !athlete.getObjectByName(name))) throw new Error('Incomplete player asset');
      onReady(athlete, ball); this.ready = true;
    }).catch(error => { if (!this.disposed) console.warn('Player models unavailable; keeping fallback graphics.', error); });
  }
  private release() {
    const geometries = new Set<THREE.BufferGeometry>(), materials = new Set<THREE.Material>(), textures = new Set<THREE.Texture>();
    this.source?.traverse(o => { if (o instanceof THREE.Mesh) {
      geometries.add(o.geometry);
      for (const m of Array.isArray(o.material) ? o.material : [o.material]) { materials.add(m); for (const t of Object.values(m)) if (t instanceof THREE.Texture) textures.add(t); }
    } });
    geometries.forEach(g => g.dispose()); materials.forEach(m => m.dispose());
    textures.forEach(t => { t.dispose(); (t.image as {close?:()=>void}|undefined)?.close?.(); }); this.source = undefined;
  }
  dispose() { this.disposed = true; this.release(); }
}
