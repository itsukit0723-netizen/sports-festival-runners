import type { WorldId } from './worlds';
export interface WorldPlacement { world: Exclude<WorldId,'sakura'>; name:string; x:number; y:number; z:number; scale:number; rotation:number; offset?:number; period?:number }
export const WORLD_MODEL_PLACEMENTS: WorldPlacement[] = [];
const add=(world:WorldPlacement['world'],name:string,x:number,y:number,z:number,scale=1,rotation=0,offset?:number,period=144)=>WORLD_MODEL_PLACEMENTS.push({world,name,x,y,z,scale,rotation,offset,period});
for(const side of [-1,1])for(let i=0;i<8;i++){
  add('city',i%2?'City_Facade_A':'City_Facade_B',side*8.4,0,0,1,-side*Math.PI/2,i*18);
  add('city','City_Street',side*5.9,0,0,1,side<0?Math.PI:0,i*18+5);
  add('ice',i%2?'Ice_Cliff_A':'Ice_Cliff_B',side*8.4,0,0,1,side<0?Math.PI:0,i*18);
  add('ice','Ice_Crystals',side*5.7,0,0,1,side<0?Math.PI:0,i*18+7);
  add('orbit','Orbit_Dock',side*7.3,0,0,1,side<0?Math.PI:0,i*18);
  add('ember','Ember_Colonnade',side*8,0,0,1,side<0?Math.PI:0,i*18);
}
for(const side of [-1,1])for(let i=0;i<12;i++)add('ember','Ember_River',side*5.8,0,0,1,side<0?Math.PI:0,i*12);
add('city','City_Clocktower',-18,0,-78,.85);
add('city','City_Facade_B',19,0,-80,1.6);
add('ice','Ice_Arch',0,0,0,1,0,42);
for(const side of [-1,1])add('ice','Ice_Mountain',side*26,-1,-97,1);
add('orbit','Orbit_Gantry',0,0,0,1,0,35);
add('orbit','Orbit_Gantry',0,0,0,1,0,106);
add('orbit','Orbit_Planet',-18,22,-92,1);
add('orbit','Orbit_Satellite',11,7,-46,1,.25);
add('orbit','Orbit_Satellite',-12,10,-75,1.2,-.3);
add('ember','Ember_Temple',-19,0,-63,1.3,.12);
add('ember','Ember_Temple',21,0,-82,1.5,-.15);
add('ember','Ember_Volcano',-30,-1,-101,1);
