import type { ChunkKind } from './chunks';
export const WORLD_IDS = ['city', 'sakura', 'ice', 'orbit', 'ember'] as const;
export type WorldId = typeof WORLD_IDS[number];
export const WORLDS: Record<WorldId, { name: string; sky: string; horizon: string; floor: string; fog: string; accent: string; kinds: readonly ChunkKind[] }> = {
  city: { name: 'ネオン街', sky: '#192638', horizon: '#637788', floor: '#304847', fog: '#34475c', accent: '#a5ffe5', kinds: ['mediumWalls', 'mediumSlidingWalls', 'mediumDefender', 'mediumBars'] },
  sakura: { name: '桜の森', sky: '#241d35', horizon: '#75637e', floor: '#3d3949', fog: '#493e57', accent: '#ffb7d5', kinds: ['mediumSlalom', 'mediumDefender', 'mediumBars', 'mediumRollers'] },
  ice: { name: '氷の峡谷', sky: '#152b3c', horizon: '#5b879b', floor: '#37566a', fog: '#365b70', accent: '#9defff', kinds: ['mediumSlidingWalls', 'mediumSlalom', 'mediumWalls', 'mediumRollers'] },
  orbit: { name: '宇宙回廊', sky: '#17172f', horizon: '#514875', floor: '#34354d', fog: '#35304f', accent: '#cfb4ff', kinds: ['mediumRotors', 'mediumRollers', 'mediumSlalom', 'mediumSlidingWalls'] },
  ember: { name: '溶岩遺跡', sky: '#2b2028', horizon: '#806459', floor: '#463a39', fog: '#5c4140', accent: '#ffc18a', kinds: ['mediumRotors', 'mediumBars', 'mediumSlidingWalls', 'mediumWalls'] },
};
export function gateWorlds(variant: number, index: number, previous: readonly WorldId[] = []): [WorldId, WorldId] {
  const available = WORLD_IDS.filter(world => !previous.includes(world));
  const a = (variant + index * 3) % available.length;
  return [available[a], available[(a + 1 + index % (available.length - 1)) % available.length]];
}
