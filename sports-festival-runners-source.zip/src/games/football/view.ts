import * as THREE from 'three';
import {FOOTBALL as F} from '../../core/config';

/** Static centered framing: both sidelines remain visible even at maximum steer. */
export function frameFootball(camera:THREE.PerspectiveCamera,width:number,height:number) {
  if(width<=0||height<=0)return;
  camera.clearViewOffset();camera.aspect=width/height;
  camera.position.set(0,10.5,12.5);camera.lookAt(0,.1,-11);camera.updateMatrixWorld(true);
  const depth=-new THREE.Vector3(0,F.ballRadius+.03,0).applyMatrix4(camera.matrixWorldInverse).z;
  const halfView=F.courseWidth/2+.75;
  camera.fov=Math.max(43,2*Math.atan(halfView/(depth*camera.aspect))*180/Math.PI);
  camera.updateProjectionMatrix();
  const ballY=(1-new THREE.Vector3(0,F.ballRadius+.03,0).project(camera).y)/2;
  // Off-axis framing uses the lower screen for the player without animated tilt.
  const playerY=height>width?.82:.77;
  camera.setViewOffset(width,height,0,(ballY-playerY)*height,width,height);
  camera.updateMatrixWorld(true);
}
export const routeSignOpacity=(remaining:number)=>Math.max(0,Math.min(1,(remaining-8)/8));
export const pickupVisible=(remaining:number)=>remaining>=-1.25;
