export const routeSignOpacity=(remaining:number)=>Math.max(0,Math.min(1,(remaining-8)/8));
export const pickupVisible=(remaining:number)=>remaining>=-1.25;
