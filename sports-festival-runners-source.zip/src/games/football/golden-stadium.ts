import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
export const TROPHY_SPACING=56;
export const TROPHY_PHASE=-19.3;
export const TROPHY_SIDE=6.75;

/** An event-only stadium, with batched stands and no collision-bearing props. */
export class GoldenStadium {
  readonly group=new THREE.Group();
  readonly surface:THREE.CanvasTexture;
  private geometries:THREE.BufferGeometry[]=[];
  private materials:THREE.Material[]=[];
  private textures:THREE.Texture[]=[];
  private tiles:THREE.Group[]=[];
  private trophyBays:THREE.Group[]=[];
  private trophyMounts:THREE.Group[]=[];
  private flags:THREE.Mesh[]=[];
  private confetti:THREE.Points;
  constructor() {
    const keep=<T extends THREE.BufferGeometry>(g:T)=>{this.geometries.push(g);return g;};
    const mat=(color:string,metalness=0,glow=0)=>{const m=new THREE.MeshStandardMaterial({color,roughness:metalness>.5?.3:.7,metalness,emissive:color,emissiveIntensity:glow});this.materials.push(m);return m;};
    const gold=mat('#dbad50',.8),ivory=mat('#eee4ce',.25),dark=mat('#14213a',.25),velvet=mat('#493554'),stone=mat('#3e455d',.3),light=mat('#ffe5a7',.35,.8),cyan=mat('#9be9e0',.3,.35);
    const box=new THREE.BoxGeometry(1,1,1),cylinder=new THREE.CylinderGeometry(1,1,1,12),sphere=new THREE.IcosahedronGeometry(1,0);
    const baseGeos:THREE.BufferGeometry[]=[box,cylinder,sphere];
    const template=new THREE.Group(),batches=new Map<THREE.Material,THREE.BufferGeometry[]>(),transform=new THREE.Object3D();
    const add=(g:THREE.BufferGeometry,m:THREE.Material,x:number,y:number,z:number,sx:number,sy:number,sz:number,rz=0,ry=0)=>{
      transform.position.set(x,y,z);transform.scale.set(sx,sy,sz);transform.rotation.set(0,ry,rz);transform.updateMatrix();
      const copy=(g.index?g.toNonIndexed():g.clone()).applyMatrix4(transform.matrix);if(!batches.has(m))batches.set(m,[]);batches.get(m)!.push(copy);
    };
    for(const side of [-1,1]) {
      // Raised grandstands, gilded aisle stairs, railings and hundreds of seats.
      for(let tier=0;tier<7;tier++) {
        const x=side*(8.2+tier*1.6),y=1+tier*.87;
        add(box,tier%2?dark:stone,x,y/2,-14,1.65,y,28);
        for(let row=0;row<2;row++)for(let seat=0;seat<22;seat++) {
          const z=-.8-seat*1.23,px=x+side*(row-.5)*.58;
          add(box,(seat+tier)%5===0?gold:velvet,px,y+.12,z,.43,.17,.7);
          add(box,(seat+tier)%5===0?gold:velvet,px+side*.17,y+.42,z,.12,.48,.65);
          add(sphere,(seat*11+tier)%4?ivory:gold,px,y+.55,z,.105,.12,.105);
        }
        add(box,gold,x,y+.7,-14,.045,.045,28);
        for(let step=0;step<4;step++)add(box,light,side*(7.6+tier*1.6),y+.04,-step*7-3,.12,.03,1.2);
      }
      // Close colonnade and arena barrier (outside the ±4.4 playable floor).
      add(box,dark,side*5.05,.48,-14,.65,.95,28);
      add(box,gold,side*5.05,.98,-14,.72,.06,28);
      for(const z of [-2,-9,-16,-23]) {
        add(cylinder,stone,side*6.8,3.4,z,.29,6.8,.29);
        add(cylinder,gold,side*6.8,.22,z,.48,.44,.48);
        add(cylinder,gold,side*6.8,6.7,z,.48,.22,.48);
        for(let i=0;i<8;i++) {const a=i*Math.PI/4;add(cylinder,ivory,side*6.8+Math.cos(a)*.275,3.5,z+Math.sin(a)*.275,.028,5.9,.028);}
        add(box,velvet,side*6.8,5,z+.4,1.1,2.2,.07);
        add(box,gold,side*6.8,4.1,z+.45,.9,.055,.04);
        add(box,light,side*5.02,.52,z,.03,.5,1.4);
      }
      // VIP balcony and canopy over the high tiers.
      add(box,dark,side*17.4,7.5,-14,3.5,.6,28);
      add(box,gold,side*17.4,7.86,-14,3.7,.075,28);
      for(let j=0;j<7;j++){add(box,cyan,side*17.5,8.5,-2-j*4,2.8,.8,3.5);add(box,gold,side*17.5,9,-2-j*4,2.9,.05,3.6);}
    }
    const arch=new THREE.TorusGeometry(12,.11,8,56,Math.PI);baseGeos.push(arch);
    for(const z of [-1,-27]) {
      add(arch,gold,0,8,z,1,1,1);
      add(arch,light,0,8,z-.18,.985,.985,1);
      for(const side of [-1,1])add(cylinder,gold,side*12,4,z,.13,8,.13);
    }
    const spine=new THREE.CylinderGeometry(1,1,1,8);spine.rotateX(Math.PI/2);baseGeos.push(spine);
    for(let i=0;i<13;i++) {
      const a=i/12*Math.PI;
      add(spine,stone,Math.cos(a)*12,8+Math.sin(a)*12,-14,.05,.05,26);
      for(const z of [-4,-24])add(box,light,Math.cos(a)*11.8,8+Math.sin(a)*11.8,z,.45,.12,.5);
    }
    for(const [m,parts] of batches){const geo=keep(mergeGeometries(parts)!);parts.forEach(p=>p.dispose());template.add(new THREE.Mesh(geo,m));}
    baseGeos.forEach(g=>g.dispose());
    for(let i=0;i<5;i++){const tile=template.clone();this.group.add(tile);this.tiles.push(tile);}
    // A correctly grounded fallback is shown until the Blender asset is ready.
    // Small display bays sit between columns, beneath the flags, outside the road.
    const fallback=new THREE.Group();
    const baseGeo=keep(new THREE.CylinderGeometry(.68,.78,1.05,8)),base=new THREE.Mesh(baseGeo,stone);base.position.y=.525;fallback.add(base);
    const foot=new THREE.Mesh(keep(new THREE.CylinderGeometry(.5,.56,.15,24)),dark);foot.position.y=1.125;fallback.add(foot);
    const profile=[[0,1.2],[.35,1.2],[.14,1.42],[.13,1.78],[.3,1.94],[.48,2.2],[.61,2.7],[.64,2.98],[.59,2.98],[.55,2.7],[.4,2.2],[.17,1.99],[0,1.99]].map(([r,y])=>new THREE.Vector2(r,y));
    fallback.add(new THREE.Mesh(keep(new THREE.LatheGeometry(profile,32)),gold));
    for(const side of [-1,1]){
      const curve=new THREE.CatmullRomCurve3([new THREE.Vector3(side*.62,2.87,0),new THREE.Vector3(side*.9,2.9,0),new THREE.Vector3(side*1.01,2.64,0),new THREE.Vector3(side*.79,2.29,0),new THREE.Vector3(side*.47,2.2,0)]);
      fallback.add(new THREE.Mesh(keep(new THREE.TubeGeometry(curve,20,.045,6,false)),gold));
    }
    for(let index=0;index<3;index++)for(const side of [-1,1]){
      const bay=new THREE.Group();bay.name=`TrophyBay-${index}-${side}`;bay.position.set(side*TROPHY_SIDE,0,0);bay.userData.row=index;
      const mount=new THREE.Group();mount.name='TrophyMount';mount.add(fallback.clone(true));bay.add(mount);this.trophyMounts.push(mount);
      // Display plate and contact footprint both touch the arena foundation.
      const plate=new THREE.Mesh(keep(new THREE.CylinderGeometry(1.12,1.16,.2,32)),dark);plate.name='TrophyDisplayPlate';plate.position.y=-.1;bay.add(plate);
      this.group.add(bay);this.trophyBays.push(bay);
    }
    // High scoreboard and woven flags form a distinct finals venue at the horizon.
    const screen=document.createElement('canvas');screen.width=1024;screen.height=256;const c=screen.getContext('2d')!;
    c.fillStyle='#101b32';c.fillRect(0,0,1024,256);c.strokeStyle='#d4ac62';c.lineWidth=10;c.strokeRect(6,6,1012,244);
    c.textAlign='center';c.fillStyle='#ffe7b0';c.font='bold 71px sans-serif';c.fillText('GOLDEN COLOSSEUM',512,115);c.font='28px sans-serif';c.fillText('SPORTS FESTIVAL   ✦   THE GRAND FINALS',512,181);
    const texture=new THREE.CanvasTexture(screen);texture.colorSpace=THREE.SRGBColorSpace;this.textures.push(texture);
    const screenMaterial=new THREE.MeshBasicMaterial({map:texture});this.materials.push(screenMaterial);
    const board=new THREE.Mesh(keep(new THREE.PlaneGeometry(26,6.5)),screenMaterial);board.position.set(0,12,-82);this.group.add(board);
    const flagGeo=keep(new THREE.PlaneGeometry(2,3,6,8)),pos=flagGeo.getAttribute('position');
    for(let i=0;i<pos.count;i++)pos.setZ(i,Math.sin(pos.getX(i)*3+pos.getY(i)*2)*.12);flagGeo.computeVertexNormals();
    const flagMaterial=new THREE.MeshStandardMaterial({color:'#9c294b',metalness:.25,roughness:.5,side:THREE.DoubleSide});this.materials.push(flagMaterial);
    for(const side of [-1,1])for(let i=0;i<8;i++) {
      const flag=new THREE.Mesh(flagGeo,flagMaterial);flag.position.set(side*8.1,7,-i*12);flag.rotation.y=side*.3;this.group.add(flag);this.flags.push(flag);
    }
    const floor=document.createElement('canvas');floor.width=floor.height=512;const f=floor.getContext('2d')!;
    f.fillStyle='#223d50';f.fillRect(0,0,512,512);
    for(let i=0;i<16;i++){f.fillStyle=i%2?'#2c4657':'#263f50';f.fillRect(0,i*32,512,32);}
    for(const x of [12,27,485,500]){f.fillStyle='#d6bd80';f.fillRect(x,0,2,512);}
    f.strokeStyle='#aecbb721';f.lineWidth=2;f.strokeRect(45,25,422,462);f.beginPath();f.arc(256,256,87,0,Math.PI*2);f.stroke();
    this.surface=new THREE.CanvasTexture(floor);this.surface.colorSpace=THREE.SRGBColorSpace;this.surface.wrapS=this.surface.wrapT=THREE.RepeatWrapping;this.surface.repeat.set(1,20);this.textures.push(this.surface);
    const particles=new Float32Array(96*3);
    for(let i=0;i<96;i++){particles[i*3]=(i%2?-1:1)*(5.6+(i*17%81)/10);particles[i*3+1]=2+(i*31%109)/10;particles[i*3+2]=-i*1.12;}
    const confettiGeo=keep(new THREE.BufferGeometry());confettiGeo.setAttribute('position',new THREE.BufferAttribute(particles,3));
    const confettiMat=new THREE.PointsMaterial({color:'#ffdf95',size:.065,transparent:true,opacity:.75,depthWrite:false});this.materials.push(confettiMat);this.confetti=new THREE.Points(confettiGeo,confettiMat);this.group.add(this.confetti);
  }
  update(distance:number,time:number,reduced:boolean) {
    for(let i=0;i<this.tiles.length;i++)this.tiles[i].position.z=14-i*28+distance%28;
    const t=reduced?0:time;
    for(const bay of this.trophyBays)bay.position.z=TROPHY_PHASE-bay.userData.row*TROPHY_SPACING+distance%TROPHY_SPACING;
    this.flags.forEach((flag,i)=>flag.rotation.y=Math.sin(t*.8+i)*.09+(i<8?-.3:.3));
    this.confetti.visible=!reduced;this.confetti.position.y=-t*.22%3;this.confetti.position.z=distance%8;
    this.surface.offset.y=-distance/5;
  }
  setTrophy(model:THREE.Object3D){
    for(const mount of this.trophyMounts){mount.clear();mount.add(model.clone(true));}
  }
  dispose(){this.geometries.forEach(g=>g.dispose());this.materials.forEach(m=>m.dispose());this.textures.forEach(t=>t.dispose());this.group.removeFromParent();}
}
