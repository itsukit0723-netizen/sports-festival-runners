import {clamp} from '../../core/types';

/** Lateral shuffle: feet and counterbalance follow actual travel, not a timer
 * that keeps waving the limbs when the defender has planted their feet. */
export function defenderPose(time:number,velocity:number,tracking:number){
 const effort=clamp(Math.abs(velocity)/2.6,0,1),step=Math.sin(time*9)*effort;
 return {step,effort,direction:Math.sign(velocity),lean:clamp(-velocity*.016,-.042,.042),bodyYaw:clamp(tracking*.035,-.12,.12),headYaw:clamp(tracking*.075,-.22,.22)};
}
