import { FOOTBALL as F } from '../../core/config';
import { clamp, Random } from '../../core/types';
import type { RoutePhrase } from './patterns';
import type { WorldId } from './worlds';
export type ChunkKind = 'easyStraight' | 'easyCoin' | 'mediumWalls' | 'mediumDefender' | 'mediumBars' | 'mediumSlidingWalls' | 'mediumRollers' | 'mediumRotors' | 'mediumSlalom' | 'hardSlidingWalls' | 'hardNarrow' | 'hardHoles' | 'hardMix' | 'mediumCrossing' | 'hardCrossing' | 'bonusCoin' | 'boost';
export interface CourseObject {
  id: number; type: 'cone' | 'wall' | 'slider' | 'defender' | 'bar' | 'hole' | 'roller' | 'rotor' | 'pillar' | 'star' | 'boost';
  x: number; baseX: number; z: number; width: number; depth: number; height: number;
  moving: boolean; amplitude: number; frequency: number; phase: number; passed: boolean;
  rewardMultiplier?: number;
}
export interface ChallengeRow { z: number; safeX: number; gap: number }
export const CROSSING_STYLES = ['ballWall','doubleBall','slidingGates','defenderWall','rotorWall','postChicane'] as const;
export type CrossingStyle = typeof CROSSING_STYLES[number];
export function crossingStyle(chunk: Pick<Chunk,'kind'|'variant'|'id'>): CrossingStyle {
  const styles = chunk.kind === 'hardCrossing' ? CROSSING_STYLES : CROSSING_STYLES.filter(s=>s!=='doubleBall');
  return styles[Math.floor((chunk.variant??chunk.id)/2)%styles.length];
}
export interface Chunk {
  id: number; start: number; kind: ChunkKind; safeX: number; gap: number;
  rows: ChallengeRow[]; objects: CourseObject[];
  variant?: number;
  choice?: { x: number; gap: number; entryX: number; entryZ: number; worlds?: [WorldId, WorldId]; resolved?: boolean };
  recovery?: boolean;
  patternId?: string;
}
// Replan a real two-lane gate, rather than carving a bonus slit next to stars.
// Budget each intermediate row separately so both the normal path and the
// alternate path can be entered and merged at maximum BOOST speed.
export function planWorldChoice(rows: ChallengeRow[], entry: ChallengeRow, side: number) {
  if (rows.length < 4) return undefined;
  const fork = rows[1], exit = rows.at(-1)!;
  const capacity = (a: number, b: number) => Math.max(0, b - a - 2 * F.route.rowClearance) / (F.maxForwardSpeed * F.boostMultiplier) * F.steeringSensitivity * .85;
  const enter = capacity(entry.z, rows[0].z) + capacity(rows[0].z, fork.z);
  const tail = rows.slice(1), leave = tail.slice(1).reduce((sum, row, i) => sum + capacity(tail[i].z, row.z), 0);
  const gap = 1.62, separation = 1.65, edge = F.courseWidth / 2 - gap / 2 - F.ballRadius - .12;
  const lo = Math.max(-edge, entry.safeX - enter, exit.safeX - leave);
  const hi = Math.min(edge, entry.safeX + enter, exit.safeX + leave);
  if (hi - lo < separation) return undefined;
  const left = clamp(fork.safeX - separation / 2, lo, hi - separation), right = left + separation;
  const normal = Math.abs(left - entry.safeX) < Math.abs(right - entry.safeX) ? left : Math.abs(left - entry.safeX) === Math.abs(right - entry.safeX) && side < 0 ? left : right;
  const alternate = normal === left ? right : left;
  const exitX = exit.safeX;
  const firstCapacity = capacity(entry.z, rows[0].z);
  rows[0].safeX = entry.safeX + (normal - entry.safeX) * firstCapacity / enter;
  fork.safeX = normal; fork.gap = gap;
  let used = 0;
  for (let i = 2; i < rows.length; i++) {
    used += capacity(rows[i - 1].z, rows[i].z);
    rows[i].safeX = normal + (exitX - normal) * used / leave;
  }
  return { x: alternate, gap, entryX: entry.safeX, entryZ: entry.z + F.route.rowClearance };
}
// Optional branches always leave room to enter and merge at maximum BOOST.
// The ordinary route is retained; only the narrower route offers double stars.
export function planChoice(rows: readonly ChallengeRow[], entry: ChallengeRow, preferredSide = -1) {
  const fork = rows[1], exit = rows.at(-1)!;
  const travel = (a: number, b: number) => Math.max(0, b - a - 2 * F.route.rowClearance) / (F.maxForwardSpeed * F.boostMultiplier) * F.steeringSensitivity * .85;
  const options = [preferredSide, -preferredSide].map(side => fork.safeX + side * 1.85).filter(x =>
    Math.abs(x) + .575 + F.ballRadius + .12 < F.courseWidth / 2 &&
    Math.abs(x - entry.safeX) <= travel(entry.z, fork.z) && Math.abs(x - exit.safeX) <= travel(fork.z, exit.z));
  return options.length ? { x: options[0], gap: 1.15, entryX: entry.safeX, entryZ: entry.z + F.route.rowClearance } : undefined;
}
export function choiceRouteX(chunk: Chunk, z: number) {
  if (!chunk.choice) return routeX(chunk.rows, z);
  const fork = chunk.rows[1], exit = chunk.rows.at(-1)!;
  const { entryZ, entryX } = chunk.choice;
  if (z < fork.z - F.route.rowClearance) return entryX + (chunk.choice.x - entryX) * clamp((z - entryZ) / (fork.z - F.route.rowClearance - entryZ), 0, 1);
  if (z < fork.z + F.route.rowClearance) return chunk.choice.x;
  return chunk.choice.x + (exit.safeX - chunk.choice.x) * clamp((z - fork.z - F.route.rowClearance) / (exit.z - fork.z - 2 * F.route.rowClearance), 0, 1);
}
export const CHUNK_KINDS: ChunkKind[] = ['easyStraight', 'easyCoin', 'mediumWalls', 'mediumDefender', 'mediumBars', 'mediumSlidingWalls', 'mediumRollers', 'mediumRotors', 'mediumSlalom', 'hardSlidingWalls', 'hardNarrow', 'hardHoles', 'hardMix', 'bonusCoin', 'boost'];
export function chooseChunkKind(tier: 'easy' | 'medium' | 'hard', random: Random, recent: readonly ChunkKind[]): ChunkKind {
  const candidates: ChunkKind[] = tier === 'easy' ? ['easyStraight', 'easyCoin'] : tier === 'medium'
    ? ['mediumWalls', 'mediumDefender', 'mediumBars', 'mediumSlidingWalls', 'mediumRollers', 'mediumRotors', 'mediumSlalom']
    : ['hardSlidingWalls', 'hardNarrow', 'hardHoles', 'hardMix'];
  const fresh = candidates.filter(kind => !recent.slice(-2).includes(kind));
  return random.pick(fresh.length ? fresh : candidates.filter(kind => kind !== recent.at(-1)));
}
export function rotorAngle(o: CourseObject, time: number) { return time * o.frequency + o.phase; }
export function courseCollision(o: CourseObject, x: number, z: number, time: number): boolean {
  const dx = x - o.x, dz = z - o.z;
  if (o.type === 'roller' || o.type === 'pillar') return Math.hypot(dx, dz) < o.width / 2 + F.ballRadius * .78;
  if (o.type === 'rotor') {
    const angle = rotorAngle(o, time), c = Math.cos(angle), s = Math.sin(angle);
    const lx = dx * c + dz * s, lz = -dx * s + dz * c;
    const reach = o.width / 2 + F.ballRadius * .78, thickness = .08 * o.width / 1.4 + F.ballRadius * .78;
    return (Math.abs(lx) < reach && Math.abs(lz) < thickness) || (Math.abs(lz) < reach && Math.abs(lx) < thickness);
  }
  return Math.abs(dz) < o.depth / 2 + F.ballRadius * .7 && Math.abs(dx) < o.width / 2 + F.ballRadius * .78;
}
export function motionOffset(o: CourseObject, time: number) {
  const phase = time * o.frequency + o.phase;
  // A brisk crossing and a readable turn at either end, still bounded by the
  // generated sweep envelope so the planned star corridor stays open.
  if (o.type === 'roller') return o.amplitude * Math.tanh(1.45 * Math.sin(phase)) / Math.tanh(1.45);
  return o.amplitude * (o.type === 'defender' ? .78 * Math.sin(phase) + .22 * Math.sin(phase * 2.4 + 1.1) : Math.sin(phase));
}

// A bounded, varied slalom through 4–5 rows, including the previous seam.
// Every center change fits after both collision volumes clear at maximum BOOST.
export function planRows(start: number, kind: ChunkKind, gap: number, previous: ChallengeRow, random: Random, intro = false, phrase?: RoutePhrase, planningSpeed: number = F.maxForwardSpeed): ChallengeRow[] {
  if (kind === 'bonusCoin') return [{ z: start + 13, safeX: previous.safeX, gap: F.courseWidth }];
  if (kind === 'mediumCrossing' || kind === 'hardCrossing') {
    // Two readable obstacles rather than four cramped micro-turns. Plan against
    // a conservative arrival-speed forecast including BOOST, not today's speed.
    const direction = previous.safeX > .25 ? 1 : previous.safeX < -.25 ? -1 : phrase?.mirror ?? random.pick([-1,1]);
    // Centre the full crossing around the road centre even at late-game speed;
    // spending all travel on the first edge otherwise leaves both exits on one side.
    const halfCrossing=Math.min(2.5,(16-2*F.route.rowClearance)/(planningSpeed*F.boostMultiplier)*F.steeringSensitivity*.8/2);
    const rows: ChallengeRow[]=[];
    for (const [index,offset] of [7,23].entries()) {
      const z=start+offset;
      const reach=Math.max(0,z-previous.z-2*F.route.rowClearance)/(planningSpeed*F.boostMultiplier)*F.steeringSensitivity*.8;
      const target=direction*(index? -2.5:halfCrossing);
      const safeX=previous.safeX+clamp(target-previous.safeX,-reach,reach);
      const row={z,safeX,gap:kind==='hardCrossing'?2.05:2.35};rows.push(row);previous=row;
    }
    return rows;
  }
  const hard = kind.startsWith('hard');
  const offsets = hard ? F.challengeRows.hard : F.challengeRows.normal;
  const direction = phrase?.mirror ?? random.pick([-1, 1]);
  const turns = phrase?.turns ?? random.pick(hard
    ? [[1, 1, 0, -1, -1], [1, 1, 1, -1, 0], [-1, 1, 1, 1, -1], [0, -1, -1, 1, 1], [1, -1, -1, -1, 1]]
    : [[1, 1, -1, 0], [-1, 0, -1, 1], [1, 0, 1, 1], [-1, -1, -1, 1], [1, -1, 1, -1]]);
  const rows: ChallengeRow[] = [];
  for (let i = 0; i < offsets.length; i++) {
    const z = start + offsets[i] + (intro ? 0 : (random.next() - .5) * (hard ? .36 : .56));
    const freeDistance = Math.max(0, z - previous.z - F.route.maxObstacleDepth - F.ballRadius * 2);
    const steeringBudgetSpeed = (F.maxForwardSpeed + planningSpeed) / 2;
    const reachable = freeDistance / (steeringBudgetSpeed * F.boostMultiplier) * F.steeringSensitivity * F.route.transitionSafety;
    const step = Math.min(hard ? F.route.hardStep : F.route.normalStep, reachable);
    let turn = turns[(i + (phrase?.offset ?? 0)) % turns.length] * direction;
    if (Math.abs(previous.safeX + turn * step) > F.route.maxCenter) turn *= -1;
    const row = { z, safeX: intro ? 0 : clamp(previous.safeX + turn * step, -F.route.maxCenter, F.route.maxCenter), gap: intro ? gap : gap + (random.next() - .5) * .16 };
    rows.push(row); previous = row;
  }
  return rows;
}

export function routeX(rows: readonly ChallengeRow[], z: number): number {
  if (z <= rows[0].z) return rows[0].safeX;
  for (let i = 1; i < rows.length; i++) if (z <= rows[i].z) {
    const previous = rows[i - 1], next = rows[i];
    // Stay centred through each obstacle's full depth before starting the slalom.
    const blend = clamp((z - previous.z - F.route.rowClearance) / (next.z - previous.z - 2 * F.route.rowClearance), 0, 1);
    return previous.safeX + (next.safeX - previous.safeX) * blend;
  }
  return rows[rows.length - 1].safeX;
}
export function coursePickupClear(x: number, z: number, objects: readonly CourseObject[]) {
  return objects.every(o => ['star', 'boost'].includes(o.type) ||
    Math.abs(z - o.z) > o.depth / 2 + F.ballRadius + .35 ||
    Math.abs(x - o.baseX) > o.width / 2 + o.amplitude + F.ballRadius + .12);
}

export function fillChunk(chunk: Chunk, create: (type: CourseObject['type'], x: number, z: number, w: number, d: number, h: number) => CourseObject) {
  const { start, kind, rows } = chunk;
  const add = (type: CourseObject['type'], x: number, z: number, w: number, d: number, h: number) => {
    const o = create(type, x, z, w, d, h); chunk.objects.push(o); return o;
  };
  const routeTokens = (count: number) => {
    for (let i = 0; i < count; i++) {
      const z = start + 2 + i * 22 / (count - 1);
      const x = routeX(rows, z);
      if (coursePickupClear(x, z, chunk.objects)) add('star', x, z, .5, .5, .65);
    }
  };
  if (kind === 'bonusCoin') { routeTokens(22); return; }
  if (kind === 'boost') add('boost', rows[0].safeX, start + 2, 1.8, 1.8, .04);
  const edge = F.courseWidth / 2;
  if (kind === 'mediumCrossing' || kind === 'hardCrossing') {
    const style=crossingStyle(chunk);
    rows.forEach((row,index)=>{
      const activeRow=(index+(chunk.variant??chunk.id))%2===0;
      const ballRow=style==='doubleBall'||style==='ballWall'&&activeRow;
      if(style==='doubleBall')row.gap=1.55;
      if(ballRow){
        const side=row.safeX>=0?-1:1,radius=style==='doubleBall'?1.5:1.1;
        const boundary=row.safeX+side*(row.gap/2+.06),room=edge-side*boundary;
        const amplitude=Math.max(0,Math.min(1.55,(room-radius*2)/2-.04));
        const x=boundary+side*(radius+amplitude);
        const ball=add('roller',x,row.z,radius*2,radius*2,radius*2);ball.moving=true;ball.amplitude=amplitude;ball.frequency=style==='doubleBall'?3.1:2.3;ball.phase=style==='doubleBall'?index*Math.PI:row.z*.53;
        // Close the outer bypass behind the ball, leaving the advertised side
        // open. The player can still react to the actual ball position.
        const outer=x+side*(radius+amplitude);
        const width=Math.max(0,edge-Math.abs(outer));
        if(width>.08)add('wall',side*(edge-width/2),row.z,width,1.45,1.5);
      }else if(activeRow && (style==='defenderWall'||style==='rotorWall')){
        const side=row.safeX>=0?-1:1,defender=style==='defenderWall';
        const width=defender?1.6:2.6,boundary=row.safeX+side*(row.gap/2+.1),room=edge-side*boundary;
        const amplitude=defender?Math.max(0,Math.min(1.15,(room-width)/2-.05)):0;
        const x=boundary+side*(width/2+amplitude);
        const o=add(defender?'defender':'rotor',x,row.z,width,defender?1.1:width,defender?1.9:.7);
        o.moving=defender;o.amplitude=amplitude;o.frequency=defender?4.6:3.8;o.phase=row.z*.61;
        const outer=x+side*(width/2+amplitude);
        for(let d=Math.abs(outer)+.4;d<edge-.3;d+=.65)add('pillar',side*d,row.z,.66,.66,1.2);
      }else if(style==='postChicane'){
        const left=row.safeX-row.gap/2,right=row.safeX+row.gap/2;
        for(let x=-edge+.34;x<edge-.3;x+=.62)if(x+.33<=left||x-.33>=right)add('pillar',x,row.z,.66,.66,1.2);
      }else{
        const amplitude=style==='slidingGates'?.95:.6;
        const left=row.safeX-row.gap/2-amplitude,right=row.safeX+row.gap/2+amplitude;
        for(const [x,width]of [[(-edge+left)/2,left+edge],[(right+edge)/2,edge-right]])if(width>0){
          const wall=add('slider',x,row.z,width,1.45,1.5);wall.moving=true;wall.amplitude=amplitude;wall.frequency=style==='slidingGates'?2.9:2.1;wall.phase=style==='slidingGates'?index*Math.PI:row.z*.53;
        }
      }
    });
    routeTokens(13);return;
  }
  const cones = (row: ChallengeRow) => {
    for (const side of [-1, 1]) add('cone', clamp(row.safeX + side * (row.gap / 2 + .55), -edge + .45, edge - .45), row.z, .9, .9, 1.35);
  };
  const gates = (row: ChallengeRow, moving = false, hole = false) => {
    const hard = kind.startsWith('hard');
    // Both halves share a phase; the fixed corridor stays open at both extremes.
    const amplitude = moving ? hard ? .55 : .45 : 0;
    const left = row.safeX - row.gap / 2 - amplitude;
    const right = row.safeX + row.gap / 2 + amplitude;
    for (const [x, width] of [[(-edge + left) / 2, left + edge], [(right + edge) / 2, edge - right]]) {
      if (width <= 0) continue;
      const wall = add(hole ? 'hole' : moving ? 'slider' : 'wall', x, row.z, width, F.route.maxObstacleDepth, hole ? .02 : 1.5);
      wall.moving = moving; wall.amplitude = amplitude;
      wall.frequency = hard ? F.moving.hardWallFrequency : F.moving.wallFrequency;
      wall.phase = (row.z - start) * .43;
    }
  };
  const special = (row: ChallengeRow, type: 'roller' | 'rotor' | 'pillar') => {
    const width = type === 'roller' ? 1.1 : type === 'rotor' ? 1.4 : .66;
    for (const side of [-1, 1]) {
      const boundary = row.safeX + side * (row.gap / 2 + .06);
      const room = edge - side * boundary;
      if (room <= 0) continue;
      if (room < width + .12) {
        add('wall', (side * edge + boundary) / 2, row.z, room, F.route.maxObstacleDepth, 1.25); continue;
      }
      const amplitude = type === 'roller' ? Math.min(1.55, (room - width) / 2 - .04) : 0;
      const x = boundary + side * (width / 2 + amplitude);
      const o = add(type, x, row.z, width, width, type === 'roller' ? 1.1 : type === 'rotor' ? .7 : 1.2);
      o.moving = type === 'roller'; o.amplitude = amplitude;
      o.frequency = type === 'roller' ? 2.8 + (row.z % 1.2) : 2.8;
      o.phase = row.z * .71 + (chunk.variant ?? 0) * .17;
      if (type === 'pillar') {
        const far = side * (edge - .4);
        if (Math.abs(far - x) > .9) add('pillar', far, row.z, .66, .66, 1.2);
      }
    }
  };
  rows.forEach((row, index) => {
    if (chunk.choice) {
      if (index !== 1) {
        const centers = [-1.5, 0, 1.5].flatMap(dz => [routeX(rows, row.z + dz), choiceRouteX(chunk, row.z + dz)]);
        const left = Math.max(-edge, Math.min(...centers) - row.gap / 2);
        const right = Math.min(edge, Math.max(...centers) + row.gap / 2);
        if (left > -edge) add('wall', (-edge + left) / 2, row.z, left + edge, F.route.maxObstacleDepth, 1.5);
        if (right < edge) add('wall', (right + edge) / 2, row.z, edge - right, F.route.maxObstacleDepth, 1.5);
      } else {
        const gaps = [{ x: row.safeX, gap: row.gap }, chunk.choice].sort((a, b) => a.x - b.x);
        let left = -edge;
        for (const route of gaps) {
          const end = route.x - route.gap / 2;
          if (end > left) add('wall', (left + end) / 2, row.z, end - left, F.route.maxObstacleDepth, 1.5);
          left = route.x + route.gap / 2;
        }
        if (left < edge) add('wall', (left + edge) / 2, row.z, edge - left, F.route.maxObstacleDepth, 1.5);
      }
      return;
    }
    if (kind === 'mediumRollers') { special(row, 'roller'); return; }
    if (kind === 'mediumRotors') { special(row, 'rotor'); return; }
    if (kind === 'mediumSlalom') { special(row, 'pillar'); return; }
    if (kind === 'hardMix') {
      const family = ((chunk.variant ?? chunk.id) + index * 3) % 5;
      if (family < 3) special(row, (['roller', 'rotor', 'pillar'] as const)[family]);
      else gates(row, family === 3, family === 4);
      return;
    }
    if (kind === 'easyStraight' || kind === 'easyCoin' || kind === 'boost') { cones(row); return; }
    if ((kind === 'mediumDefender' || kind === 'mediumBars') && index === 0) {
      const side = row.safeX >= 0 ? -1 : 1;
      const defender = kind === 'mediumDefender', width = defender ? 1.6 : 2.5;
      const amplitude = defender ? .85 : .45;
      const x = row.safeX + side * (row.gap / 2 + width / 2 + amplitude);
      const o = add(defender ? 'defender' : 'bar', x, row.z, width, 1.1, 1.9);
      o.moving = true; o.amplitude = amplitude; o.frequency = defender ? F.moving.defenderFrequency : F.moving.barFrequency;
      add('cone', clamp(row.safeX - side * (row.gap / 2 + .55), -edge + .45, edge - .45), row.z, .9, .9, 1.35);
      return;
    }
    if ((kind === 'mediumDefender' || kind === 'mediumBars') && index === 1) { cones(row); return; }
    gates(row, kind === 'mediumSlidingWalls' || kind === 'hardSlidingWalls', kind === 'hardHoles');
  });
  if (chunk.choice?.worlds) return; // Destinations, not a trail of stars, guide these choices.
  routeTokens(9);
  if (chunk.choice) for (const dz of [-.7, 0, .7]) {
    const z = rows[1].z + dz;
    if (coursePickupClear(chunk.choice.x, z, chunk.objects)) add('star', chunk.choice.x, z, .5, .5, .65).rewardMultiplier = 2;
  }
}
