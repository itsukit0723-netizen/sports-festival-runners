import { FOOTBALL as F } from '../../core/config';
import { clamp, Random } from '../../core/types';
import type { RoutePhrase } from './patterns';
import type { WorldId } from './worlds';
export type ChunkKind = 'easyStraight' | 'easyCoin' | 'mediumWalls' | 'mediumDefender' | 'mediumBars' | 'mediumSlidingWalls' | 'mediumRollers' | 'mediumRotors' | 'mediumSlalom' | 'hardSlidingWalls' | 'hardNarrow' | 'hardHoles' | 'hardMix' | 'mediumCrossing' | 'hardCrossing' | 'hardScramble' | 'bonusCoin' | 'boost';
export interface CourseObject {
  id: number; type: 'cone' | 'wall' | 'slider' | 'defender' | 'bar' | 'hole' | 'roller' | 'rotor' | 'pillar' | 'star' | 'boost';
  x: number; baseX: number; z: number; width: number; depth: number; height: number;
  moving: boolean; amplitude: number; frequency: number; phase: number; passed: boolean;
  rewardMultiplier?: number;
  velocityX?: number;
  chaotic?: boolean; baseZ?:number; depthAmplitude?:number;
}
export interface ChallengeRow { z: number; safeX: number; gap: number; clearance?:number }
export const challengeClearance=(row:ChallengeRow)=>row.clearance??F.route.rowClearance;
export const courseChunkLength=(chunk:Chunk)=>chunk.length??F.chunkLength;
export const CROSSING_STYLES = ['ballWall','doubleBall','slidingGates','defenderWall','rotorWall','postChicane'] as const;
export type CrossingStyle = typeof CROSSING_STYLES[number];
export function crossingStyle(chunk: Pick<Chunk,'kind'|'variant'|'id'>): CrossingStyle {
  const styles = chunk.kind === 'hardCrossing' ? CROSSING_STYLES : CROSSING_STYLES.filter(s=>s!=='doubleBall');
  return styles[Math.floor((chunk.variant??chunk.id)/2)%styles.length];
}
export interface Chunk {
  id: number; start: number; kind: ChunkKind; safeX: number; gap: number;
  rows: ChallengeRow[]; objects: CourseObject[];
  variant?: number;
  choice?: { x: number; gap: number; entryX: number; entryZ: number; worlds?: [WorldId, WorldId]; resolved?: boolean };
  recovery?: boolean;
  patternId?: string;
  length?:number;
  scrambleChoice?: { x: number };
  crossingTempo?: 'quick' | 'hold' | 'late';
}
export function scrambleChoiceX(chunk: Chunk, z: number) {
  const [entry, fork, exit] = chunk.rows;
  const x = chunk.scrambleChoice?.x ?? fork.safeX;
  if (z <= fork.z) return entry.safeX + (x - entry.safeX) * clamp((z-entry.z-challengeClearance(entry))/(fork.z-entry.z-2*F.route.rowClearance),0,1);
  return x + (exit.safeX-x)*clamp((z-fork.z-F.route.rowClearance)/(exit.z-fork.z-2*F.route.rowClearance),0,1);
}
// Replan a real two-lane gate, rather than carving a bonus slit next to stars.
// Budget each intermediate row separately so both the normal path and the
// alternate path can be entered and merged at maximum BOOST speed.
export function planWorldChoice(rows: ChallengeRow[], entry: ChallengeRow, side: number) {
  if (rows.length < 4) return undefined;
  const fork = rows[1], exit = rows.at(-1)!;
  const capacity = (a: number, b: number) => Math.max(0, b - a - 2 * F.route.rowClearance) / (F.maxForwardSpeed * F.boostMultiplier) * F.steeringSensitivity * .85;
  const enter = capacity(entry.z, rows[0].z) + capacity(rows[0].z, fork.z);
  const tail = rows.slice(1), leave = tail.slice(1).reduce((sum, row, i) => sum + capacity(tail[i].z, row.z), 0);
  const gap = 1.62, separation = 1.65, edge = F.courseWidth / 2 - gap / 2 - F.ballRadius - .12;
  const lo = Math.max(-edge, entry.safeX - enter, exit.safeX - leave);
  const hi = Math.min(edge, entry.safeX + enter, exit.safeX + leave);
  if (hi - lo < separation) return undefined;
  const left = clamp(fork.safeX - separation / 2, lo, hi - separation), right = left + separation;
  const normal = Math.abs(left - entry.safeX) < Math.abs(right - entry.safeX) ? left : Math.abs(left - entry.safeX) === Math.abs(right - entry.safeX) && side < 0 ? left : right;
  const alternate = normal === left ? right : left;
  const exitX = exit.safeX;
  const firstCapacity = capacity(entry.z, rows[0].z);
  rows[0].safeX = entry.safeX + (normal - entry.safeX) * firstCapacity / enter;
  fork.safeX = normal; fork.gap = gap;
  let used = 0;
  for (let i = 2; i < rows.length; i++) {
    used += capacity(rows[i - 1].z, rows[i].z);
    rows[i].safeX = normal + (exitX - normal) * used / leave;
  }
  return { x: alternate, gap, entryX: entry.safeX, entryZ: entry.z + F.route.rowClearance };
}
// Optional branches always leave room to enter and merge at maximum BOOST.
// The ordinary route is retained; only the narrower route offers double stars.
export function planChoice(rows: readonly ChallengeRow[], entry: ChallengeRow, preferredSide = -1) {
  const fork = rows[1], exit = rows.at(-1)!;
  const travel = (a: number, b: number) => Math.max(0, b - a - 2 * F.route.rowClearance) / (F.maxForwardSpeed * F.boostMultiplier) * F.steeringSensitivity * .85;
  const options = [preferredSide, -preferredSide].map(side => fork.safeX + side * 1.85).filter(x =>
    Math.abs(x) + .575 + F.ballRadius + .12 < F.courseWidth / 2 &&
    Math.abs(x - entry.safeX) <= travel(entry.z, fork.z) && Math.abs(x - exit.safeX) <= travel(fork.z, exit.z));
  return options.length ? { x: options[0], gap: 1.15, entryX: entry.safeX, entryZ: entry.z + F.route.rowClearance } : undefined;
}
export function choiceRouteX(chunk: Chunk, z: number) {
  if (!chunk.choice) return routeX(chunk.rows, z);
  const fork = chunk.rows[1], exit = chunk.rows.at(-1)!;
  const { entryZ, entryX } = chunk.choice;
  if (z < fork.z - F.route.rowClearance) return entryX + (chunk.choice.x - entryX) * clamp((z - entryZ) / (fork.z - F.route.rowClearance - entryZ), 0, 1);
  if (z < fork.z + F.route.rowClearance) return chunk.choice.x;
  return chunk.choice.x + (exit.safeX - chunk.choice.x) * clamp((z - fork.z - F.route.rowClearance) / (exit.z - fork.z - 2 * F.route.rowClearance), 0, 1);
}
export const CHUNK_KINDS: ChunkKind[] = ['easyStraight', 'easyCoin', 'mediumWalls', 'mediumDefender', 'mediumBars', 'mediumSlidingWalls', 'mediumRollers', 'mediumRotors', 'mediumSlalom', 'hardSlidingWalls', 'hardNarrow', 'hardHoles', 'hardMix', 'bonusCoin', 'boost'];
export function chooseChunkKind(tier: 'easy' | 'medium' | 'hard', random: Random, recent: readonly ChunkKind[]): ChunkKind {
  const candidates: ChunkKind[] = tier === 'easy' ? ['easyStraight', 'easyCoin'] : tier === 'medium'
    ? ['mediumWalls', 'mediumDefender', 'mediumBars', 'mediumSlidingWalls', 'mediumRollers', 'mediumRotors', 'mediumSlalom']
    : ['hardSlidingWalls', 'hardNarrow', 'hardHoles', 'hardMix'];
  const fresh = candidates.filter(kind => !recent.slice(-2).includes(kind));
  return random.pick(fresh.length ? fresh : candidates.filter(kind => kind !== recent.at(-1)));
}
export function rotorAngle(o: CourseObject, time: number) { return time * o.frequency + o.phase; }
export function courseCollision(o: CourseObject, x: number, z: number, time: number): boolean {
  const dx = x - o.x, dz = z - o.z;
  if (o.type === 'roller' || o.type === 'pillar') return Math.hypot(dx, dz) < o.width / 2 + F.ballRadius * .78;
  if (o.type === 'rotor') {
    const angle = rotorAngle(o, time), c = Math.cos(angle), s = Math.sin(angle);
    const lx = dx * c + dz * s, lz = -dx * s + dz * c;
    const reach = o.width / 2 + F.ballRadius * .78, thickness = .08 * o.width / 1.4 + F.ballRadius * .78;
    return (Math.abs(lx) < reach && Math.abs(lz) < thickness) || (Math.abs(lz) < reach && Math.abs(lx) < thickness);
  }
  return Math.abs(dz) < o.depth / 2 + F.ballRadius * .7 && Math.abs(dx) < o.width / 2 + F.ballRadius * .78;
}
export function motionOffset(o: CourseObject, time: number, playerX?: number) {
  const phase = time * o.frequency + o.phase;
  // A brisk crossing and a readable turn at either end, still bounded by the
  // generated sweep envelope so the planned star corridor stays open.
  if (o.type === 'roller') return o.amplitude * (o.chaotic ? .57*Math.sin(phase)+.28*Math.sin(phase*1.73+o.phase*.4)+.15*Math.sin(phase*.61+2.1) : Math.tanh(1.45 * Math.sin(phase)) / Math.tanh(1.45));
  if(o.type==='defender'){
    const intent=playerX===undefined?0:clamp((playerX-o.baseX)/Math.max(.001,o.amplitude),-1,1);
    return o.amplitude*(.78*intent+.22*Math.sin(time*Math.min(o.frequency,2.25)+o.phase));
  }
  return o.amplitude * Math.sin(phase);
}
export function motionDepthOffset(o:CourseObject,time:number){return (o.depthAmplitude??0)*(.65*Math.sin(time*o.frequency*.83+o.phase*1.7)+.35*Math.sin(time*o.frequency*1.41+2.4));}

// A bounded, varied slalom through 4–5 rows, including the previous seam.
// Every center change fits after both collision volumes clear at maximum BOOST.
export function planRows(start: number, kind: ChunkKind, gap: number, previous: ChallengeRow, random: Random, intro = false, phrase?: RoutePhrase, planningSpeed: number = F.maxForwardSpeed, tempo: Chunk['crossingTempo'] = 'quick'): ChallengeRow[] {
  if (kind === 'bonusCoin') return [{ z: start + 13, safeX: previous.safeX, gap: F.courseWidth }];
  if (kind === 'mediumCrossing' || kind === 'hardCrossing') {
    // Two readable obstacles rather than four cramped micro-turns. Plan against
    // a conservative arrival-speed forecast including BOOST, not today's speed.
    const direction = previous.safeX > .25 ? 1 : previous.safeX < -.25 ? -1 : phrase?.mirror ?? random.pick([-1,1]);
    const rows: ChallengeRow[]=[];
    for (let index=0;index<2;index++) {
      // Leave a reaction margin after the trailing barrier before the opposite
      // edge is demanded. Holding adds timing variety, not a tighter turn.
      const safeX=direction*(index?-3.45:3.45),clearance=index===0 && tempo==='hold'?5.4+planningSpeed*F.boostMultiplier*.2:3.15;
      const travel=Math.abs(safeX-previous.safeX)/F.steeringSensitivity*planningSpeed*F.boostMultiplier/.76;
      const z=Math.max(start+9,previous.z+challengeClearance(previous)+clearance+travel+.35);
      const row={z,safeX,gap:1.05,clearance};rows.push(row);previous=row;
    }
    return rows;
  }
  const hard = kind.startsWith('hard');
  const offsets = kind==='hardScramble'?[4,17,30]:hard ? F.challengeRows.hard : F.challengeRows.normal;
  const direction = phrase?.mirror ?? random.pick([-1, 1]);
  const turns = phrase?.turns ?? random.pick(hard
    ? [[1, 1, 0, -1, -1], [1, 1, 1, -1, 0], [-1, 1, 1, 1, -1], [0, -1, -1, 1, 1], [1, -1, -1, -1, 1]]
    : [[1, 1, -1, 0], [-1, 0, -1, 1], [1, 0, 1, 1], [-1, -1, -1, 1], [1, -1, 1, -1]]);
  const rows: ChallengeRow[] = [];
  for (let i = 0; i < offsets.length; i++) {
    const z = start + offsets[i] + (intro ? 0 : (random.next() - .5) * (hard ? .36 : .56));
    const freeDistance = Math.max(0, z - previous.z - Math.max(F.route.maxObstacleDepth+F.ballRadius*2,challengeClearance(previous)+F.route.rowClearance));
    const steeringBudgetSpeed = kind==='hardScramble'?planningSpeed:(F.maxForwardSpeed + planningSpeed) / 2;
    const reachable = freeDistance / (steeringBudgetSpeed * F.boostMultiplier) * F.steeringSensitivity * F.route.transitionSafety;
    const step = Math.min(kind==='hardScramble'?1.8:hard ? F.route.hardStep : F.route.normalStep, reachable);
    let turn = turns[(i + (phrase?.offset ?? 0)) % turns.length] * direction;
    const limit=Math.max(F.route.maxCenter,Math.abs(previous.safeX));
    if(Math.abs(previous.safeX)>F.route.maxCenter)turn=-Math.sign(previous.safeX);
    if (Math.abs(previous.safeX + turn * step) > limit) turn *= -1;
    const row = { z, safeX: intro ? 0 : kind==='hardScramble' && i>0 ? rows[0].safeX : clamp(previous.safeX + turn * step, -limit, limit), gap: kind==='hardScramble'?1.7:intro ? gap : gap + (random.next() - .5) * .16 };
    rows.push(row); previous = row;
  }
  return rows;
}

export function routeX(rows: readonly ChallengeRow[], z: number): number {
  if (z <= rows[0].z) return rows[0].safeX;
  for (let i = 1; i < rows.length; i++) if (z <= rows[i].z) {
    const previous = rows[i - 1], next = rows[i];
    // Stay centred through each obstacle's full depth before starting the slalom.
    const blend = clamp((z - previous.z - challengeClearance(previous)) / (next.z - previous.z - challengeClearance(previous)-challengeClearance(next)), 0, 1);
    return previous.safeX + (next.safeX - previous.safeX) * blend;
  }
  return rows[rows.length - 1].safeX;
}
export function coursePickupClear(x: number, z: number, objects: readonly CourseObject[]) {
  return objects.every(o => ['star', 'boost'].includes(o.type) ||
    Math.abs(z - (o.baseZ??o.z)) > o.depth / 2 + (o.depthAmplitude??0) + F.ballRadius + .35 ||
    Math.abs(x - o.baseX) > o.width / 2 + o.amplitude + F.ballRadius + .12);
}

export function fillChunk(chunk: Chunk, create: (type: CourseObject['type'], x: number, z: number, w: number, d: number, h: number) => CourseObject) {
  const { start, kind, rows } = chunk;
  const add = (type: CourseObject['type'], x: number, z: number, w: number, d: number, h: number) => {
    const o = create(type, x, z, w, d, h); chunk.objects.push(o); return o;
  };
  const routeTokens = (count: number) => {
    for (let i = 0; i < count; i++) {
      const z = start + 2 + i * (courseChunkLength(chunk)-4) / (count - 1);
      const x = routeX(rows, z);
      if (coursePickupClear(x, z, chunk.objects)) add('star', x, z, .5, .5, .65);
    }
  };
  if (kind === 'bonusCoin') { routeTokens(22); return; }
  if (kind === 'boost') add('boost', rows[0].safeX, start + 2, 1.8, 1.8, .04);
  const edge = F.courseWidth / 2;
  if(kind==='hardScramble'){
    // A genuine unmarked choice around a moving central ball, rather than a
    // single star trail. Both bypasses merge before the next section.
    const middle=rows[1],side=middle.safeX>0?-1:1;
    chunk.scrambleChoice={x:middle.safeX+side*1.7};
    rows.forEach((row,index)=>{
      const sweep=.65+.48+.5+F.ballRadius+.1;
      const centers=[-sweep,0,sweep].flatMap(dz=>[routeX(rows,row.z+dz),scrambleChoiceX(chunk,row.z+dz)]);
      for(const side of [-1,1]){
        const boundary=side<0?Math.min(...centers)-row.gap/2-.1:Math.max(...centers)+row.gap/2+.1;
        const room=edge-side*boundary;
        for(let j=0;j<3;j++){
          const width=.72+((index*3+j+(chunk.variant??0))%4)*.07;
          if(room<width+.12)continue;
          const amplitude=Math.min(1.7,Math.max(0,(room-width)/2-.05));
          const x=boundary+side*(width/2+amplitude);
          const ball=add('roller',x,row.z+(j-1)*.48,width,width,width);
          ball.baseZ=ball.z;ball.moving=true;ball.amplitude=amplitude;ball.chaotic=true;ball.depthAmplitude=.65;
          ball.frequency=1.7+((index*7+j*3+(side>0?2:0))%9)*.27;ball.phase=index*1.97+j*2.41+side*.81;
        }
      }
    });
    const splitter=add('roller',(middle.safeX+chunk.scrambleChoice.x)/2,middle.z,.65,.65,.65);
    splitter.moving=true;splitter.amplitude=.12;splitter.frequency=2.2;splitter.phase=(chunk.variant??0)*.7;
    return;
  }
  if (kind === 'mediumCrossing' || kind === 'hardCrossing') {
    const style=crossingStyle(chunk);
    rows.forEach((row,index)=>{
      const activeRow=(index+(chunk.variant??chunk.id))%2===0;
      const ballRow=style==='doubleBall'||style==='ballWall'&&activeRow;
      // A low cut-off rail closes the central shortcut before the main hazard.
      // This forces every style to use the edge exit, rather than just following
      // an optional star curve while staying near the middle.
      const side=row.safeX>=0?-1:1,boundary=row.safeX+side*row.gap/2;
      const railWidth=edge-side*boundary;
      const tempo=chunk.crossingTempo??'quick';
      add('wall',side*(edge-railWidth/2),row.z-(tempo==='late'?.55:2.4),railWidth,.5,.55);
      // Hold the first edge through a second physical barrier. A late-entry
      // version moves its leading barrier closer to the main obstacle.
      if(index===0 && tempo==='hold')add('wall',side*(edge-railWidth/2),row.z+4.8,railWidth,.5,.55);
      if(ballRow){
        const side=row.safeX>=0?-1:1,radius=style==='doubleBall'?1.5:1.1;
        const boundary=row.safeX+side*(row.gap/2+.06),room=edge-side*boundary;
        const amplitude=Math.max(0,Math.min(1.55,(room-radius*2)/2-.04));
        const x=boundary+side*(radius+amplitude);
        const ball=add('roller',x,row.z,radius*2,radius*2,radius*2);ball.moving=true;ball.amplitude=amplitude;ball.frequency=style==='doubleBall'?3.1:2.3;ball.phase=style==='doubleBall'?index*Math.PI:row.z*.53;
        // Close the outer bypass behind the ball, leaving the advertised side
        // open. The player can still react to the actual ball position.
        const outer=x+side*(radius+amplitude);
        const width=Math.max(0,edge-Math.abs(outer));
        if(width>.08)add('wall',side*(edge-width/2),row.z,width,1.45,1.5);
      }else if(activeRow && (style==='defenderWall'||style==='rotorWall')){
        const side=row.safeX>=0?-1:1,defender=style==='defenderWall';
        const width=defender?1.6:2.6,boundary=row.safeX+side*(row.gap/2+.1),room=edge-side*boundary;
        const amplitude=defender?Math.max(0,Math.min(1.15,(room-width)/2-.05)):0;
        const x=boundary+side*(width/2+amplitude);
        const o=add(defender?'defender':'rotor',x,row.z,width,defender?1.1:width,defender?1.9:.7);
        o.moving=defender;o.amplitude=amplitude;o.frequency=defender?4.6:3.8;o.phase=row.z*.61;
        const outer=x+side*(width/2+amplitude);
        for(let d=Math.abs(outer)+.4;d<edge-.3;d+=.65)add('pillar',side*d,row.z,.66,.66,1.2);
      }else if(style==='postChicane'){
        const left=row.safeX-row.gap/2,right=row.safeX+row.gap/2;
        for(let x=-edge+.34;x<edge-.3;x+=.62)if(x+.33<=left||x-.33>=right)add('pillar',x,row.z,.66,.66,1.2);
      }else{
        const amplitude=style==='slidingGates'?.95:.6;
        const left=row.safeX-row.gap/2-amplitude,right=row.safeX+row.gap/2+amplitude;
        for(const [x,width]of [[(-edge+left)/2,left+edge],[(right+edge)/2,edge-right]])if(width>0){
          const wall=add('slider',x,row.z,width,1.45,1.5);wall.moving=true;wall.amplitude=amplitude;wall.frequency=style==='slidingGates'?2.9:2.1;wall.phase=style==='slidingGates'?index*Math.PI:row.z*.53;
        }
      }
    });
    routeTokens(13);return;
  }
  const cones = (row: ChallengeRow) => {
    for (const side of [-1, 1]) {
      const x=row.safeX+side*(row.gap/2+.55);
      if(Math.abs(x)+.45<=edge)add('cone',x,row.z,.9,.9,1.35);
    }
  };
  const gates = (row: ChallengeRow, moving = false, hole = false) => {
    const hard = kind.startsWith('hard');
    // Both halves share a phase; the fixed corridor stays open at both extremes.
    const amplitude = moving ? hard ? .55 : .45 : 0;
    const left = row.safeX - row.gap / 2 - amplitude;
    const right = row.safeX + row.gap / 2 + amplitude;
    for (const [x, width] of [[(-edge + left) / 2, left + edge], [(right + edge) / 2, edge - right]]) {
      if (width <= 0) continue;
      const wall = add(hole ? 'hole' : moving ? 'slider' : 'wall', x, row.z, width, F.route.maxObstacleDepth, hole ? .02 : 1.5);
      wall.moving = moving; wall.amplitude = amplitude;
      wall.frequency = hard ? F.moving.hardWallFrequency : F.moving.wallFrequency;
      wall.phase = (row.z - start) * .43;
    }
  };
  const special = (row: ChallengeRow, type: 'roller' | 'rotor' | 'pillar') => {
    const width = type === 'roller' ? 1.1 : type === 'rotor' ? 1.4 : .66;
    for (const side of [-1, 1]) {
      const boundary = row.safeX + side * (row.gap / 2 + .06);
      const room = edge - side * boundary;
      if (room <= 0) continue;
      if (room < width + .12) {
        add('wall', (side * edge + boundary) / 2, row.z, room, F.route.maxObstacleDepth, 1.25); continue;
      }
      const amplitude = type === 'roller' ? Math.min(1.55, (room - width) / 2 - .04) : 0;
      const x = boundary + side * (width / 2 + amplitude);
      const o = add(type, x, row.z, width, width, type === 'roller' ? 1.1 : type === 'rotor' ? .7 : 1.2);
      o.moving = type === 'roller'; o.amplitude = amplitude;
      o.frequency = type === 'roller' ? 2.8 + (row.z % 1.2) : 2.8;
      o.phase = row.z * .71 + (chunk.variant ?? 0) * .17;
      if (type === 'pillar') {
        const far = side * (edge - .4);
        if (Math.abs(far - x) > .9) add('pillar', far, row.z, .66, .66, 1.2);
      }
    }
  };
  rows.forEach((row, index) => {
    if (chunk.choice) {
      if (index !== 1) {
        const centers = [-1.5, 0, 1.5].flatMap(dz => [routeX(rows, row.z + dz), choiceRouteX(chunk, row.z + dz)]);
        const left = Math.max(-edge, Math.min(...centers) - row.gap / 2);
        const right = Math.min(edge, Math.max(...centers) + row.gap / 2);
        if (left > -edge) add('wall', (-edge + left) / 2, row.z, left + edge, F.route.maxObstacleDepth, 1.5);
        if (right < edge) add('wall', (right + edge) / 2, row.z, edge - right, F.route.maxObstacleDepth, 1.5);
      } else {
        const gaps = [{ x: row.safeX, gap: row.gap }, chunk.choice].sort((a, b) => a.x - b.x);
        let left = -edge;
        for (const route of gaps) {
          const end = route.x - route.gap / 2;
          if (end > left) add('wall', (left + end) / 2, row.z, end - left, F.route.maxObstacleDepth, 1.5);
          left = route.x + route.gap / 2;
        }
        if (left < edge) add('wall', (left + edge) / 2, row.z, edge - left, F.route.maxObstacleDepth, 1.5);
      }
      return;
    }
    if (kind === 'mediumRollers') { special(row, 'roller'); return; }
    if (kind === 'mediumRotors') { special(row, 'rotor'); return; }
    if (kind === 'mediumSlalom') { special(row, 'pillar'); return; }
    if (kind === 'hardMix') {
      const family = ((chunk.variant ?? chunk.id) + index * 3) % 5;
      if (family < 3) special(row, (['roller', 'rotor', 'pillar'] as const)[family]);
      else gates(row, family === 3, family === 4);
      return;
    }
    if (kind === 'easyStraight' || kind === 'easyCoin' || kind === 'boost') { cones(row); return; }
    if ((kind === 'mediumDefender' || kind === 'mediumBars') && index === 0) {
      const side = row.safeX >= 0 ? -1 : 1;
      const defender = kind === 'mediumDefender', width = defender ? 1.6 : 2.5;
      const amplitude = defender ? .85 : .45;
      const x = row.safeX + side * (row.gap / 2 + width / 2 + amplitude);
      const o = add(defender ? 'defender' : 'bar', x, row.z, width, 1.1, 1.9);
      o.moving = true; o.amplitude = amplitude; o.frequency = defender ? F.moving.defenderFrequency : F.moving.barFrequency;
      add('cone', clamp(row.safeX - side * (row.gap / 2 + .55), -edge + .45, edge - .45), row.z, .9, .9, 1.35);
      return;
    }
    if ((kind === 'mediumDefender' || kind === 'mediumBars') && index === 1) { cones(row); return; }
    gates(row, kind === 'mediumSlidingWalls' || kind === 'hardSlidingWalls', kind === 'hardHoles');
  });
  if (chunk.choice?.worlds) return; // Destinations, not a trail of stars, guide these choices.
  routeTokens(9);
  if (chunk.choice) for (const dz of [-.7, 0, .7]) {
    const z = rows[1].z + dz;
    if (coursePickupClear(chunk.choice.x, z, chunk.objects)) add('star', chunk.choice.x, z, .5, .5, .65).rewardMultiplier = 2;
  }
}
