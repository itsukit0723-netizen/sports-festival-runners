import { FOOTBALL as F } from '../../core/config';
import { clamp, Random } from '../../core/types';
export type ChunkKind = 'easyStraight' | 'easyCoin' | 'mediumWalls' | 'mediumDefender' | 'mediumBars' | 'mediumSlidingWalls' | 'mediumRollers' | 'mediumRotors' | 'mediumSlalom' | 'hardSlidingWalls' | 'hardNarrow' | 'hardHoles' | 'hardMix' | 'bonusCoin' | 'boost';
export interface CourseObject {
  id: number; type: 'cone' | 'wall' | 'slider' | 'defender' | 'bar' | 'hole' | 'roller' | 'rotor' | 'pillar' | 'star' | 'boost';
  x: number; baseX: number; z: number; width: number; depth: number; height: number;
  moving: boolean; amplitude: number; frequency: number; phase: number; passed: boolean;
}
export interface ChallengeRow { z: number; safeX: number; gap: number }
export interface Chunk {
  id: number; start: number; kind: ChunkKind; safeX: number; gap: number;
  rows: ChallengeRow[]; objects: CourseObject[];
  variant?: number;
}
export const CHUNK_KINDS: ChunkKind[] = ['easyStraight', 'easyCoin', 'mediumWalls', 'mediumDefender', 'mediumBars', 'mediumSlidingWalls', 'mediumRollers', 'mediumRotors', 'mediumSlalom', 'hardSlidingWalls', 'hardNarrow', 'hardHoles', 'hardMix', 'bonusCoin', 'boost'];
export function chooseChunkKind(tier: 'easy' | 'medium' | 'hard', random: Random, recent: readonly ChunkKind[]): ChunkKind {
  const candidates: ChunkKind[] = tier === 'easy' ? ['easyStraight', 'easyCoin'] : tier === 'medium'
    ? ['mediumWalls', 'mediumDefender', 'mediumBars', 'mediumSlidingWalls', 'mediumRollers', 'mediumRotors', 'mediumSlalom']
    : ['hardSlidingWalls', 'hardNarrow', 'hardHoles', 'hardMix'];
  const fresh = candidates.filter(kind => !recent.slice(-2).includes(kind));
  return random.pick(fresh.length ? fresh : candidates.filter(kind => kind !== recent.at(-1)));
}
export function rotorAngle(o: CourseObject, time: number) { return time * o.frequency + o.phase; }
export function courseCollision(o: CourseObject, x: number, z: number, time: number): boolean {
  const dx = x - o.x, dz = z - o.z;
  if (o.type === 'roller' || o.type === 'pillar') return Math.hypot(dx, dz) < o.width / 2 + F.ballRadius * .78;
  if (o.type === 'rotor') {
    const angle = rotorAngle(o, time), c = Math.cos(angle), s = Math.sin(angle);
    const lx = dx * c + dz * s, lz = -dx * s + dz * c;
    const reach = o.width / 2 + F.ballRadius * .78, thickness = .08 + F.ballRadius * .78;
    return (Math.abs(lx) < reach && Math.abs(lz) < thickness) || (Math.abs(lz) < reach && Math.abs(lx) < thickness);
  }
  return Math.abs(dz) < o.depth / 2 + F.ballRadius * .7 && Math.abs(dx) < o.width / 2 + F.ballRadius * .78;
}
export function motionOffset(o: CourseObject, time: number) {
  const phase = time * o.frequency + o.phase;
  return o.amplitude * (o.type === 'defender' ? .78 * Math.sin(phase) + .22 * Math.sin(phase * 2.4 + 1.1) : Math.sin(phase));
}

// A bounded, varied slalom through 4–5 rows, including the previous seam.
// Every center change fits after both collision volumes clear at maximum BOOST.
export function planRows(start: number, kind: ChunkKind, gap: number, previous: ChallengeRow, random: Random, intro = false): ChallengeRow[] {
  if (kind === 'bonusCoin') return [{ z: start + 13, safeX: previous.safeX, gap: F.courseWidth }];
  const hard = kind.startsWith('hard');
  const offsets = hard ? F.challengeRows.hard : F.challengeRows.normal;
  const direction = random.pick([-1, 1]);
  const turns = random.pick(hard
    ? [[1, 1, 0, -1, -1], [1, 1, 1, -1, 0], [-1, 1, 1, 1, -1], [0, -1, -1, 1, 1], [1, -1, -1, -1, 1]]
    : [[1, 1, -1, 0], [-1, 0, -1, 1], [1, 0, 1, 1], [-1, -1, -1, 1], [1, -1, 1, -1]]);
  const rows: ChallengeRow[] = [];
  for (let i = 0; i < offsets.length; i++) {
    const z = start + offsets[i] + (intro ? 0 : (random.next() - .5) * (hard ? .36 : .56));
    const freeDistance = Math.max(0, z - previous.z - F.route.maxObstacleDepth - F.ballRadius * 2);
    const reachable = freeDistance / (F.maxForwardSpeed * F.boostMultiplier) * F.steeringSensitivity * F.route.transitionSafety;
    const step = Math.min(hard ? F.route.hardStep : F.route.normalStep, reachable);
    let turn = turns[i] * direction;
    if (Math.abs(previous.safeX + turn * step) > F.route.maxCenter) turn *= -1;
    const row = { z, safeX: intro ? 0 : clamp(previous.safeX + turn * step, -F.route.maxCenter, F.route.maxCenter), gap: intro ? gap : gap + (random.next() - .5) * .16 };
    rows.push(row); previous = row;
  }
  return rows;
}

export function routeX(rows: readonly ChallengeRow[], z: number): number {
  if (z <= rows[0].z) return rows[0].safeX;
  for (let i = 1; i < rows.length; i++) if (z <= rows[i].z) {
    const previous = rows[i - 1], next = rows[i];
    // Stay centred through each obstacle's full depth before starting the slalom.
    const blend = clamp((z - previous.z - F.route.rowClearance) / (next.z - previous.z - 2 * F.route.rowClearance), 0, 1);
    return previous.safeX + (next.safeX - previous.safeX) * blend;
  }
  return rows[rows.length - 1].safeX;
}
export function coursePickupClear(x: number, z: number, objects: readonly CourseObject[]) {
  return objects.every(o => ['star', 'boost'].includes(o.type) ||
    Math.abs(z - o.z) > o.depth / 2 + F.ballRadius + .35 ||
    Math.abs(x - o.baseX) > o.width / 2 + o.amplitude + F.ballRadius + .12);
}

export function fillChunk(chunk: Chunk, create: (type: CourseObject['type'], x: number, z: number, w: number, d: number, h: number) => CourseObject) {
  const { start, kind, rows } = chunk;
  const add = (type: CourseObject['type'], x: number, z: number, w: number, d: number, h: number) => {
    const o = create(type, x, z, w, d, h); chunk.objects.push(o); return o;
  };
  const routeTokens = (count: number) => {
    for (let i = 0; i < count; i++) {
      const z = start + 2 + i * 22 / (count - 1);
      const x = routeX(rows, z);
      if (coursePickupClear(x, z, chunk.objects)) add('star', x, z, .5, .5, .65);
    }
  };
  if (kind === 'bonusCoin') { routeTokens(22); return; }
  if (kind === 'boost') add('boost', rows[0].safeX, start + 2, 1.8, 1.8, .04);
  const edge = F.courseWidth / 2;
  const cones = (row: ChallengeRow) => {
    for (const side of [-1, 1]) add('cone', clamp(row.safeX + side * (row.gap / 2 + .55), -edge + .45, edge - .45), row.z, .9, .9, 1.35);
  };
  const gates = (row: ChallengeRow, moving = false, hole = false) => {
    const hard = kind.startsWith('hard');
    // Both halves share a phase; the fixed corridor stays open at both extremes.
    const amplitude = moving ? hard ? .55 : .45 : 0;
    const left = row.safeX - row.gap / 2 - amplitude;
    const right = row.safeX + row.gap / 2 + amplitude;
    for (const [x, width] of [[(-edge + left) / 2, left + edge], [(right + edge) / 2, edge - right]]) {
      if (width <= 0) continue;
      const wall = add(hole ? 'hole' : moving ? 'slider' : 'wall', x, row.z, width, F.route.maxObstacleDepth, hole ? .02 : 1.5);
      wall.moving = moving; wall.amplitude = amplitude;
      wall.frequency = hard ? F.moving.hardWallFrequency : F.moving.wallFrequency;
      wall.phase = (row.z - start) * .43;
    }
  };
  const special = (row: ChallengeRow, type: 'roller' | 'rotor' | 'pillar') => {
    const width = type === 'roller' ? 1.1 : type === 'rotor' ? 1.4 : .66;
    for (const side of [-1, 1]) {
      const boundary = row.safeX + side * (row.gap / 2 + .06);
      const room = edge - side * boundary;
      if (room <= 0) continue;
      if (room < width + .12) {
        add('wall', (side * edge + boundary) / 2, row.z, room, F.route.maxObstacleDepth, 1.25); continue;
      }
      const amplitude = type === 'roller' ? Math.min(.65, (room - width) / 2 - .04) : 0;
      const x = boundary + side * (width / 2 + amplitude);
      const o = add(type, x, row.z, width, width, type === 'roller' ? 1.1 : type === 'rotor' ? .7 : 1.2);
      o.moving = type === 'roller'; o.amplitude = amplitude;
      o.frequency = type === 'roller' ? 2.2 + (row.z % 1.2) : 2.8;
      o.phase = row.z * .71 + (chunk.variant ?? 0) * .17;
      if (type === 'pillar') {
        const far = side * (edge - .4);
        if (Math.abs(far - x) > .9) add('pillar', far, row.z, .66, .66, 1.2);
      }
    }
  };
  rows.forEach((row, index) => {
    if (kind === 'mediumRollers') { special(row, 'roller'); return; }
    if (kind === 'mediumRotors') { special(row, 'rotor'); return; }
    if (kind === 'mediumSlalom') { special(row, 'pillar'); return; }
    if (kind === 'hardMix') {
      const family = ((chunk.variant ?? chunk.id) + index * 3) % 5;
      if (family < 3) special(row, (['roller', 'rotor', 'pillar'] as const)[family]);
      else gates(row, family === 3, family === 4);
      return;
    }
    if (kind === 'easyStraight' || kind === 'easyCoin' || kind === 'boost') { cones(row); return; }
    if ((kind === 'mediumDefender' || kind === 'mediumBars') && index === 0) {
      const side = row.safeX >= 0 ? -1 : 1;
      const defender = kind === 'mediumDefender', width = defender ? 1.6 : 2.5;
      const amplitude = defender ? .85 : .45;
      const x = row.safeX + side * (row.gap / 2 + width / 2 + amplitude);
      const o = add(defender ? 'defender' : 'bar', x, row.z, width, 1.1, 1.9);
      o.moving = true; o.amplitude = amplitude; o.frequency = defender ? F.moving.defenderFrequency : F.moving.barFrequency;
      add('cone', clamp(row.safeX - side * (row.gap / 2 + .55), -edge + .45, edge - .45), row.z, .9, .9, 1.35);
      return;
    }
    if ((kind === 'mediumDefender' || kind === 'mediumBars') && index === 1) { cones(row); return; }
    gates(row, kind === 'mediumSlidingWalls' || kind === 'hardSlidingWalls', kind === 'hardHoles');
  });
  routeTokens(9);
}
