import { FOOTBALL as F } from '../../core/config';
import { clamp, Random } from '../../core/types';
export type ChunkKind = 'easyStraight' | 'easyCoin' | 'mediumWalls' | 'mediumDefender' | 'mediumBars' | 'mediumSlidingWalls' | 'hardSlidingWalls' | 'hardNarrow' | 'hardHoles' | 'bonusCoin' | 'boost';
export interface CourseObject {
  id: number; type: 'cone' | 'wall' | 'slider' | 'defender' | 'bar' | 'hole' | 'star' | 'boost';
  x: number; baseX: number; z: number; width: number; depth: number; height: number;
  moving: boolean; amplitude: number; frequency: number; phase: number; passed: boolean;
}
export interface ChallengeRow { z: number; safeX: number; gap: number }
export interface Chunk {
  id: number; start: number; kind: ChunkKind; safeX: number; gap: number;
  rows: ChallengeRow[]; objects: CourseObject[];
}
export const CHUNK_KINDS: ChunkKind[] = ['easyStraight', 'easyCoin', 'mediumWalls', 'mediumDefender', 'mediumBars', 'mediumSlidingWalls', 'hardSlidingWalls', 'hardNarrow', 'hardHoles', 'bonusCoin', 'boost'];
export function motionOffset(o: CourseObject, time: number) {
  const phase = time * o.frequency + o.phase;
  return o.amplitude * (o.type === 'defender' ? .78 * Math.sin(phase) + .22 * Math.sin(phase * 2.4 + 1.1) : Math.sin(phase));
}

// A bounded slalom through 3–4 rows per chunk, including the previous seam.
// Every center change fits after both collision volumes clear at maximum BOOST.
export function planRows(start: number, kind: ChunkKind, gap: number, previous: ChallengeRow, random: Random, intro = false): ChallengeRow[] {
  if (kind === 'bonusCoin') return [{ z: start + 13, safeX: previous.safeX, gap: F.courseWidth }];
  const hard = kind.startsWith('hard');
  const offsets = hard ? F.challengeRows.hard : F.challengeRows.normal;
  const direction = random.pick([-1, 1]);
  const turns = hard ? [1, -1, 1, -1] : kind === 'mediumDefender' ? [1, 1, -1] : [1, -1, 1];
  const rows: ChallengeRow[] = [];
  for (let i = 0; i < offsets.length; i++) {
    const z = start + offsets[i];
    const freeDistance = Math.max(0, z - previous.z - F.route.maxObstacleDepth - F.ballRadius * 2);
    const reachable = freeDistance / (F.maxForwardSpeed * F.boostMultiplier) * F.steeringSensitivity * F.route.transitionSafety;
    const step = Math.min(hard ? F.route.hardStep : F.route.normalStep, reachable);
    let turn = turns[i] * direction;
    if (Math.abs(previous.safeX + turn * step) > F.route.maxCenter) turn *= -1;
    const row = { z, safeX: intro ? 0 : clamp(previous.safeX + turn * step, -F.route.maxCenter, F.route.maxCenter), gap };
    rows.push(row); previous = row;
  }
  return rows;
}

export function routeX(rows: readonly ChallengeRow[], z: number): number {
  if (z <= rows[0].z) return rows[0].safeX;
  for (let i = 1; i < rows.length; i++) if (z <= rows[i].z) {
    const previous = rows[i - 1], next = rows[i];
    // Stay centred through each obstacle's full depth before starting the slalom.
    const blend = clamp((z - previous.z - F.route.rowClearance) / (next.z - previous.z - 2 * F.route.rowClearance), 0, 1);
    return previous.safeX + (next.safeX - previous.safeX) * blend;
  }
  return rows[rows.length - 1].safeX;
}
export function coursePickupClear(x: number, z: number, objects: readonly CourseObject[]) {
  return objects.every(o => ['star', 'boost'].includes(o.type) ||
    Math.abs(z - o.z) > o.depth / 2 + F.ballRadius + .35 ||
    Math.abs(x - o.baseX) > o.width / 2 + o.amplitude + F.ballRadius + .12);
}

export function fillChunk(chunk: Chunk, create: (type: CourseObject['type'], x: number, z: number, w: number, d: number, h: number) => CourseObject) {
  const { start, kind, rows } = chunk;
  const add = (type: CourseObject['type'], x: number, z: number, w: number, d: number, h: number) => {
    const o = create(type, x, z, w, d, h); chunk.objects.push(o); return o;
  };
  const routeTokens = (count: number) => {
    for (let i = 0; i < count; i++) {
      const z = start + 2 + i * 22 / (count - 1);
      const x = routeX(rows, z);
      if (coursePickupClear(x, z, chunk.objects)) add('star', x, z, .5, .5, .65);
    }
  };
  if (kind === 'bonusCoin') { routeTokens(22); return; }
  if (kind === 'boost') add('boost', rows[0].safeX, start + 2, 1.8, 1.8, .04);
  const edge = F.courseWidth / 2;
  const cones = (row: ChallengeRow) => {
    for (const side of [-1, 1]) add('cone', clamp(row.safeX + side * (row.gap / 2 + .55), -edge + .45, edge - .45), row.z, .9, .9, 1.35);
  };
  const gates = (row: ChallengeRow, moving = false, hole = false) => {
    const hard = kind.startsWith('hard');
    // Both halves share a phase; the fixed corridor stays open at both extremes.
    const amplitude = moving ? hard ? .55 : .45 : 0;
    const left = row.safeX - row.gap / 2 - amplitude;
    const right = row.safeX + row.gap / 2 + amplitude;
    for (const [x, width] of [[(-edge + left) / 2, left + edge], [(right + edge) / 2, edge - right]]) {
      if (width <= 0) continue;
      const wall = add(hole ? 'hole' : moving ? 'slider' : 'wall', x, row.z, width, F.route.maxObstacleDepth, hole ? .02 : 1.5);
      wall.moving = moving; wall.amplitude = amplitude;
      wall.frequency = hard ? F.moving.hardWallFrequency : F.moving.wallFrequency;
      wall.phase = (row.z - start) * .43;
    }
  };
  rows.forEach((row, index) => {
    if (kind === 'easyStraight' || kind === 'easyCoin' || kind === 'boost') { cones(row); return; }
    if ((kind === 'mediumDefender' || kind === 'mediumBars') && index === 0) {
      const side = row.safeX >= 0 ? -1 : 1;
      const defender = kind === 'mediumDefender', width = defender ? 1.6 : 2.5;
      const amplitude = defender ? .85 : .45;
      const x = row.safeX + side * (row.gap / 2 + width / 2 + amplitude);
      const o = add(defender ? 'defender' : 'bar', x, row.z, width, 1.1, 1.9);
      o.moving = true; o.amplitude = amplitude; o.frequency = defender ? F.moving.defenderFrequency : F.moving.barFrequency;
      add('cone', clamp(row.safeX - side * (row.gap / 2 + .55), -edge + .45, edge - .45), row.z, .9, .9, 1.35);
      return;
    }
    if ((kind === 'mediumDefender' || kind === 'mediumBars') && index === 1) { cones(row); return; }
    gates(row, kind === 'mediumSlidingWalls' || kind === 'hardSlidingWalls', kind === 'hardHoles');
  });
  routeTokens(9);
}
