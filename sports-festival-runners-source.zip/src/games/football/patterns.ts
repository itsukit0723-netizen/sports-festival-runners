import type { ChunkKind } from './chunks';

export interface RoutePhrase { turns: readonly number[]; mirror: number; offset: number }
export interface FootballPattern { id: string; kinds: readonly ChunkKind[]; hardKinds: readonly ChunkKind[]; phrase: RoutePhrase }
const families: readonly (readonly ChunkKind[])[] = [
  ['mediumWalls', 'mediumSlalom', 'mediumBars', 'mediumDefender'],
  ['mediumRollers', 'mediumWalls', 'mediumRotors', 'mediumSlalom'],
  ['mediumSlidingWalls', 'mediumDefender', 'mediumSlalom', 'mediumWalls'],
  ['mediumRotors', 'mediumBars', 'mediumSlidingWalls', 'mediumRollers'],
  ['mediumSlalom', 'mediumRollers', 'mediumDefender', 'mediumRotors'],
  ['mediumDefender', 'mediumSlidingWalls', 'mediumBars', 'mediumWalls'],
  ['mediumBars', 'mediumRotors', 'mediumWalls', 'mediumRollers'],
  ['mediumSlidingWalls', 'mediumSlalom', 'mediumRollers', 'mediumBars'],
];
const phrases = [[1, 1, -1, -1, 0], [1, 0, -1, 0, 1], [1, -1, 1, -1, 0], [0, 1, 1, -1, -1], [-1, -1, 0, 1, 1], [1, 0, 1, -1, -1]];
const hard: readonly ChunkKind[] = ['hardSlidingWalls', 'hardNarrow', 'hardHoles', 'hardMix'];
// Eight obstacle themes × six steering phrases × two mirrored versions = 96.
export const FOOTBALL_PATTERNS: readonly FootballPattern[] = families.flatMap((kinds, family) => phrases.flatMap((turns, route) => [-1, 1].map(mirror => ({
  id: `route-${family}-${route}-${mirror}`, kinds,
  hardKinds: [...hard.slice(family % 4), ...hard.slice(0, family % 4)],
  phrase: { turns, mirror, offset: 0 },
}))));
export const FOOTBALL_SECTION_SECONDS = 5;
// About 15 seconds of fixed course; boosts and steering can shift arrival time.
export const FOOTBALL_OPENING_CHUNKS = 12;
