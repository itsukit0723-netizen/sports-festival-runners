import * as THREE from 'three';
import { FOOTBALL as F } from '../../core/config';
import type { GameEvent, GameRenderer } from '../../core/types';
import type { FootballModel } from './model';
import { rotorAngle, choiceRouteX, type CourseObject } from './chunks';
import { DefenderFactory } from './defender';
interface Spark { mesh: THREE.Mesh; vx: number; vy: number; vz: number; life: number }
export class FootballRenderer implements GameRenderer {
  private renderer: THREE.WebGLRenderer; private scene = new THREE.Scene();
  private camera = new THREE.PerspectiveCamera(48, 1, .1, 130);
  private ball = new THREE.Group(); private ballRoll = new THREE.Group();
  private objectMeshes = new Map<number, THREE.Group>(); private meshPool = new Map<string, THREE.Group[]>();
  private materials = new Map<string, THREE.MeshStandardMaterial>();
  private marks: THREE.Mesh[] = []; private scenery: THREE.Group[] = [];
  private ghosts: THREE.Mesh[] = []; private speedLines: THREE.Mesh[] = [];
  private sparks: Spark[] = []; private sparkPool: THREE.Mesh[] = [];
  private geometries: THREE.BufferGeometry[] = [];
  private box = this.keep(new THREE.BoxGeometry(1, 1, 1));
  private sphere = this.keep(new THREE.SphereGeometry(1, 20, 14));
  private starGeo = this.keep(this.starGeometry());
  private particleGeo = this.keep(new THREE.IcosahedronGeometry(.065, 0));
  private boostLight = new THREE.PointLight('#d2ff8f', 0, 8);
  private lastRoll = 0; private lastSideRoll = 0;
  private rollAxis = new THREE.Vector3(1, 0, 0); private sideAxis = new THREE.Vector3(0, 0, 1);
  private disposed = false;
  private choiceMarks: THREE.Mesh[] = [];
  private doubleBadge?: THREE.SpriteMaterial;
  private defenders: DefenderFactory;
  constructor(private canvas: HTMLCanvasElement, private model: FootballModel) {
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance', alpha: false });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.65));
    this.renderer.setClearColor('#27364c'); this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.scene.fog = new THREE.Fog('#34475c', 28, 104);
    this.scene.add(new THREE.HemisphereLight('#c6d8ed', '#283a3d', 1.65));
    const light = new THREE.DirectionalLight('#ffe1b4', 2.4); light.position.set(-8, 16, 9); this.scene.add(light);
    const rim = new THREE.DirectionalLight('#9cbbdf', 1.1); rim.position.set(6, 8, -20); this.scene.add(rim);
    this.defenders = new DefenderFactory(g => this.keep(g), color => this.material(color));
    this.buildWorld(); this.buildBall(); this.scene.add(this.boostLight);
    this.resize();
  }
  private keep<T extends THREE.BufferGeometry>(g: T): T { this.geometries.push(g); return g; }
  private material(color: string, emissive = false) {
    const key = color + emissive;
    if (!this.materials.has(key)) this.materials.set(key, new THREE.MeshStandardMaterial({ color, roughness: .72, metalness: .03, ...(emissive ? { emissive: color, emissiveIntensity: .55 } : {}) }));
    return this.materials.get(key)!;
  }
  private mesh(geo: THREE.BufferGeometry, color: string, x: number, y: number, z: number, sx = 1, sy = 1, sz = 1, glow = false) {
    const mesh = new THREE.Mesh(geo, this.material(color, glow)); mesh.position.set(x, y, z); mesh.scale.set(sx, sy, sz); return mesh;
  }
  private buildWorld() {
    const sky = document.createElement('canvas'); sky.width = 16; sky.height = 256;
    const c = sky.getContext('2d')!, gradient = c.createLinearGradient(0, 0, 0, 256);
    gradient.addColorStop(0, '#192638'); gradient.addColorStop(.55, '#2c3d53'); gradient.addColorStop(1, '#637788');
    c.fillStyle = gradient; c.fillRect(0, 0, 16, 256);
    const skyTexture = new THREE.CanvasTexture(sky); skyTexture.colorSpace = THREE.SRGBColorSpace;
    this.scene.background = skyTexture;
    const moon = new THREE.Mesh(this.keep(new THREE.CircleGeometry(3, 48)), new THREE.MeshBasicMaterial({ color: '#f2dba8', fog: false }));
    moon.position.set(-16, 14, -95); this.scene.add(moon);
    const halo = new THREE.Mesh(this.keep(new THREE.CircleGeometry(4.8, 48)), new THREE.MeshBasicMaterial({ color: '#e8d6af', transparent: true, opacity: .07, depthWrite: false, fog: false }));
    halo.position.set(-16, 14, -95.1); this.scene.add(halo);
    const floor = this.mesh(this.box, '#304847', 0, -.24, -47, 8.8, .4, 120); this.scene.add(floor);
    for (const side of [-1, 1]) {
      this.scene.add(this.mesh(this.box, '#263749', side * 4.7, -.12, -47, .6, .65, 120));
      this.scene.add(this.mesh(this.box, '#e0c49c', side * 4.27, .01, -47, .08, .025, 120));
      this.scene.add(this.mesh(this.box, '#243541', side * 10, -.8, -45, 9, 1.2, 120));
      this.scene.add(this.mesh(this.box, '#b8795b', side * 4.62, .22, -47, .12, .055, 120));
      for (let i = 0; i < 12; i++) {
        const group = new THREE.Group(); group.position.set(side * 7.1, 0, -i * 10);
        // Quiet night stadium: stepped seating, metal rails and warm floodlights.
        group.add(this.mesh(this.box, '#28394b', side * .5, .4, 0, 2, .8, 3));
        for (let step = 0; step < 3; step++) group.add(this.mesh(this.box, step % 2 ? '#b38b71' : '#7b8483', side * (.1 + step * .45), .48 + step * .24, 0, .48, .1, 2.8));
        group.add(this.mesh(this.box, '#34495b', side * 2.5, 1.7, 2, 2, 3.4, 3));
        for (let j = 0; j < 3; j++) group.add(this.mesh(this.box, '#b9a078', side * 1.48, .7 + j * .7, 2, .02, .18, .5, true));
        if (i % 3 === 0) {
          group.add(this.mesh(this.box, '#3a4b5e', 0, 3.7, -2.3, .14, 7.4, .14));
          group.add(this.mesh(this.box, '#d6cdb7', 0, 7.3, -2.3, 1.65, .24, .55, true));
          for (const x of [-.55, 0, .55]) group.add(this.mesh(this.box, '#fff0d0', x, 7.22, -1.99, .38, .15, .04, true));
        }
        this.scenery.push(group); this.scene.add(group);
      }
    }
    for (let i = 0; i < 36; i++) {
      const mark = this.mesh(this.box, '#afa88b', 0, .006, -i * 3, .045, .012, 1.1);
      this.marks.push(mark); this.scene.add(mark);
    }
    const circle = this.keep(new THREE.RingGeometry(1.55, 1.59, 48));
    const ring = new THREE.Mesh(circle, new THREE.MeshBasicMaterial({ color: '#c6b693', side: THREE.DoubleSide })); ring.rotation.x = -Math.PI / 2; ring.position.set(0, .015, -10); this.scene.add(ring);
    for (let i = 0; i < 16; i++) {
      const line = this.mesh(this.box, '#e9ffca', (i % 2 ? -1 : 1) * 3.8, .025, -i * 5, .055, .012, 2.5, true);
      this.speedLines.push(line); this.scene.add(line);
    }
    for (let i = 0; i < 72; i++) {
      const mark = this.mesh(this.box, '#dfa568', 0, .035, 0, .055, .015, .45, true);
      mark.visible = false; this.choiceMarks.push(mark); this.scene.add(mark);
    }
  }
  private buildBall() {
    const radius = F.ballRadius;
    this.ballRoll.add(this.mesh(this.sphere, '#fff9e9', 0, 0, 0, radius, radius, radius));
    const ico = new THREE.IcosahedronGeometry(1, 0), pos = ico.getAttribute('position'), vertices = new Map<string, THREE.Vector3>();
    for (let i = 0; i < pos.count; i++) { const n = new THREE.Vector3().fromBufferAttribute(pos, i).normalize(); vertices.set(n.toArray().map(v => v.toFixed(3)).join(','), n); }
    for (const n of vertices.values()) {
      const tangent = new THREE.Vector3().crossVectors(n, new THREE.Vector3(0, 1, .001)).normalize();
      const bitangent = new THREE.Vector3().crossVectors(n, tangent).normalize(), coords: number[] = [];
      const at = (a: number) => n.clone().addScaledVector(tangent, Math.cos(a) * .31).addScaledVector(bitangent, Math.sin(a) * .31).normalize().multiplyScalar(radius + .003);
      // Subdivide and project the pentagons onto the sphere. A flat fan clips
      // under the sphere and causes flickering black patches while rolling.
      const triangle = (a: THREE.Vector3, b: THREE.Vector3, c: THREE.Vector3, depth: number) => {
        if (!depth) { coords.push(...a.clone().normalize().multiplyScalar(radius + .005).toArray(), ...b.clone().normalize().multiplyScalar(radius + .005).toArray(), ...c.clone().normalize().multiplyScalar(radius + .005).toArray()); return; }
        const ab = a.clone().add(b).normalize(), bc = b.clone().add(c).normalize(), ca = c.clone().add(a).normalize();
        triangle(a, ab, ca, depth - 1); triangle(ab, b, bc, depth - 1); triangle(ca, bc, c, depth - 1); triangle(ab, bc, ca, depth - 1);
      };
      for (let i = 0; i < 5; i++) triangle(n.clone(), at(i * Math.PI * 2 / 5).normalize(), at((i + 1) * Math.PI * 2 / 5).normalize(), 2);
      const geo = this.keep(new THREE.BufferGeometry()); geo.setAttribute('position', new THREE.Float32BufferAttribute(coords, 3)); geo.computeVertexNormals();
      this.ballRoll.add(new THREE.Mesh(geo, this.material('#263944')));
    }
    ico.dispose(); this.ball.add(this.ballRoll); this.ball.position.set(0, radius + .03, 0); this.scene.add(this.ball);
    for (let i = 0; i < 3; i++) {
      const ghost = new THREE.Mesh(this.sphere, new THREE.MeshBasicMaterial({ color: '#edffd8', transparent: true, opacity: .16 - i * .04, depthWrite: false }));
      ghost.scale.setScalar(radius * (1 - i * .08)); this.ghosts.push(ghost); this.scene.add(ghost);
    }
    // Soft contact shadow without a mobile-expensive shadow map.
    const canvas = document.createElement('canvas'); canvas.width = canvas.height = 64; const c = canvas.getContext('2d')!;
    const g = c.createRadialGradient(32, 32, 2, 32, 32, 30); g.addColorStop(0, '#26394080'); g.addColorStop(1, '#26394000'); c.fillStyle = g; c.fillRect(0, 0, 64, 64);
    const tex = new THREE.CanvasTexture(canvas), mat = new THREE.MeshBasicMaterial({ map: tex, transparent: true, depthWrite: false });
    const shadow = new THREE.Mesh(this.keep(new THREE.PlaneGeometry(1.5, 1.5)), mat); shadow.rotation.x = -Math.PI / 2; shadow.position.y = .025;
    shadow.userData.ballShadow = true; this.scene.add(shadow);
  }
  private starGeometry() {
    const shape = new THREE.Shape();
    for (let i = 0; i < 10; i++) { const a = i * Math.PI / 5 + Math.PI / 2, r = i % 2 ? .18 : .37; if (i === 0) shape.moveTo(Math.cos(a) * r, Math.sin(a) * r); else shape.lineTo(Math.cos(a) * r, Math.sin(a) * r); }
    shape.closePath(); return new THREE.ExtrudeGeometry(shape, { depth: .09, bevelEnabled: false });
  }
  private object(o: CourseObject) {
    const key = o.type === 'star' && o.rewardMultiplier === 2 ? 'doubleStar' : o.type;
    const pooled = this.meshPool.get(key)?.pop();
    if (pooled) { pooled.visible = true; return pooled; }
    const g = o.type === 'defender' ? this.defenders.create() : new THREE.Group(); g.userData.type = key;
    if (o.type === 'star') {
      const double = o.rewardMultiplier === 2;
      g.add(this.mesh(this.starGeo, double ? '#f7a05b' : '#f7cd5a', 0, 0, 0, 1, 1, 1, true));
      if (double) {
        if (!this.doubleBadge) {
          const canvas = document.createElement('canvas'); canvas.width = 128; canvas.height = 64;
          const c = canvas.getContext('2d')!; c.fillStyle = '#253744e8'; c.fillRect(0, 0, 128, 64);
          c.fillStyle = '#ffd197'; c.font = 'bold 48px Arial'; c.textAlign = 'center'; c.fillText('×2', 64, 49);
          const map = new THREE.CanvasTexture(canvas); map.colorSpace = THREE.SRGBColorSpace;
          this.doubleBadge = new THREE.SpriteMaterial({ map, transparent: true, depthWrite: false });
        }
        const badge = new THREE.Sprite(this.doubleBadge); badge.position.y = 1.1; badge.scale.set(1.1, .55, 1); g.add(badge);
      }
    }
    else if (o.type === 'boost') {
      g.add(this.mesh(this.box, '#c4fb87', 0, .03, 0, 1, .06, 1, true));
      for (let i = 0; i < 3; i++) { const arrow = this.mesh(this.box, '#f8ffe6', 0, .07, .3 - i * .28, .45, .015, .08); arrow.rotation.y = -.3; g.add(arrow); }
    } else if (o.type === 'roller') {
      const rolling = new THREE.Group(); rolling.position.y = .55;
      rolling.add(this.mesh(this.sphere, '#b9683f', 0, 0, 0, .55, .55, .55));
      const band = this.keep(new THREE.TorusGeometry(.55, .025, 6, 28));
      rolling.add(this.mesh(band, '#293e48', 0, 0, 0));
      const other = this.mesh(band, '#e1bd85', 0, 0, 0); other.rotation.y = Math.PI / 2; rolling.add(other);
      g.add(rolling);
      g.add(this.mesh(this.box, '#22373d', 0, .015, 0, .85, .02, .85));
    } else if (o.type === 'rotor') {
      const rotating = new THREE.Group(); rotating.position.y = .45;
      for (const angle of [0, Math.PI / 2]) {
        const arm = new THREE.Group(); arm.rotation.y = angle;
        arm.add(this.mesh(this.box, '#9ba49b', 0, 0, 0, 1.4, .14, .16));
        for (const side of [-1, 1]) arm.add(this.mesh(this.box, '#efb36d', side * .61, .005, 0, .18, .15, .17, true));
        rotating.add(arm);
      }
      g.add(rotating);
      g.add(this.mesh(this.keep(new THREE.CylinderGeometry(.13, .2, .64, 10)), '#324956', 0, .32, 0));
      g.add(this.mesh(this.keep(new THREE.CylinderGeometry(.25, .25, .1, 10)), '#d9bb87', 0, .7, 0));
    } else if (o.type === 'pillar') {
      g.add(this.mesh(this.keep(new THREE.CylinderGeometry(.22, .28, 1.15, 10)), '#334d5b', 0, .575, 0));
      g.add(this.mesh(this.keep(new THREE.CylinderGeometry(.245, .255, .13, 10)), '#e7bc7f', 0, .89, 0, 1, 1, 1, true));
      g.add(this.mesh(this.keep(new THREE.CylinderGeometry(.24, .24, .09, 10)), '#c9b48d', 0, 1.16, 0));
      g.add(this.mesh(this.box, '#8eb9ad', 0, .47, .265, .035, .42, .015, true));
      g.add(this.mesh(this.box, '#21333e', 0, .035, 0, .66, .07, .66));
    } else if (o.type === 'cone') {
      const cone = this.keep(new THREE.ConeGeometry(.36, 1, 8));
      g.add(this.mesh(cone, '#e28752', 0, .5, 0)); g.add(this.mesh(this.box, '#8d5c48', 0, .07, 0, .85, .14, .85));
      g.add(this.mesh(this.keep(new THREE.CylinderGeometry(.18, .23, .14, 8)), '#fff0d9', 0, .58, 0));
    } else if (o.type === 'defender') {
      // The same detailed athlete now plays under the stadium's night lighting.
    } else if (o.type === 'bar') {
      g.add(this.mesh(this.box, '#475b66', 0, .38, 0, .13, .75, .2));
      const bar = this.mesh(this.box, '#ce926b', 0, .65, 0, 1, .28, .55); g.add(bar);
      g.add(this.mesh(this.box, '#fff2d4', 0, .66, .28, .2, .28, .03));
    } else if (o.type === 'hole') {
      g.add(this.mesh(this.box, '#101d29', 0, .025, 0));
      for (const side of [-1, 1]) g.add(this.mesh(this.box, '#dbad68', 0, .04, side * .45, 1, .025, .08, true));
    } else {
      // Padded training barricades: charcoal steel, ribbed inserts, amber trim.
      const moving = o.type === 'slider';
      g.add(this.mesh(this.box, '#263847', 0, .46, 0, 1, .92, .94));
      for (let i = 0; i < 4; i++) g.add(this.mesh(this.box, i % 2 ? '#40545b' : '#354952', -.375 + i * .25, .51, .48, .235, .66, .035));
      for (const side of [-1, 1]) {
        g.add(this.mesh(this.box, '#75807c', side * .47, .5, .49, .035, .92, .04));
        const slash = this.mesh(this.box, '#e4ba85', side * .23, .52, .51, .055, .3, .025); slash.rotation.z = side * -.42; g.add(slash);
      }
      g.add(this.mesh(this.box, '#bd8c63', 0, .96, 0, 1, .08, .98));
      g.add(this.mesh(this.box, moving ? '#a6d5c0' : '#e2b985', 0, .84, .51, .72, .035, .025, true));
      g.add(this.mesh(this.box, '#172938', 0, .055, 0, 1, .11, 1));
    }
    return g;
  }
  resize() { const w = this.canvas.clientWidth, h = this.canvas.clientHeight; this.renderer.setSize(w, h, false); this.camera.aspect = w / h; this.camera.updateProjectionMatrix(); }
  render(dt: number, events: GameEvent[]) {
    if (this.disposed) return;
    const m = this.model, active = new Set<number>();
    let markIndex = 0;
    for (const chunk of m.chunks) if (chunk.choice) for (let i = 0; i < 12 && markIndex < this.choiceMarks.length; i++) {
      const z = chunk.start - 1 + i * 2;
      const mark = this.choiceMarks[markIndex++]; mark.position.set(choiceRouteX(chunk, z), .035, -(z - m.distance));
      mark.visible = z > m.distance - 1 && z < m.distance + F.visibleDistance;
    }
    for (; markIndex < this.choiceMarks.length; markIndex++) this.choiceMarks[markIndex].visible = false;
    for (const chunk of m.chunks) for (const o of chunk.objects) {
      if (o.passed && (o.type === 'star' || o.type === 'boost')) continue;
      if (o.z - m.distance < -7) continue;
      active.add(o.id); let mesh = this.objectMeshes.get(o.id);
      if (!mesh) { mesh = this.object(o); this.objectMeshes.set(o.id, mesh); this.scene.add(mesh); }
      mesh.position.set(o.x, o.type === 'star' ? .85 + Math.sin(m.time * 3 + o.id) * .08 : 0, -(o.z - m.distance));
      if (o.type === 'star') mesh.rotation.y = m.time * 2 + o.id;
      if (o.type === 'rotor') mesh.children[0].rotation.y = rotorAngle(o, m.time);
      if (o.type === 'roller') {
        mesh.children[0].rotation.z = -o.x / .55;
        mesh.children[0].rotation.x = m.time * .6 + o.phase;
      }
      if (o.type === 'wall' || o.type === 'slider' || o.type === 'hole' || o.type === 'boost') mesh.scale.set(o.width, o.height || .04, o.depth);
      if (o.type === 'bar') { mesh.children[1].scale.x = o.width; mesh.children[1].rotation.y = Math.sin(m.time * o.frequency + o.phase) * .26; }
      if (o.type === 'defender') this.defenders.animate(mesh, m.time + o.phase, o.frequency, m.x - o.x);
    }
    for (const [id, mesh] of this.objectMeshes) if (!active.has(id)) {
      this.scene.remove(mesh); mesh.visible = false; this.objectMeshes.delete(id);
      const type = mesh.userData.type as string; if (!this.meshPool.has(type)) this.meshPool.set(type, []); this.meshPool.get(type)!.push(mesh);
    }
    this.ball.position.x = m.x; this.ball.position.y = F.ballRadius + .03 + Math.sin(m.distance * 4) * .012;
    this.ballRoll.rotateOnWorldAxis(this.rollAxis, m.rotation - this.lastRoll);
    this.ballRoll.rotateOnWorldAxis(this.sideAxis, m.sideRotation - this.lastSideRoll);
    this.lastRoll = m.rotation; this.lastSideRoll = m.sideRotation;
    for (const child of this.scene.children) if (child.userData.ballShadow) child.position.x = m.x;
    this.camera.position.x += (m.x * .8 - this.camera.position.x) * (1 - Math.exp(-dt * 12));
    this.camera.position.y = 5.1; this.camera.position.z = 9;
    this.camera.lookAt(this.camera.position.x * .85, .1, -8);
    const targetFov = m.boost > 0 ? 57 : 48;
    this.camera.fov += (targetFov - this.camera.fov) * (1 - Math.exp(-dt * 3)); this.camera.updateProjectionMatrix();
    for (let i = 0; i < this.marks.length; i++) this.marks[i].position.z = 5 - ((i * 3 - m.distance) % 108 + 108) % 108;
    for (let i = 0; i < this.scenery.length; i++) this.scenery[i].position.z = 6 - (((i % 12) * 10 - m.distance) % 120 + 120) % 120;
    for (let i = 0; i < this.ghosts.length; i++) { const g = this.ghosts[i]; g.visible = m.boost > 0; g.position.set(m.x, F.ballRadius, (i + 1) * .65); }
    for (let i = 0; i < this.speedLines.length; i++) { const line = this.speedLines[i]; line.visible = m.boost > 0; line.position.z = 4 - ((i * 5 - m.distance * 1.4) % 80 + 80) % 80; }
    this.boostLight.position.set(m.x, 1, 0); this.boostLight.intensity = m.boost > 0 ? 4 : 0;
    for (const e of events) if (e.kind === 'coin' || e.kind === 'over' || e.kind === 'boost') {
      for (let i = 0; i < (e.kind === 'coin' ? 6 : 22) && this.sparks.length < F.maxParticles; i++) {
        const mesh = this.sparkPool.pop() ?? this.mesh(this.particleGeo, '#ffeaa0', 0, 0, 0, 1, 1, 1, true);
        mesh.position.set(e.x ?? m.x, .6, 0); mesh.visible = true; this.scene.add(mesh);
        this.sparks.push({ mesh, vx: (Math.random() - .5) * 4, vy: 2 + Math.random() * 3, vz: (Math.random() - .5) * 4, life: .45 + Math.random() * .3 });
      }
    }
    for (const p of this.sparks) {
      p.life -= dt; p.mesh.position.x += p.vx * dt; p.mesh.position.y += p.vy * dt; p.mesh.position.z += (p.vz + m.speed * .25) * dt; p.vy -= dt * 8;
      p.mesh.scale.setScalar(Math.max(0, p.life * 2));
    }
    this.sparks = this.sparks.filter(p => { if (p.life > 0) return true; this.scene.remove(p.mesh); p.mesh.visible = false; this.sparkPool.push(p.mesh); return false; });
    this.renderer.render(this.scene, this.camera);
  }
  dispose() {
    this.disposed = true;
    if (this.scene.background instanceof THREE.Texture) this.scene.background.dispose();
    this.scene.traverse(o => { const mesh = o as THREE.Mesh; if (mesh.material && !Array.isArray(mesh.material) && mesh.material instanceof THREE.MeshBasicMaterial) { mesh.material.map?.dispose(); mesh.material.dispose(); } });
    this.geometries.forEach(g => g.dispose()); this.materials.forEach(m => m.dispose()); this.renderer.dispose();
    this.doubleBadge?.map?.dispose(); this.doubleBadge?.dispose();
    this.objectMeshes.clear(); this.meshPool.clear();
  }
}
