import * as THREE from 'three';
import { WORLD_IDS, type WorldId } from './worlds';

// Subtle hand-drawn surface detail; no high contrast noise across safe gaps.
export function worldSurfaces() {
  return new Map(WORLD_IDS.map(world => {
    const canvas = document.createElement('canvas'); canvas.width = canvas.height = 256;
    const c = canvas.getContext('2d')!; c.fillStyle = '#dedede'; c.fillRect(0, 0, 256, 256);
    let n = 717;
    const random = () => { n = (Math.imul(n, 1664525) + 1013904223) >>> 0; return n / 0x100000000; };
    for (let i = 0; i < 1800; i++) { c.fillStyle = `rgba(35,45,60,${random() * .045})`; c.fillRect(random() * 256, random() * 256, 1, 1); }
    c.lineWidth = 1;
    if (world === 'ice') {
      c.strokeStyle = '#94b2bd50';
      for (let j = 0; j < 8; j++) { c.beginPath(); let x = random() * 256; c.moveTo(x, 0); for (let k = 0; k < 7; k++) { x += random() * 55 - 27; c.lineTo(x, k * 44); } c.stroke(); }
    } else {
      const step = world === 'orbit' ? 64 : 128; c.strokeStyle = '#6d77832c';
      for (let y = 0; y <= 256; y += step) { c.beginPath(); c.moveTo(0, y); c.lineTo(256, y); c.stroke(); }
      for (let j = 0; j < 4; j++) { c.beginPath(); c.moveTo(j * 64, 0); c.lineTo(j * 64, 256); c.stroke(); }
      if (world === 'orbit') for (let y = 10; y < 256; y += 64) for (let x = 10; x < 256; x += 64) { c.fillStyle = '#6a738435'; c.fillRect(x, y, 2, 2); c.fillRect(x + 43, y, 2, 2); }
    }
    const texture = new THREE.CanvasTexture(canvas); texture.colorSpace = THREE.SRGBColorSpace;
    texture.wrapS = texture.wrapT = THREE.RepeatWrapping; texture.repeat.set(2, 24); texture.anisotropy = 2;
    return [world, texture] as [WorldId, THREE.CanvasTexture];
  }));
}
