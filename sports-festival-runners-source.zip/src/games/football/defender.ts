import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';

interface Rig { leftArm: THREE.Object3D; rightArm: THREE.Object3D; leftLeg: THREE.Object3D; rightLeg: THREE.Object3D; head: THREE.Object3D }
type Retain = <T extends THREE.BufferGeometry>(geometry: T) => T;
type Material = (color: string) => THREE.Material;

/** One shared, original athlete mesh; only the small joint groups are animated. */
export class DefenderFactory {
  private prototype: THREE.Group;
  private rigs = new WeakMap<THREE.Group, Rig>();
  private instances = new Set<THREE.Group>();
  constructor(keep: Retain, material: Material) {
    const player = new THREE.Group();
    const sphere = keep(new THREE.SphereGeometry(1, 16, 12));
    const capsule = keep(new THREE.CapsuleGeometry(.1, .3, 3, 10));
    const box = keep(new THREE.BoxGeometry(1, 1, 1));
    const hair = keep(new THREE.SphereGeometry(1, 16, 9, 0, Math.PI * 2, 0, Math.PI * .54));
    const collar = keep(new THREE.TorusGeometry(.105, .018, 5, 20));
    const torso = keep(new THREE.LatheGeometry([
      new THREE.Vector2(.22, 0), new THREE.Vector2(.26, .08), new THREE.Vector2(.25, .25),
      new THREE.Vector2(.31, .47), new THREE.Vector2(.33, .53), new THREE.Vector2(.23, .58),
    ], 16));
    const skin = '#dba98b', kit = '#7774ad', shorts = '#454b73', white = '#fff2da', hairColor = '#34333c';
    const part = (parent: THREE.Object3D, geometry: THREE.BufferGeometry, color: string, position: number[], scale: number[]) => {
      const mesh = new THREE.Mesh(geometry, material(color)); mesh.position.fromArray(position); mesh.scale.fromArray(scale); parent.add(mesh); return mesh;
    };
    const limb = (parent: THREE.Object3D, color: string, from: number[], to: number[], radius: number) => {
      const a = new THREE.Vector3().fromArray(from), b = new THREE.Vector3().fromArray(to), delta = b.clone().sub(a);
      const mesh = part(parent, capsule, color, a.clone().add(b).multiplyScalar(.5).toArray(), [radius / .1, delta.length() / .5, radius / .1]);
      mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), delta.normalize()); return mesh;
    };
    // Rounded, tapered torso, a proper collar, shirt trim and a geometric number 7.
    part(player, sphere, '#638e80', [0, .016, .02], [.55, .018, .32]);
    part(player, torso, kit, [0, .82, 0], [1, 1, .66]);
    part(player, sphere, shorts, [0, .77, 0], [.29, .17, .21]);
    limb(player, skin, [0, 1.37, 0], [0, 1.51, 0], .09);
    const neck = part(player, collar, white, [0, 1.42, 0], [1, 1, 1]); neck.rotation.x = Math.PI / 2;
    for (const sign of [-1, 1]) {
      const trim = part(player, box, white, [sign * .245, 1.09, .15], [.027, .31, .027]); trim.rotation.z = sign * -.05;
    }
    part(player, box, white, [0, 1.19, .196], [.155, .028, .018]);
    const number = part(player, box, white, [.018, 1.105, .191], [.027, .19, .018]); number.rotation.z = -.42;
    part(player, sphere, '#d3f88a', [-.16, 1.28, .176], [.032, .032, .012]);
    // A face and close-cropped hairstyle, without external textures or downloads.
    const head = new THREE.Group(); head.name = 'head'; head.position.set(0, 1.66, .015); player.add(head);
    part(head, sphere, skin, [0, 0, 0], [.215, .245, .2]);
    part(head, hair, hairColor, [0, .045, -.012], [.222, .23, .209]);
    part(head, sphere, hairColor, [-.035, .195, .065], [.15, .075, .14]);
    for (const sign of [-1, 1]) {
      part(head, sphere, skin, [sign * .21, -.012, -.005], [.044, .065, .043]);
      part(head, sphere, '#f9f3e6', [sign * .077, .012, .184], [.038, .027, .014]);
      part(head, sphere, '#30363d', [sign * .073, .008, .196], [.015, .021, .008]);
      const brow = part(head, capsule, hairColor, [sign * .077, .064, .188], [.065, .14, .065]); brow.rotation.z = Math.PI / 2 + sign * .09;
    }
    part(head, sphere, '#d39b7d', [0, -.035, .201], [.037, .047, .034]);
    part(head, sphere, '#86574d', [0, -.105, .18], [.045, .009, .012]);
    // Separate upper and lower limbs create a grounded defensive stance.
    for (const sign of [-1, 1]) {
      const arm = new THREE.Group(); arm.name = sign < 0 ? 'leftArm' : 'rightArm'; arm.position.set(sign * .30, 1.33, 0); player.add(arm);
      limb(arm, skin, [0, 0, 0], [sign * .19, -.21, .025], .084);
      limb(arm, kit, [0, .015, 0], [sign * .105, -.105, .012], .12);
      limb(arm, white, [sign * .095, -.10, .012], [sign * .12, -.126, .015], .098);
      part(arm, sphere, skin, [sign * .19, -.21, .025], [.087, .087, .087]);
      limb(arm, skin, [sign * .19, -.21, .025], [sign * .35, -.065, .20], .07);
      const hand = part(arm, sphere, skin, [sign * .38, -.055, .215], [.07, .092, .043]); hand.rotation.z = sign * -.35;
      part(arm, sphere, skin, [sign * .33, -.07, .245], [.025, .04, .025]);
      const leg = new THREE.Group(); leg.name = sign < 0 ? 'leftLeg' : 'rightLeg'; leg.position.set(sign * .165, .81, 0); player.add(leg);
      limb(leg, skin, [0, -.05, 0], [sign * .10, -.31, .025], .103);
      limb(leg, shorts, [0, .01, 0], [sign * .055, -.19, .015], .14);
      part(leg, sphere, skin, [sign * .10, -.31, .025], [.087, .09, .087]);
      limb(leg, skin, [sign * .10, -.31, .025], [sign * .18, -.62, .045], .079);
      limb(leg, white, [sign * .135, -.43, .032], [sign * .18, -.65, .045], .083);
      limb(leg, kit, [sign * .135, -.43, .032], [sign * .145, -.46, .034], .086);
      part(leg, sphere, '#ecebdf', [sign * .18, -.733, .115], [.135, .047, .235]);
      part(leg, sphere, '#354454', [sign * .18, -.704, .1], [.128, .067, .22]);
      part(leg, box, white, [sign * .18, -.657, .15], [.075, .009, .1]);
    }
    // Bake stationary pieces per joint and material. Clones share the resulting
    // geometries, avoiding a separate draw call for every facial / clothing detail.
    const joints: THREE.Object3D[] = []; player.traverse(node => { if (node instanceof THREE.Group) joints.push(node); });
    for (const joint of joints) {
      const batches = new Map<THREE.Material, THREE.Mesh[]>();
      for (const child of [...joint.children]) if (child instanceof THREE.Mesh && !Array.isArray(child.material)) {
        if (!batches.has(child.material)) batches.set(child.material, []); batches.get(child.material)!.push(child);
      }
      for (const [mat, meshes] of batches) {
        const pieces = meshes.map(mesh => { mesh.updateMatrix(); return mesh.geometry.clone().applyMatrix4(mesh.matrix); });
        const merged = mergeGeometries(pieces, false); pieces.forEach(piece => piece.dispose());
        if (merged) { meshes.forEach(mesh => joint.remove(mesh)); joint.add(new THREE.Mesh(keep(merged), mat)); }
      }
    }
    this.prototype = player;
  }
  create() {
    const group = this.prototype.clone(true);
    this.instances.add(group);
    this.bind(group);
    return group;
  }
  private bind(group: THREE.Group) {
    this.rigs.set(group, {
      head: group.getObjectByName('head')!, leftArm: group.getObjectByName('leftArm')!, rightArm: group.getObjectByName('rightArm')!,
      leftLeg: group.getObjectByName('leftLeg')!, rightLeg: group.getObjectByName('rightLeg')!,
    });
  }
  setModel(model: THREE.Object3D) {
    this.prototype = new THREE.Group(); this.prototype.add(model.clone(true));
    for (const group of this.instances) {
      group.clear(); group.add(model.clone(true)); this.bind(group);
    }
  }
  dispose() { this.instances.clear(); }
  animate(group: THREE.Group, time: number, frequency: number, tracking: number) {
    const rig = this.rigs.get(group)!; const stride = Math.sin(time * frequency * 1.7);
    group.position.y += Math.abs(stride) * .014; group.rotation.z = stride * .025;
    for (const [sign, leg, arm] of [[-1, rig.leftLeg, rig.leftArm], [1, rig.rightLeg, rig.rightArm]] as const) {
      leg.rotation.x = stride * sign * .17; leg.rotation.z = stride * .055;
      arm.rotation.z = stride * sign * .09; arm.rotation.x = stride * sign * .07;
    }
    rig.head.rotation.y = THREE.MathUtils.clamp(tracking * .15, -.3, .3);
    rig.head.rotation.z = -stride * .02;
  }
}
