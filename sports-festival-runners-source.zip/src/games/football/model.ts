import { FOOTBALL as F } from '../../core/config';
import { DifficultyDirector } from '../../core/director';
import { clamp, Random, type GameModel, type GameEvent, type GameInput } from '../../core/types';
import { fillChunk, motionOffset, motionDepthOffset, challengeClearance, courseChunkLength, planRows, planChoice, planWorldChoice, chooseChunkKind, courseSweptCollision, crossingStyle, type CrossingStyle, type ChallengeRow, type Chunk, type CourseObject, type ChunkKind } from './chunks';
import { WORLDS, gateWorlds, type WorldId } from './worlds';
import { PatternDeck, OPENING_SEED } from '../../core/patterns';
import { FOOTBALL_PATTERNS, FOOTBALL_SECTION_SECONDS, FOOTBALL_OPENING_CHUNKS, type FootballPattern } from './patterns';
export class FootballModel implements GameModel {
  time = 0; score = 0; coins = 0; combo = 0; speed: number = F.forwardSpeed;
  boost = 0; fever = 0; bonus = 0; over = false;
  x = 0; distance: number = -F.introRunway; rotation = 0; sideRotation = 0;
  world: WorldId = 'city'; worldsVisited = 0;
  chunks: Chunk[] = []; events: GameEvent[] = [];
  private random: Random; private director: DifficultyDirector;
  private nextStart = 0; private nextId = 0; private nextObjectId = 0;
  private nextBonus: number = F.firstBonus; private nextBoost = 9;
  private sinceCoin = 10;
  private recentKinds: ChunkKind[] = [];
  private lastChoiceStart = -Infinity;
  private nextChoiceSide = 1;
  private nextWorldAt = 17;
  private lastStarStart = -Infinity;
  private starInterval = 2;
  private lastWorldOptions: WorldId[] = ['city'];
  private previousRow: ChallengeRow = { z: -8, safeX: 0, gap: F.courseWidth };
  private pool: CourseObject[] = [];
  private runRandom: Random; private deck: PatternDeck<FootballPattern>;
  private pattern?: FootballPattern; private patternUntil = 0; private patternChunk = 0; private opening = true;
  private lastCrossingStyle?: CrossingStyle;
  private hardCrossings = 0;
  private nextScrambleAt = 23;
  constructor(seed?: number) {
    const runSeed = seed ?? (Math.random() * 0xffffffff) >>> 0;
    this.random = new Random(OPENING_SEED); this.runRandom = new Random(runSeed);
    this.deck = new PatternDeck(FOOTBALL_PATTERNS, new Random(runSeed ^ 0x51fc));
    this.director = new DifficultyDirector(this.random); this.generate();
  }
  private create = (type: CourseObject['type'], x: number, z: number, width: number, depth: number, height: number): CourseObject => {
    const o = this.pool.pop() ?? {} as CourseObject;
    Object.assign(o, { id: this.nextObjectId++, type, x, baseX: x, z, baseZ:z, width, depth, height, moving: false, amplitude: 0, frequency: 0, phase: this.random.next() * 6.28, passed: false, rewardMultiplier: 1, velocityX: 0,chaotic:false,depthAmplitude:0 });
    return o;
  };
  private generate() {
    while (this.nextStart < this.distance + F.visibleDistance) {
      // Predict arrival time, rather than difficulty at the far-away spawn time.
      const arrivalTime = this.time + Math.max(0, this.nextStart + 13 - this.distance) / this.speed;
      if (this.opening && this.nextStart >= FOOTBALL_OPENING_CHUNKS * F.chunkLength) {
        this.opening = false; this.random = this.runRandom; this.director = new DifficultyDirector(this.random);
      }
      if (!this.opening && (!this.pattern || arrivalTime >= this.patternUntil)) {
        this.pattern = this.deck.next(); this.patternChunk = 0; this.patternUntil = arrivalTime + FOOTBALL_SECTION_SECONDS;
      }
      const tier = this.director.football(arrivalTime, this.bonus > 0);
      let kind: ChunkKind;
      if (this.pattern && tier !== 'easy') {
        const kinds = tier === 'hard' ? this.pattern.hardKinds : this.world !== 'city' && this.patternChunk % 2 === 0 ? WORLDS[this.world].kinds : this.pattern.kinds;
        const ordered = [...kinds.slice(this.patternChunk % kinds.length), ...kinds.slice(0, this.patternChunk % kinds.length)];
        kind = ordered.find(candidate => !this.recentKinds.includes(candidate)) ?? chooseChunkKind(tier, this.random, this.recentKinds);
      } else kind = chooseChunkKind(tier, this.random, this.recentKinds);
      if (arrivalTime >= this.nextBonus) { kind = 'bonusCoin'; this.nextBonus += F.bonusFrequency; }
      else if (arrivalTime >= this.nextBoost) { kind = 'boost'; this.nextBoost += 20; }
      // Follow a large dodge with an open cone phrase so the next demand can be
      // read, rather than stacking a dense wall maze immediately afterwards.
      if (!this.opening && this.recentKinds.at(-1)?.endsWith('Crossing') && kind !== 'bonusCoin' && kind !== 'boost') kind = 'easyCoin';
      if (!this.opening && kind !== 'bonusCoin' && kind !== 'boost' && arrivalTime < this.nextWorldAt && this.nextStart-this.lastStarStart < this.starInterval*F.chunkLength){
        if(arrivalTime>=this.nextScrambleAt){kind='hardScramble';this.nextScrambleAt=arrivalTime+14;}
        else if(this.nextId%2===0)kind=arrivalTime>=F.hardChunkStartTime?'hardCrossing':'mediumCrossing';
      }
      const gap = tier === 'hard' ? F.corridor.hard : F.corridor.normal;
      const crossingTempo = kind.endsWith('Crossing') ? (['quick','hold','late'] as const)[this.nextId%3] : undefined;
      const rows = planRows(this.nextStart, kind, gap, this.previousRow, this.random, this.nextStart < F.chunkLength * F.introChunks,
        this.pattern ? { ...this.pattern.phrase, offset: this.patternChunk } : undefined, this.opening ? F.maxForwardSpeed : this.forecastSpeed(arrivalTime + (kind.endsWith('Crossing')?7:3)),crossingTempo);
      const chunk: Chunk = { id: this.nextId++, start: this.nextStart, kind, safeX: rows.at(-1)!.safeX, gap, rows, objects: [], variant: Math.floor(this.random.next() * 10000), patternId: this.pattern?.id };
      if(kind.endsWith('Crossing'))chunk.length=rows.at(-1)!.z-this.nextStart+5;
      chunk.crossingTempo=crossingTempo;
      if(kind==='hardScramble')chunk.length=34;
      if(kind.endsWith('Crossing')){
        if(kind==='hardCrossing' && this.hardCrossings++%2===0)chunk.variant=2+(chunk.variant!%2);
        if(crossingStyle(chunk)===this.lastCrossingStyle)chunk.variant!+=2;
        this.lastCrossingStyle=crossingStyle(chunk);
      }
      this.patternChunk++;
      if (kind.startsWith('medium') && !kind.endsWith('Crossing') && tier === 'medium' && this.recentKinds.length === 2 && this.recentKinds.every(k => k.startsWith('hard')) && rows.every(r=>Math.abs(r.safeX)+r.gap/2+1.25<F.courseWidth/2)) {
        chunk.recovery = true;
        // Same two obstacle rows, with gentler steering and slightly wider gaps.
        for (let i = rows.length - 2; i < rows.length; i++) {
          rows[i].safeX = rows[i - 1].safeX + (rows[i].safeX - rows[i - 1].safeX) * .5;
          rows[i].gap += .35;
          // Keep both sliding halves on the road when a wide recovery gate is
          // near the edge, including its movement envelope.
          if(kind==='mediumSlidingWalls'){
            const limit=F.courseWidth/2-rows[i].gap/2-.45-.08;
            rows[i].safeX=clamp(rows[i].safeX,-limit,limit);
          }
        }
      }
      const eligible = kind !== 'bonusCoin' && kind !== 'boost' && kind!=='hardScramble' && !kind.endsWith('Crossing') && !chunk.recovery;
      if (this.opening) {
        if (arrivalTime >= 12 && kind.startsWith('medium') && chunk.start - this.lastChoiceStart >= 8 * F.chunkLength) chunk.choice = planChoice(rows, this.previousRow);
      } else if (eligible) {
        // World visits and optional reward forks have independent schedules.
        if (arrivalTime >= this.nextWorldAt) {
          chunk.choice = planWorldChoice(rows, this.previousRow, this.nextChoiceSide);
          if (chunk.choice) {
            chunk.choice.worlds = gateWorlds(chunk.variant!, chunk.id, this.lastWorldOptions);
            this.lastWorldOptions = chunk.choice.worlds;
            this.nextWorldAt = arrivalTime + 13;
          }
        }
        if (!chunk.choice && chunk.start - this.lastStarStart >= this.starInterval * F.chunkLength) {
          chunk.choice = planChoice(rows, this.previousRow, this.nextChoiceSide);
          if (chunk.choice) { this.lastStarStart = chunk.start; this.starInterval = 5 - this.starInterval; }
        }
      }
      if (chunk.choice) {
        this.lastChoiceStart = chunk.start;
        this.nextChoiceSide = chunk.choice.x > rows[1].safeX ? -1 : 1;
      }
      this.previousRow = rows.at(-1)!; chunk.safeX = this.previousRow.safeX;
      this.recentKinds.push(kind); this.recentKinds = this.recentKinds.slice(-2);
      fillChunk(chunk, this.create); this.chunks.push(chunk); this.nextStart += courseChunkLength(chunk);
    }
  }
  private forecastSpeed(time: number) {
    let speed: number = F.forwardSpeed;
    for(let i=0;i<F.difficultyCurve.length-1;i++){
      const a=F.difficultyCurve[i],b=F.difficultyCurve[i+1];
      if(time>=a.at)speed=a.speed+(b.speed-a.speed)*clamp((time-a.at)/(b.at-a.at),0,1);
    }
    return Math.min(F.maxForwardSpeed,speed+2);
  }
  update(dt: number, input: GameInput) {
    if (this.over) return;
    this.time += dt; this.sinceCoin += dt;
    this.boost = Math.max(0, this.boost - dt); this.bonus = Math.max(0, this.bonus - dt);
    if (this.sinceCoin > F.comboWindow) this.combo = 0;
    let base: number = F.forwardSpeed;
    for (let i = 0; i < F.difficultyCurve.length - 1; i++) {
      const a = F.difficultyCurve[i], b = F.difficultyCurve[i + 1];
      if (this.time >= a.at) base = a.speed + (b.speed - a.speed) * clamp((this.time - a.at) / (b.at - a.at), 0, 1);
    }
    this.speed = base * (this.boost > 0 ? F.boostMultiplier : 1);
    const oldX = this.x,oldDistance=this.distance;
    this.x = clamp(this.x + input.axis * F.steeringSensitivity * dt + input.drag * F.dragSensitivity, -F.courseWidth / 2 + F.ballRadius + .08, F.courseWidth / 2 - F.ballRadius - .08);
    this.sideRotation -= (this.x - oldX) / F.ballRadius;
    this.distance += this.speed * dt; this.rotation -= this.speed / F.ballRadius * dt;
    this.score += this.speed * dt * 1.8;
    for (const chunk of this.chunks) {
      if (chunk.kind === 'bonusCoin' && this.distance >= chunk.start && this.distance - this.speed * dt < chunk.start) {
        this.bonus = F.chunkLength / this.speed; this.events.push({ kind: 'bonus' });
      }
      for (const o of chunk.objects) {
        const previousX=o.x,previousZ=o.z;
        if (o.moving) {
          const target=o.baseX+motionOffset(o,this.time,this.x);
          if(o.type==='defender'){
            const desired=clamp((target-o.x)*5,-2.6,2.6);
            const velocity=(o.velocityX??0)+clamp(desired-(o.velocityX??0),-9*dt,9*dt);
            const next=clamp(o.x+velocity*dt,o.baseX-o.amplitude,o.baseX+o.amplitude);
            o.velocityX=dt>0?(next-o.x)/dt:0;o.x=next;
          }else o.x=target;
          if(o.chaotic)o.z=(o.baseZ??o.z)+motionDepthOffset(o,this.time);
        }
        const dz = o.z - this.distance, dx = Math.abs(o.x - this.x);
        if (o.type === 'star' || o.type === 'boost') {
          if (!o.passed && Math.abs(dz) < (o.type === 'boost' ? 1.2 : .85) && dx < (o.type === 'boost' ? o.width / 2 + .3 : .85)) {
            o.passed = true;
            if (o.type === 'boost') { this.boost = F.boostDuration; this.events.push({ kind: 'boost', x: this.x, z: dz }); }
            else {
              this.combo++; this.coins++; this.sinceCoin = 0;
              const points = F.tokenScore * (o.rewardMultiplier ?? 1) * (1 + Math.min(4, Math.floor(this.combo / 8)));
              this.score += points;
              this.events.push({ kind: 'coin', x: o.x, z: dz, value: this.combo, points, reward: o.rewardMultiplier === 2 ? 'double' : undefined });
            }
          }
          continue;
        }
        if (!input.testInvincible && courseSweptCollision(o,oldX,oldDistance,this.x,this.distance,this.time,previousX,previousZ)) {
          this.over = true; this.events.push({ kind: 'over', x: this.x, z: 0 }); return;
        }
        if (!o.passed && dz < -o.depth / 2 - F.ballRadius) {
          o.passed = true;
          const clearance = dx - o.width / 2 - F.ballRadius;
          if (o.type === 'defender') { this.score += 80; this.events.push({ kind: 'dribble', x: this.x, z: 0 }); }
          else if (clearance < .48 && clearance > -.15) { this.score += 60; this.events.push({ kind: 'near', x: this.x, z: 0 }); }
        }
      }
      if (chunk.choice?.worlds && !chunk.choice.resolved && this.distance >= chunk.rows[1].z) {
        chunk.choice.resolved = true;
        const fork = chunk.rows[1], normal = Math.abs(this.x - fork.safeX), alternate = Math.abs(this.x - chunk.choice.x);
        if (this.distance - fork.z < this.speed * dt + .1 && Math.min(normal, alternate) <= chunk.choice.gap / 2) {
          const destination = chunk.choice.worlds[alternate < normal ? 1 : 0];
          if (destination !== this.world) this.worldsVisited++;
          this.world = destination; this.score += 90;
          this.events.push({ kind: 'portal', x: this.x, value: this.worldsVisited });
        }
      }
    }
    while (this.chunks.length && this.chunks[0].start + courseChunkLength(this.chunks[0]) < this.distance - 9) {
      const removed = this.chunks.shift()!;
      for (const o of removed.objects) if (this.pool.length < F.poolSize) this.pool.push(o);
    }
    this.generate();
  }
  get pooledObjects() { return this.pool.length; }
  get routeHint() {
    for (const chunk of this.chunks) {
      if (chunk.choice && chunk.rows[1].z - this.distance > 0 && chunk.rows[1].z - this.distance < 24) return chunk.choice.worlds ? '' : '広い通常ルート ／ 狭い橙ルートはスター得点 ×2';
      if (chunk.recovery && this.distance >= chunk.start + 12 && this.distance < chunk.start + F.chunkLength) return '難所クリア。少し広い通路でスターを回収';
    }
    return '';
  }
  nextChallengeRow(): ChallengeRow {
    for (const chunk of this.chunks) for (const row of chunk.rows) if (row.z + challengeClearance(row) > this.distance) return row;
    return this.previousRow;
  }
}
