import { FOOTBALL as F } from '../../core/config';
import { DifficultyDirector } from '../../core/director';
import { clamp, Random, type GameModel, type GameEvent, type GameInput } from '../../core/types';
import { fillChunk, motionOffset, planRows, type ChallengeRow, type Chunk, type CourseObject, type ChunkKind } from './chunks';
export class FootballModel implements GameModel {
  time = 0; score = 0; coins = 0; combo = 0; speed: number = F.forwardSpeed;
  boost = 0; fever = 0; bonus = 0; over = false;
  x = 0; distance: number = -F.introRunway; rotation = 0; sideRotation = 0;
  chunks: Chunk[] = []; events: GameEvent[] = [];
  private random: Random; private director: DifficultyDirector;
  private nextStart = 0; private nextId = 0; private nextObjectId = 0;
  private nextBonus: number = F.firstBonus; private nextBoost = 9;
  private sinceCoin = 10;
  private previousRow: ChallengeRow = { z: -8, safeX: 0, gap: F.courseWidth };
  private pool: CourseObject[] = [];
  constructor(seed?: number) { this.random = new Random(seed); this.director = new DifficultyDirector(this.random); this.generate(); }
  private create = (type: CourseObject['type'], x: number, z: number, width: number, depth: number, height: number): CourseObject => {
    const o = this.pool.pop() ?? {} as CourseObject;
    Object.assign(o, { id: this.nextObjectId++, type, x, baseX: x, z, width, depth, height, moving: false, amplitude: 0, frequency: 0, phase: this.random.next() * 6.28, passed: false });
    return o;
  };
  private generate() {
    while (this.nextStart < this.distance + F.visibleDistance) {
      // Predict arrival time, rather than difficulty at the far-away spawn time.
      const arrivalTime = this.time + Math.max(0, this.nextStart + 13 - this.distance) / this.speed;
      const tier = this.director.football(arrivalTime, this.bonus > 0);
      let kind: ChunkKind = tier === 'hard' ? this.random.pick(['hardNarrow', 'hardHoles', 'hardSlidingWalls'] as const) : tier === 'medium' ? this.random.pick(['mediumWalls', 'mediumDefender', 'mediumBars', 'mediumSlidingWalls'] as const) : this.random.pick(['easyStraight', 'easyCoin'] as const);
      if (arrivalTime >= this.nextBonus) { kind = 'bonusCoin'; this.nextBonus += F.bonusFrequency; }
      else if (arrivalTime >= this.nextBoost) { kind = 'boost'; this.nextBoost += 20; }
      const gap = tier === 'hard' ? 1.5 : 1.9;
      const rows = planRows(this.nextStart, kind, gap, this.previousRow, this.random, this.nextStart < F.chunkLength * F.introChunks);
      this.previousRow = rows[rows.length - 1];
      const chunk: Chunk = { id: this.nextId++, start: this.nextStart, kind, safeX: this.previousRow.safeX, gap, rows, objects: [] };
      fillChunk(chunk, this.create); this.chunks.push(chunk); this.nextStart += F.chunkLength;
    }
  }
  update(dt: number, input: GameInput) {
    if (this.over) return;
    this.time += dt; this.sinceCoin += dt;
    this.boost = Math.max(0, this.boost - dt); this.bonus = Math.max(0, this.bonus - dt);
    if (this.sinceCoin > F.comboWindow) this.combo = 0;
    let base: number = F.forwardSpeed;
    for (let i = 0; i < F.difficultyCurve.length - 1; i++) {
      const a = F.difficultyCurve[i], b = F.difficultyCurve[i + 1];
      if (this.time >= a.at) base = a.speed + (b.speed - a.speed) * clamp((this.time - a.at) / (b.at - a.at), 0, 1);
    }
    this.speed = base * (this.boost > 0 ? F.boostMultiplier : 1);
    const oldX = this.x;
    this.x = clamp(this.x + input.axis * F.steeringSensitivity * dt + input.drag * F.dragSensitivity, -F.courseWidth / 2 + F.ballRadius + .08, F.courseWidth / 2 - F.ballRadius - .08);
    this.sideRotation -= (this.x - oldX) / F.ballRadius;
    this.distance += this.speed * dt; this.rotation -= this.speed / F.ballRadius * dt;
    this.score += this.speed * dt * 1.8;
    for (const chunk of this.chunks) {
      if (chunk.kind === 'bonusCoin' && this.distance >= chunk.start && this.distance - this.speed * dt < chunk.start) {
        this.bonus = F.chunkLength / this.speed; this.events.push({ kind: 'bonus' });
      }
      for (const o of chunk.objects) {
        if (o.moving) o.x = o.baseX + motionOffset(o, this.time);
        const dz = o.z - this.distance, dx = Math.abs(o.x - this.x);
        if (o.type === 'star' || o.type === 'boost') {
          if (!o.passed && Math.abs(dz) < (o.type === 'boost' ? 1.2 : .85) && dx < (o.type === 'boost' ? o.width / 2 + .3 : .85)) {
            o.passed = true;
            if (o.type === 'boost') { this.boost = F.boostDuration; this.events.push({ kind: 'boost', x: this.x, z: dz }); }
            else {
              this.combo++; this.coins++; this.sinceCoin = 0;
              this.score += F.tokenScore * (1 + Math.min(4, Math.floor(this.combo / 8)));
              this.events.push({ kind: 'coin', x: o.x, z: dz, value: this.combo });
            }
          }
          continue;
        }
        if (Math.abs(dz) < o.depth / 2 + F.ballRadius * .7 && dx < o.width / 2 + F.ballRadius * .78) {
          this.over = true; this.events.push({ kind: 'over', x: this.x, z: 0 }); return;
        }
        if (!o.passed && dz < -o.depth / 2 - F.ballRadius) {
          o.passed = true;
          const clearance = dx - o.width / 2 - F.ballRadius;
          if (o.type === 'defender') { this.score += 80; this.events.push({ kind: 'dribble', x: this.x, z: 0 }); }
          else if (clearance < .48 && clearance > -.15) { this.score += 60; this.events.push({ kind: 'near', x: this.x, z: 0 }); }
        }
      }
    }
    while (this.chunks.length && this.chunks[0].start + F.chunkLength < this.distance - 9) {
      const removed = this.chunks.shift()!;
      for (const o of removed.objects) if (this.pool.length < F.poolSize) this.pool.push(o);
    }
    this.generate();
  }
  get pooledObjects() { return this.pool.length; }
  nextChallengeRow(): ChallengeRow {
    for (const chunk of this.chunks) for (const row of chunk.rows) if (row.z + F.route.rowClearance > this.distance) return row;
    return this.previousRow;
  }
}
