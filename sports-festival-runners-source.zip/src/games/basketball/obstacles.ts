import { BASKETBALL as B } from '../../core/config';
import { Random, clamp } from '../../core/types';
export type ObstacleProfile = 'normal' | 'high' | 'long';
export interface RunnerObstacle {
  type: 'cone' | 'hurdle' | 'dummy' | 'bench' | 'mat';
  profile: ObstacleProfile; width: number; height: number;
}
// Five slightly tighter beats, then a short collection pocket. Average = 1.
export function runnerRhythm(index: number) { return index % 6 === 5 ? 1.2 : .96; }
export function obstacleFor(profile: ObstacleProfile, time: number, baseSpeed: number, random: Random): RunnerObstacle {
  const { normal, high, long } = B.obstacles;
  if (profile === 'high') return {
    type: 'dummy', profile, width: high.width,
    height: Math.round(high.startHeight + Math.min(1, time / 30) * (high.maxHeight - high.startHeight)),
  };
  if (profile === 'long') {
    const type = random.pick(['bench', 'mat'] as const);
    return { type, profile, width: Math.round(clamp(baseSpeed * long.seconds, long.minWidth, long.maxWidth)), height: type === 'mat' ? long.matHeight : long.benchHeight };
  }
  const type = random.pick(['cone', 'hurdle'] as const);
  return { type, profile, width: type === 'cone' ? normal.coneWidth : normal.hurdleWidth, height: type === 'cone' ? normal.coneHeight : normal.hurdleHeight };
}
export function pickObstacle(time: number, baseSpeed: number, random: Random) {
  const profiles: readonly ObstacleProfile[] = time < 6 ? ['normal'] : time < 10 ? ['normal', 'normal', 'high'] : ['normal', 'high', 'long'];
  return obstacleFor(random.pick(profiles), time, baseSpeed, random);
}
