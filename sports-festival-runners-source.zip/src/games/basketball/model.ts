import { BASKETBALL as B } from '../../core/config';
import { DifficultyDirector } from '../../core/director';
import { Random, type GameModel, type GameEvent, type GameInput } from '../../core/types';
import { pickObstacle, type ObstacleProfile } from './obstacles';
export interface RunnerObject {
  id: number; type: 'cone' | 'hurdle' | 'dummy' | 'bench' | 'mat' | 'coin' | 'boost' | 'fever';
  x: number; y: number; width: number; height: number; passed: boolean; minClearance: number;
  profile?: ObstacleProfile;
}
export const isRunnerPickup = (o: RunnerObject) => ['coin', 'boost', 'fever'].includes(o.type);
// Reserve room for the ball and the HIGH/LONG placards, not just the coin sprite.
export function runnerPickupClear(x: number, y: number, objects: readonly RunnerObject[]) {
  return objects.every(o => isRunnerPickup(o) || x < o.x - 34 || x > o.x + o.width + 34 || y < o.y - 34 || y > o.y + o.height + 34);
}
export class BasketballModel implements GameModel {
  time = 0; score = 0; coins = 0; combo = 0; speed: number = B.baseSpeed;
  boost = 0; fever = 0; bonus = 0; over = false;
  y: number = B.ground - B.radius; vy = 0; rotation = 0; distance = 0;
  objects: RunnerObject[] = []; events: GameEvent[] = [];
  private random: Random; private director: DifficultyDirector;
  private obstacleIn = 2.1; private coinIn = .5; private itemIn = 6;
  private nextBonus: number = B.firstBonus; private nextId = 0;
  private sinceCoin = 10; private itemCount = 0; private buffer = 0;
  constructor(seed?: number) { this.random = new Random(seed); this.director = new DifficultyDirector(this.random); }
  private add(type: RunnerObject['type'], x: number, y: number, width = 22, height = 22) {
    if (['coin', 'boost', 'fever'].includes(type) && !runnerPickupClear(x, y, this.objects)) return false;
    // Never accelerate the player into a high obstacle before a jump can rise.
    if ((type === 'boost' || type === 'fever') && this.objects.some(o => !isRunnerPickup(o) && o.x >= x && o.x - x < B.maxSpeed * B.boostMultiplier * .5)) return false;
    if (type === 'coin' && this.objects.some(o => o.type === 'coin' && Math.hypot(o.x - x, o.y - y) < 23)) return false;
    this.objects.push({ id: this.nextId++, type, x, y, width, height, passed: false, minClearance: 999 });
    return true;
  }
  private obstacleCoins(o: RunnerObject, speed: number) {
    const flight = 2 * B.jumpForce / B.gravity;
    const start = o.x + o.width / 2 - speed * flight / 2;
    // This is the real, unaccelerated jump parabola, centred over the obstacle.
    for (let i = 0; i < 7; i++) {
      const t = flight * (.14 + i * .12);
      this.add('coin', start + speed * t, B.ground - B.radius - B.jumpForce * t + .5 * B.gravity * t * t);
    }
  }
  private coinLine(x: number, shape: 'arc' | 'ground' | 'wave', count = 7) {
    for (let i = 0; i < count; i++) {
      const lift = shape === 'arc' ? Math.sin(i / (count - 1) * Math.PI) * 100 : shape === 'wave' ? 14 + Math.sin(i * .8) * 14 : 0;
      this.add('coin', x + i * B.coinSpacing, B.ground - 26 - lift);
    }
  }
  update(dt: number, input: GameInput) {
    if (this.over) return;
    this.time += dt; this.sinceCoin += dt;
    this.boost = Math.max(0, this.boost - dt); this.fever = Math.max(0, this.fever - dt); this.bonus = Math.max(0, this.bonus - dt);
    if (this.sinceCoin > B.comboWindow) this.combo = 0;
    const difficulty = this.director.basketball(this.time);
    const motionRate = this.boost > 0 ? B.boostMultiplier : this.fever > 0 ? B.feverSpeedMultiplier : 1;
    this.speed = difficulty.speed * motionRate;
    this.distance += this.speed * dt;
    this.rotation += Math.min(B.maxVisualRollRate, B.visualRollRate * this.speed / B.baseSpeed) * dt;
    this.score += this.speed * dt / 16 * (this.fever > 0 ? 2 : 1);
    if (input.jump) this.buffer = .09;
    this.buffer -= dt;
    if (this.buffer > 0 && this.y >= B.ground - B.radius - .5) {
      this.vy = -B.jumpForce; this.buffer = 0; this.events.push({ kind: 'jump', x: B.playerX, y: this.y });
    }
    const wasAir = this.y < B.ground - B.radius - .5;
    // BOOST changes horizontal travel only. Takeoff, apex and fall keep their rhythm.
    this.vy += B.gravity * dt; this.y += this.vy * dt;
    if (this.y >= B.ground - B.radius) {
      this.y = B.ground - B.radius; this.vy = 0;
      if (wasAir) this.events.push({ kind: 'land', x: B.playerX, y: B.ground });
    }
    if (this.time >= this.nextBonus) {
      this.nextBonus += B.bonusFrequency; this.bonus = B.bonusDuration;
      this.events.push({ kind: 'bonus' });
      // Sixteen ground coins + eight airborne coins: one easy, satisfying sweep.
      this.coinLine(B.width + 20, 'ground', 16); this.coinLine(B.width + 20 + 17 * B.coinSpacing, 'arc', 8);
      this.obstacleIn = B.bonusDuration + 1;
      if (this.random.next() < .55) this.add('fever', B.width + 26, B.ground - 30);
    }
    this.obstacleIn -= dt; this.coinIn -= dt * motionRate; this.itemIn -= dt;
    if (this.obstacleIn <= 0 && this.bonus <= 0) {
      const { type, width, height, profile } = pickObstacle(this.time, difficulty.speed, this.random);
      this.add(type, B.width + 50, B.ground - height, width, height);
      const obstacle = this.objects[this.objects.length - 1]; obstacle.profile = profile;
      // A newly spawned obstacle must also respect pickups generated earlier.
      this.objects = this.objects.filter(o => !isRunnerPickup(o) || runnerPickupClear(o.x, o.y, this.objects));
      this.obstacleCoins(obstacle, difficulty.speed);
      this.obstacleIn = difficulty.gap * (.94 + this.random.next() * .2);
    }
    if (this.coinIn <= 0 && this.bonus <= 0) { this.coinLine(B.width + 30, this.random.pick(['ground', 'wave'] as const)); this.coinIn = 4.7; }
    if (this.itemIn <= 0 && this.bonus <= 0) {
      const type = this.itemCount % 2 === 0 ? 'boost' : 'fever';
      if (this.add(type, B.width + 30, B.ground - 30)) {
        this.itemCount++; this.itemIn = 10;
        this.obstacleIn = Math.max(this.obstacleIn, 1.35);
      } else this.itemIn = .75;
    }
    for (const o of this.objects) {
      o.x -= this.speed * dt;
      if (['coin', 'boost', 'fever'].includes(o.type)) {
        // Slight attraction makes lines forgiving without changing collision bounds.
        const reach = this.bonus > 0 ? 60 : 37;
        if (Math.hypot(o.x - B.playerX, o.y - this.y) < reach) {
          o.x = -200;
          if (o.type === 'coin') {
            this.coins++; this.combo++; this.sinceCoin = 0;
            this.score += B.coinScore * (1 + Math.min(4, Math.floor(this.combo / 8))) * (this.fever > 0 ? 2 : 1);
            this.events.push({ kind: 'coin', x: B.playerX + 6, y: this.y - 12, value: this.combo });
          } else {
            if (o.type === 'boost') this.boost = B.boostDuration; else this.fever = B.feverDuration;
            this.events.push({ kind: o.type === 'boost' ? 'boost' : 'fever' });
          }
        }
        continue;
      }
      const closestX = Math.max(o.x, Math.min(B.playerX, o.x + o.width));
      const closestY = Math.max(o.y, Math.min(this.y, o.y + o.height));
      const horizontalOverlap = o.x < B.playerX + B.radius && o.x + o.width > B.playerX - B.radius;
      if (horizontalOverlap) o.minClearance = Math.min(o.minClearance, o.y - (this.y + B.radius));
      if (Math.hypot(closestX - B.playerX, closestY - this.y) < B.radius - 4) {
        if (this.fever > 0) {
          this.score += 100; this.events.push({ kind: 'smash', x: o.x + o.width / 2, y: o.y, value: o.width }); o.x = -200;
        } else { this.over = true; this.events.push({ kind: 'over', x: B.playerX, y: this.y }); break; }
      }
      if (!o.passed && o.x + o.width < B.playerX - B.radius) {
        o.passed = true;
        if (this.fever <= 0 && o.minClearance < 18) { this.score += B.nearScore; this.events.push({ kind: 'near', x: B.playerX, y: this.y }); }
        if (this.boost > 0) this.score += 35;
      }
    }
    this.objects = this.objects.filter(o => o.x + o.width > -50);
  }
}
