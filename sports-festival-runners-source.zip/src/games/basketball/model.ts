import { BASKETBALL as B, STEP } from '../../core/config';
import { DifficultyDirector } from '../../core/director';
import { Random, type GameModel, type GameEvent, type GameInput } from '../../core/types';
import { obstacleFor, pickObstacle, runnerRhythm, type ObstacleProfile } from './obstacles';
import { PatternDeck, OPENING_SECONDS, OPENING_SEED } from '../../core/patterns';
import { JUMP_PATTERNS, type JumpPattern } from './patterns';
import { releasedVelocity, SHORT_GUIDE, FULL_GUIDE } from './jump';
export interface RunnerObject {
  id: number; type: 'cone' | 'hurdle' | 'dummy' | 'bench' | 'mat' | 'coin' | 'boost' | 'fever';
  x: number; y: number; width: number; height: number; passed: boolean; minClearance: number;
  profile?: ObstacleProfile;
  guideBefore?: number; guideAfter?: number; guideId?: number;
  landingReward?: boolean;
}
export const isRunnerPickup = (o: RunnerObject) => ['coin', 'boost', 'fever'].includes(o.type);
// Reserve room for the ball and the HIGH/LONG placards, not just the coin sprite.
export function runnerPickupClear(x: number, y: number, objects: readonly RunnerObject[]) {
  return objects.every(o => isRunnerPickup(o) || x < o.x - 34 || x > o.x + o.width + 34 || y < o.y - 34 || y > o.y + o.height + 34);
}
export function runnerGroundCoinClear(x: number, objects: readonly RunnerObject[]) {
  return objects.every(o => isRunnerPickup(o) || x < o.x - (o.guideBefore ?? 40) - 24 || x > o.x + o.width + (o.guideAfter ?? 40) + 24);
}
export class BasketballModel implements GameModel {
  time = 0; score = 0; coins = 0; combo = 0; speed: number = B.baseSpeed;
  boost = 0; fever = 0; bonus = 0; over = false;
  y: number = B.ground - B.radius; vy = 0; rotation = 0; distance = 0;
  objects: RunnerObject[] = []; events: GameEvent[] = [];
  private random: Random; private director: DifficultyDirector;
  private obstacleIn = 2.1; private coinIn = .5; private itemIn = 6;
  private nextBonus: number = B.firstBonus; private nextId = 0;
  private sinceCoin = 10; private itemCount = 0; private buffer = 0;
  private touchFlight = false; private touchElapsed = 0; private touchPressure = 0;
  private obstacleCount = 0;
  private runRandom: Random; private deck: PatternDeck<JumpPattern>;
  private pattern?: JumpPattern; private patternBeat = 0; private opening = true;
  get coursePattern() { return this.pattern?.id ?? 'opening'; }
  constructor(seed?: number) {
    const runSeed = seed ?? (Math.random() * 0xffffffff) >>> 0;
    this.random = new Random(OPENING_SEED); this.runRandom = new Random(runSeed);
    this.deck = new PatternDeck(JUMP_PATTERNS, new Random(runSeed ^ 0x51ba));
    this.director = new DifficultyDirector(this.random);
  }
  private add(type: RunnerObject['type'], x: number, y: number, width = 22, height = 22) {
    if (['coin', 'boost', 'fever'].includes(type) && !runnerPickupClear(x, y, this.objects)) return false;
    // Never accelerate the player into a high obstacle before a jump can rise.
    if (type === 'boost' && this.objects.some(o => !isRunnerPickup(o) && o.x >= x && o.x - x < this.speed * B.boostMultiplier * .5)) return false;
    if (type === 'coin' && this.objects.some(o => o.type === 'coin' && Math.hypot(o.x - x, o.y - y) < 23)) return false;
    if (type === 'coin' && this.objects.some(o => (o.type === 'boost' || o.type === 'fever') && Math.hypot(o.x - x, o.y - y) < 42)) return false;
    if (type === 'boost' || type === 'fever') {
      if (this.objects.some(o => o.type === 'coin' && o.x <= B.width + 12 && Math.hypot(o.x - x, o.y - y) < 42)) return false;
      this.objects = this.objects.filter(o => o.type !== 'coin' || Math.hypot(o.x - x, o.y - y) >= 42);
    }
    this.objects.push({ id: this.nextId++, type, x, y, width, height, passed: false, minClearance: 999 });
    return true;
  }
  private forecastTravel(seconds: number) {
    let distance = 0;
    const cuts = [0, seconds, this.boost, this.fever, ...B.difficultyCurve.map(stage => stage.at - this.time)]
      .filter(t => t >= 0 && t <= seconds).sort((a, b) => a - b);
    // Split at powerup expiry; trapezoids also follow the smooth post-50s ramp.
    for (let i = 1; i < cuts.length; i++) {
      const a = cuts[i - 1], b = cuts[i], mid = (a + b) / 2;
      const multiplier = this.boost > mid ? B.boostMultiplier : this.fever > mid ? B.feverSpeedMultiplier : 1;
      distance += (this.director.basketball(this.time + a).speed + this.director.basketball(this.time + b).speed) / 2 * multiplier * (b - a);
    }
    return distance;
  }
  private obstacleCoins(o: RunnerObject) {
    const guide = o.profile === 'normal' ? SHORT_GUIDE : FULL_GUIDE;
    const { flight, apex } = guide;
    // Place the entire guide offscreen. Account for acceleration and a powerup
    // expiring before the player reaches this obstacle, rather than using spawn speed.
    let lo = 0, hi = 8;
    for (let i = 0; i < 18; i++) {
      const mid = (lo + hi) / 2;
      if (this.forecastTravel(mid) < o.x + o.width / 2 - B.playerX) lo = mid; else hi = mid;
    }
    const jumpAt = Math.max(0, (lo + hi) / 2 - apex);
    o.guideBefore = Math.max(34, o.x - B.playerX - this.forecastTravel(jumpAt));
    o.guideAfter = Math.max(34, B.playerX + this.forecastTravel(jumpAt + flight) - o.x - o.width);
    // Ground coins cannot tell the player to stay low inside a jump corridor.
    // Only not-yet-visible coins are replaced; visible guides never pop out.
    this.objects = this.objects.filter(token => token.type !== 'coin' || token.x <= B.width + 12 ||
      runnerGroundCoinClear(token.x, [o]));
    for (let i = 0; i < 7; i++) {
      const t = flight * (.14 + i * .12);
      const point = guide.points[Math.min(guide.points.length - 1, Math.round(t / STEP))];
      if (this.add('coin', B.playerX + this.forecastTravel(jumpAt + t), B.ground - B.radius - point.height)) {
        this.objects[this.objects.length - 1].guideId = o.id;
      }
    }
    if (o.profile === 'normal') for (const after of [.025, .12]) {
      const x = B.playerX + this.forecastTravel(jumpAt + flight + after);
      if (runnerGroundCoinClear(x, this.objects.filter(other => other.id !== o.id)) && this.add('coin', x, B.ground - B.radius)) this.objects.at(-1)!.landingReward = true;
    }
  }
  private coinLine(x: number, count = 7) {
    for (let i = 0; i < count; i++) {
      const px = x + i * B.coinSpacing;
      if (runnerGroundCoinClear(px, this.objects)) this.add('coin', px, B.ground - B.radius);
    }
  }
  update(dt: number, input: GameInput) {
    if (this.over) return;
    this.time += dt; this.sinceCoin += dt;
    if (this.opening && this.time >= OPENING_SECONDS) { this.opening = false; this.random = this.runRandom; }
    this.boost = Math.max(0, this.boost - dt); this.fever = Math.max(0, this.fever - dt); this.bonus = Math.max(0, this.bonus - dt);
    if (this.sinceCoin > B.comboWindow) this.combo = 0;
    const difficulty = this.director.basketball(this.time);
    const motionRate = this.boost > 0 ? B.boostMultiplier : this.fever > 0 ? B.feverSpeedMultiplier : 1;
    this.speed = difficulty.speed * motionRate;
    this.distance += this.speed * dt;
    this.rotation += Math.min(B.maxVisualRollRate, B.visualRollRate * this.speed / B.baseSpeed) * dt;
    this.score += this.speed * dt / 16 * (this.fever > 0 ? 2 : 1);
    if (input.jump) this.buffer = .09;
    this.buffer -= dt;
    if (this.buffer > 0 && this.y >= B.ground - B.radius - .5) {
      this.touchFlight = !!input.touchJump; this.touchElapsed = 0; this.touchPressure = 0;
      this.vy = -B.jumpForce; this.buffer = 0; this.events.push({ kind: 'jump', x: B.playerX, y: this.y });
    }
    if (this.touchFlight) {
      this.touchPressure = Math.max(this.touchPressure, input.touchJump?.pressure ?? 0);
      if (!input.touchJump?.held) {
        // Launch immediately; an early release trims upward energy once. A firm
        // pressure sample can preserve a high jump even on a very short tap.
        const risen = B.ground - B.radius - this.y;
        this.vy = releasedVelocity(this.vy, risen, this.touchElapsed, this.touchPressure);
        this.touchFlight = false;
      }
      this.touchElapsed += dt;
    }
    const wasAir = this.y < B.ground - B.radius - .5;
    // BOOST changes horizontal travel only. Takeoff, apex and fall keep their rhythm.
    this.vy += B.gravity * dt; this.y += this.vy * dt;
    if (this.y >= B.ground - B.radius) {
      this.y = B.ground - B.radius; this.vy = 0;
      this.touchFlight = false;
      if (wasAir) this.events.push({ kind: 'land', x: B.playerX, y: B.ground });
    }
    if (this.time >= this.nextBonus) {
      this.nextBonus += B.bonusFrequency; this.bonus = B.bonusDuration;
      this.events.push({ kind: 'bonus' });
      // Leave a separate pickup pocket before the grounded bonus line.
      const hasFever = this.random.next() < .55 && this.add('fever', B.width + 26, B.ground - 30);
      this.coinLine(B.width + (hasFever ? 80 : 20), 24);
    }
    this.obstacleIn -= dt; this.coinIn -= dt * motionRate; this.itemIn -= dt;
    if (this.obstacleIn <= 0) {
      if (!this.opening && (!this.pattern || this.patternBeat === this.pattern.beats.length)) {
        this.pattern = this.deck.next(); this.patternBeat = 0;
      }
      const { type, width, height, profile } = this.pattern
        ? obstacleFor(this.pattern.beats[this.patternBeat++], this.time, difficulty.speed, this.random)
        : pickObstacle(this.time, difficulty.speed, this.random);
      const flight = 2 * B.jumpForce / B.gravity;
      const previous = this.objects.filter(o => !isRunnerPickup(o)).at(-1);
      const spawnX = Math.max(B.width + 36 + this.speed * flight * .5,
        previous ? previous.x + previous.width / 2 + this.speed * (flight + .14) - width / 2 : 0);
      this.add(type, spawnX, B.ground - height, width, height);
      const obstacle = this.objects[this.objects.length - 1]; obstacle.profile = profile;
      // A newly spawned obstacle must also respect pickups generated earlier.
      this.objects = this.objects.filter(o => !isRunnerPickup(o) || runnerPickupClear(o.x, o.y, this.objects));
      this.obstacleCoins(obstacle);
      const cadence = this.fever > 0 ? .84 : this.bonus > 0 ? 1.12 : 1;
      const rhythm = this.time < 10 ? 1 : runnerRhythm(this.obstacleCount++);
      this.obstacleIn = Math.max(B.endless.minGap, difficulty.gap * cadence * rhythm * (.96 + this.random.next() * .1));
    }
    if (this.coinIn <= 0 && this.bonus <= 0) { this.coinLine(B.width + 30, 5); this.coinIn = 4.7; }
    if (this.itemIn <= 0 && this.bonus <= 0) {
      const type = this.itemCount % 2 === 0 ? 'boost' : 'fever';
      if (this.add(type, B.width + 30, B.ground - 30)) {
        this.itemCount++; this.itemIn = 10;
        if (type === 'boost') this.obstacleIn = Math.max(this.obstacleIn, 1.15);
      } else this.itemIn = .75;
    }
    for (const o of this.objects) {
      o.x -= this.speed * dt;
      if (['coin', 'boost', 'fever'].includes(o.type)) {
        // Slight attraction makes lines forgiving without changing collision bounds.
        const reach = this.bonus > 0 ? 60 : 37;
        if (Math.hypot(o.x - B.playerX, o.y - this.y) < reach) {
          o.x = -200;
          if (o.type === 'coin') {
            this.coins++; this.combo++; this.sinceCoin = 0;
            const points = B.coinScore * (o.landingReward ? B.landingCoinMultiplier : 1) * (1 + Math.min(4, Math.floor(this.combo / 8))) * (this.fever > 0 ? 2 : 1);
            this.score += points;
            this.events.push({ kind: 'coin', x: B.playerX + 6, y: this.y - 12, value: this.combo, points, reward: o.landingReward ? 'landing' : undefined });
          } else {
            if (o.type === 'boost') this.boost = B.boostDuration; else this.fever = B.feverDuration;
            this.events.push({ kind: o.type === 'boost' ? 'boost' : 'fever' });
          }
        }
        continue;
      }
      const closestX = Math.max(o.x, Math.min(B.playerX, o.x + o.width));
      const closestY = Math.max(o.y, Math.min(this.y, o.y + o.height));
      const horizontalOverlap = o.x < B.playerX + B.radius && o.x + o.width > B.playerX - B.radius;
      if (horizontalOverlap) o.minClearance = Math.min(o.minClearance, o.y - (this.y + B.radius));
      if (Math.hypot(closestX - B.playerX, closestY - this.y) < B.radius - 4) {
        if (this.fever > 0) {
          this.score += 100; this.events.push({ kind: 'smash', x: o.x + o.width / 2, y: o.y, value: o.width }); o.x = -200;
        } else if (!input.testInvincible) { this.over = true; this.events.push({ kind: 'over', x: B.playerX, y: this.y }); break; }
      }
      if (!o.passed && o.x + o.width < B.playerX - B.radius) {
        o.passed = true;
        if (this.fever <= 0 && o.minClearance < 18) { this.score += B.nearScore; this.events.push({ kind: 'near', x: B.playerX, y: this.y }); }
        if (this.boost > 0) this.score += 35;
      }
    }
    this.objects = this.objects.filter(o => o.x + o.width > -50);
  }
  get routeHint() {
    return this.objects.some(o => o.landingReward && o.x > B.playerX + 25 && o.x < B.width - 10)
      ? '低めに跳ぶ → 早く着地 → ミントのコインを回収' : '';
  }
}
