import {GiantPower,GIANT} from './giant';
import { BASKETBALL as B, STEP } from '../../core/config';
import { DifficultyDirector } from '../../core/director';
import { Random, type GameModel, type GameEvent, type GameInput } from '../../core/types';
import { obstacleFor, pickObstacle, runnerRhythm, type ObstacleProfile } from './obstacles';
import { PatternDeck, OPENING_SECONDS, OPENING_SEED } from '../../core/patterns';
import { JUMP_PATTERNS, type JumpPattern } from './patterns';
import { releasedVelocity, SHORT_GUIDE, FULL_GUIDE, jumpGuide } from './jump';
const TAP_GUIDE = jumpGuide(.025);
export interface RunnerObject {
  id: number; type: 'cone' | 'hurdle' | 'dummy' | 'bench' | 'mat' | 'beam' | 'coin' | 'boost' | 'fever';
  x: number; y: number; width: number; height: number; passed: boolean; minClearance: number;
  profile?: ObstacleProfile;
  guideBefore?: number; guideAfter?: number; guideId?: number;
  landingReward?: boolean;
  tapOnly?: boolean;
  clusterParent?:number;
}
export const isRunnerPickup = (o: RunnerObject) => ['coin', 'boost', 'fever'].includes(o.type);
// Reserve room for the ball and the HIGH/LONG placards, not just the coin sprite.
export function runnerPickupClear(x: number, y: number, objects: readonly RunnerObject[]) {
  return objects.every(o => isRunnerPickup(o) || x < o.x - 34 || x > o.x + o.width + 34 || y < o.y - 34 || y > o.y + o.height + 34);
}
export function runnerGroundCoinClear(x: number, objects: readonly RunnerObject[]) {
  return objects.every(o => isRunnerPickup(o) || x < o.x - (o.guideBefore ?? 40) - 24 || x > o.x + o.width + (o.guideAfter ?? 40) + 24);
}
export class BasketballModel implements GameModel {
  time = 0; score = 0; coins = 0; combo = 0; speed: number = B.baseSpeed;
  boost = 0; fever = 0; bonus = 0; over = false;
  y: number = B.ground - B.radius; vy = 0; rotation = 0; distance = 0;
  objects: RunnerObject[] = []; events: GameEvent[] = [];
  private random: Random; private director: DifficultyDirector;
  private obstacleIn = 2.1; private coinIn = .5; private itemIn = 6;
  private nextBonus: number = B.firstBonus; private nextId = 0;
  private sinceCoin = 10; private itemCount = 0; private buffer = 0;
  private golden=false; private giant=new GiantPower(); private giantForecast?:number[];
  setGolden(enabled:boolean){this.golden=enabled;if(!enabled)this.giant.reset();}
  get giantScale(){return this.giant.scale;}
  get giantRecovery(){return this.giant.recovering;}
  get giantAura(){return this.giant.aura;}
  get giantActive(){return this.golden&&this.giant.engaged;}
  private get bodyRadius(){return B.radius*this.giantScale;}
  private get bodyY(){return this.y-(this.bodyRadius-B.radius);}
  private touchFlight = false; private touchElapsed = 0; private touchPressure = 0;
  private bufferedShort = false;
  private obstacleCount = 0;
  private runRandom: Random; private deck: PatternDeck<JumpPattern>;
  private pattern?: JumpPattern; private patternBeat = 0; private opening = true;
  get coursePattern() { return this.pattern?.id ?? 'opening'; }
  constructor(seed?: number) {
    const runSeed = seed ?? (Math.random() * 0xffffffff) >>> 0;
    this.random = new Random(OPENING_SEED); this.runRandom = new Random(runSeed);
    this.deck = new PatternDeck(JUMP_PATTERNS, new Random(runSeed ^ 0x51ba));
    this.director = new DifficultyDirector(this.random);
  }
  private add(type: RunnerObject['type'], x: number, y: number, width = 22, height = 22) {
    if(this.golden&&type==='boost'){
      const tail=Math.max(B.playerX,...this.objects.filter(o=>!isRunnerPickup(o)).map(o=>o.x+o.width));
      x=Math.max(x,tail+this.forecastTravel(.5));
    }
    // A new speed pickup inside a tap phrase would invalidate its timed gaps.
    // Existing boosts are forecast through expiry before the phrase is placed.
    if ((type === 'boost' || type === 'fever') && this.objects.some(o => o.tapOnly && o.x + o.width > B.playerX - B.radius)) return false;
    if (['coin', 'boost', 'fever'].includes(type) && !runnerPickupClear(x, y, this.objects)) return false;
    // Never accelerate the player into a high obstacle before a jump can rise.
    if (type === 'boost' && this.objects.some(o => !isRunnerPickup(o) && o.x >= x && o.x - x < this.speed * B.boostMultiplier * .5)) return false;
    if (type === 'coin' && this.objects.some(o => o.type === 'coin' && Math.hypot(o.x - x, o.y - y) < 23)) return false;
    if (type === 'coin' && this.objects.some(o => (o.type === 'boost' || o.type === 'fever') && Math.hypot(o.x - x, o.y - y) < 42)) return false;
    if (type === 'boost' || type === 'fever') {
      if (this.objects.some(o => o.type === 'coin' && o.x <= B.width + 12 && Math.hypot(o.x - x, o.y - y) < 42)) return false;
      this.objects = this.objects.filter(o => o.type !== 'coin' || Math.hypot(o.x - x, o.y - y) >= 42);
    }
    this.objects.push({ id: this.nextId++, type, x, y, width, height, passed: false, minClearance: 999 });
    return true;
  }
  private forecastTravel(seconds: number) {
    const pendingBoost=this.golden?this.objects.find(o=>o.type==='boost'&&o.x>B.playerX):undefined;
    if(this.giantActive||pendingBoost){
      if(!this.giantForecast){
        const curve=[0],power=this.giant.clone();let y=this.y,vy=this.vy,fever=this.fever,boost=this.boost,taken=false;
        for(let i=1;i<=Math.ceil(16/STEP);i++){
          fever=Math.max(0,fever-STEP);boost=Math.max(0,boost-STEP);
          power.advance(STEP,fever>0,boost>0?B.boostMultiplier:fever>0?B.feverSpeedMultiplier:1,y>=B.ground-B.radius-.5);
          vy+=B.gravity*STEP;y+=vy*STEP;if(y>=B.ground-B.radius){y=B.ground-B.radius;vy=0;}
          curve.push(curve[i-1]+this.director.basketball(this.time+i*STEP).speed*power.speedFactor*STEP);
          if(pendingBoost&&!taken){
            const radius=B.radius*power.scale,bodyY=y-(radius-B.radius),reach=power.engaged?Math.max(37,radius+9):37;
            if(Math.hypot(pendingBoost.x-B.playerX-curve[i],pendingBoost.y-bodyY)<reach){boost=B.boostDuration;taken=true;}
          }
          if(power.ready&&boost<=0&&y>=B.ground-B.radius-.5)power.finish();
        }
        this.giantForecast=curve;
      }
      const t=Math.max(0,Math.min(16,seconds))/STEP,i=Math.floor(t),a=this.giantForecast[i];
      return a+(this.giantForecast[Math.min(i+1,this.giantForecast.length-1)]-a)*(t-i);
    }
    let distance = 0;
    const cuts = [0, seconds, this.boost, this.fever, ...B.difficultyCurve.map(stage => stage.at - this.time)]
      .filter(t => t >= 0 && t <= seconds).sort((a, b) => a - b);
    // Split at powerup expiry; trapezoids also follow the smooth post-50s ramp.
    for (let i = 1; i < cuts.length; i++) {
      const a = cuts[i - 1], b = cuts[i], mid = (a + b) / 2;
      const multiplier = this.boost > mid ? B.boostMultiplier : this.fever > mid ? B.feverSpeedMultiplier : 1;
      distance += (this.director.basketball(this.time + a).speed + this.director.basketball(this.time + b).speed) / 2 * multiplier * (b - a);
    }
    return distance;
  }
  private obstacleCoins(o: RunnerObject) {
    const guide = o.profile === 'normal' ? SHORT_GUIDE : FULL_GUIDE;
    const { flight, apex } = guide;
    // Place the entire guide offscreen. Account for acceleration and a powerup
    // expiring before the player reaches this obstacle, rather than using spawn speed.
    let lo = 0, hi = 8;
    for (let i = 0; i < 18; i++) {
      const mid = (lo + hi) / 2;
      if (this.forecastTravel(mid) < o.x + o.width / 2 - B.playerX) lo = mid; else hi = mid;
    }
    const jumpAt = Math.max(0, (lo + hi) / 2 - apex);
    o.guideBefore = Math.max(34, o.x - B.playerX - this.forecastTravel(jumpAt));
    o.guideAfter = Math.max(34, B.playerX + this.forecastTravel(jumpAt + flight) - o.x - o.width);
    // Ground coins cannot tell the player to stay low inside a jump corridor.
    // Only not-yet-visible coins are replaced; visible guides never pop out.
    this.objects = this.objects.filter(token => token.type !== 'coin' || token.x <= B.width + 12 ||
      runnerGroundCoinClear(token.x, [o]));
    for (let i = 0; i < 7; i++) {
      const t = flight * (.14 + i * .12);
      const point = guide.points[Math.min(guide.points.length - 1, Math.round(t / STEP))];
      if (this.add('coin', B.playerX + this.forecastTravel(jumpAt + t), B.ground - B.radius - point.height)) {
        this.objects[this.objects.length - 1].guideId = o.id;
      }
    }
    if (o.profile === 'normal') for (const after of [.025, .12]) {
      const x = B.playerX + this.forecastTravel(jumpAt + flight + after);
      if (runnerGroundCoinClear(x, this.objects.filter(other => other.id !== o.id)) && this.add('coin', x, B.ground - B.radius)) this.objects.at(-1)!.landingReward = true;
    }
  }
  private coinLine(x: number, count = 7) {
    for (let i = 0; i < count; i++) {
      const px = x + i * B.coinSpacing;
      if (runnerGroundCoinClear(px, this.objects)) this.add('coin', px, B.ground - B.radius);
    }
  }
  private staccato(pattern: JumpPattern) {
    const recipe = pattern.staccato!;
    const previous = this.objects.filter(o => !isRunnerPickup(o) && o.type !== 'beam' && o.clusterParent===undefined).at(-1);
    const firstDistance = Math.max(B.width + 80 + this.forecastTravel(.35) - B.playerX,
      previous ? previous.x + previous.width / 2 - B.playerX + this.forecastTravel(this.golden?.86:1.05) : 0);
    let lo = 0, hi = 12;
    for (let i=0;i<22;i++) { const mid=(lo+hi)/2; if(this.forecastTravel(mid)<firstDistance)lo=mid;else hi=mid; }
    const firstAt=(lo+hi)/2, arrivals=[firstAt];
    for(const gap of recipe.gaps) arrivals.push(arrivals.at(-1)!+gap);
    const centers=arrivals.map(at=>B.playerX+this.forecastTravel(at));
    const railStart=B.playerX+this.forecastTravel(Math.max(0,firstAt-.32));
    const railEnd=B.playerX+this.forecastTravel(arrivals.at(-1)!+.34);
    this.add('beam',railStart,B.ground-164,railEnd-railStart,20);
    this.objects.at(-1)!.tapOnly=true;
    const hurdles:RunnerObject[]=[];
    for(const x of centers) {
      this.add('hurdle',x-recipe.width/2,B.ground-recipe.height,recipe.width,recipe.height);
      const o=this.objects.at(-1)!;o.tapOnly=true;hurdles.push(o);
    }
    this.objects=this.objects.filter(o=>!isRunnerPickup(o)||runnerPickupClear(o.x,o.y,this.objects));
    for(let i=0;i<arrivals.length;i++) {
      const launch=arrivals[i]-TAP_GUIDE.apex;
      for(const fraction of [.28,.5,.72]) {
        const t=TAP_GUIDE.flight*fraction;
        const point=TAP_GUIDE.points[Math.round(t/STEP)];
        if(this.add('coin',B.playerX+this.forecastTravel(launch+t),B.ground-B.radius-point.height)) this.objects.at(-1)!.guideId=hurdles[i].id;
      }
      const x=B.playerX+this.forecastTravel(launch+TAP_GUIDE.flight+.025);
      if(this.add('coin',x,B.ground-B.radius)) this.objects.at(-1)!.landingReward=true;
    }
    this.patternBeat=pattern.beats.length;
    this.obstacleIn=arrivals.at(-1)!-firstAt+(this.golden?.86:1.05);
  }
  update(dt: number, input: GameInput) {
    if (this.over) return;
    this.time += dt; this.sinceCoin += dt; this.giantForecast=undefined;
    if (this.opening && this.time >= OPENING_SECONDS) { this.opening = false; this.random = this.runRandom; }
    this.boost = Math.max(0, this.boost - dt); this.fever = Math.max(0, this.fever - dt); this.bonus = Math.max(0, this.bonus - dt);
    if (this.sinceCoin > B.comboWindow) this.combo = 0;
    const difficulty = this.director.basketball(this.time);
    const rawRate = this.boost > 0 ? B.boostMultiplier : this.fever > 0 ? B.feverSpeedMultiplier : 1;
    const change=this.giant.advance(dt,this.golden&&this.fever>0,rawRate,this.y>=B.ground-B.radius-.5);
    if(change.started)this.events.push({kind:'giant',x:B.playerX,y:this.bodyY});
    if(change.ending)this.events.push({kind:'giantEnd',x:B.playerX,y:B.ground});
    const motionRate = this.giantActive?this.giant.speedFactor:rawRate;
    this.speed = difficulty.speed * motionRate;
    this.distance += this.speed * dt;
    this.rotation += Math.min(B.maxVisualRollRate, B.visualRollRate * this.speed / B.baseSpeed) * dt;
    this.score += this.speed * dt / 16 * (this.fever > 0 ? 2 : 1);
    if (input.jump) { this.buffer = .09; this.bufferedShort = !!input.shortJump; }
    this.buffer -= dt;
    if (this.buffer > 0 && this.y >= B.ground - B.radius - .5) {
      this.touchFlight = !!input.touchJump || this.bufferedShort; this.touchElapsed = 0; this.touchPressure = 0;
      this.vy = -B.jumpForce; this.buffer = 0; this.events.push({ kind: 'jump', x: B.playerX, y: this.y });
      if (this.bufferedShort) { this.vy = releasedVelocity(this.vy,0,0); this.touchFlight=false; }
    }
    if (this.touchFlight) {
      this.touchPressure = Math.max(this.touchPressure, input.touchJump?.pressure ?? 0);
      if (!input.touchJump?.held) {
        // Launch immediately; an early release trims upward energy once. A firm
        // pressure sample can preserve a high jump even on a very short tap.
        const risen = B.ground - B.radius - this.y;
        this.vy = releasedVelocity(this.vy, risen, this.touchElapsed, this.touchPressure);
        this.touchFlight = false;
      }
      this.touchElapsed += dt;
    }
    const wasAir = this.y < B.ground - B.radius - .5;
    // BOOST changes horizontal travel only. Takeoff, apex and fall keep their rhythm.
    this.vy += B.gravity * dt; this.y += this.vy * dt;
    if (this.y >= B.ground - B.radius) {
      this.y = B.ground - B.radius; this.vy = 0;
      this.touchFlight = false;
      if (wasAir) this.events.push({ kind: 'land', x: B.playerX, y: B.ground });
    }
    if (this.time >= this.nextBonus) {
      this.nextBonus += B.bonusFrequency; this.bonus = B.bonusDuration;
      this.events.push({ kind: 'bonus' });
      // Leave a separate pickup pocket before the grounded bonus line.
      const hasFever = this.random.next() < .55 && this.add('fever', B.width + 26, B.ground - 30);
      this.coinLine(B.width + (hasFever ? 80 : 20), 24);
    }
    this.obstacleIn -= dt; this.coinIn -= dt * motionRate; this.itemIn -= dt;
    if (this.obstacleIn <= 0) {
      if (!this.opening && (!this.pattern || this.patternBeat === this.pattern.beats.length)) {
        this.pattern = this.deck.next(); this.patternBeat = 0;
      }
      if (this.pattern?.staccato && !this.giantActive && !this.objects.some(o => (o.type === 'boost' || o.type === 'fever') && o.x > B.playerX - 45)) {
        this.staccato(this.pattern);
      } else {
      const waitingTap = !!this.pattern?.staccato;
      const { type, width, height, profile } = this.pattern
        ? obstacleFor(waitingTap ? 'normal' : this.pattern.beats[this.patternBeat++], this.time, difficulty.speed, this.random)
        : pickObstacle(this.time, difficulty.speed, this.random);
      const flight = 2 * B.jumpForce / B.gravity;
      const previous = this.objects.filter(o => !isRunnerPickup(o) && o.type !== 'beam' && o.clusterParent===undefined).at(-1);
      const pendingBoost=this.golden?this.objects.find(o=>o.type==='boost'&&o.x>B.playerX):undefined;
      const planningSpeed=pendingBoost?difficulty.speed*B.boostMultiplier:this.speed;
      const spawnX = Math.max(B.width + 36 + planningSpeed * flight * .5,
        pendingBoost?pendingBoost.x+planningSpeed*.7:0,
        previous ? previous.x + previous.width / 2 + planningSpeed * (flight + (this.golden?.09:.14)) - width / 2 : 0);
      this.add(type, spawnX, B.ground - height, width, height);
      const obstacle = this.objects[this.objects.length - 1]; obstacle.profile = profile;
      if(this.golden&&profile==='normal'&&!waitingTap){
        const center=obstacle.x+obstacle.width/2+this.forecastTravel(.16);
        this.add('hurdle',center-11,B.ground-24,22,24);
        const buddy=this.objects.at(-1)!;buddy.profile='normal';buddy.clusterParent=obstacle.id;
      }
      // A newly spawned obstacle must also respect pickups generated earlier.
      this.objects = this.objects.filter(o => !isRunnerPickup(o) || runnerPickupClear(o.x, o.y, this.objects));
      this.obstacleCoins(obstacle);
      const cadence = this.fever > 0 ? .84 : this.bonus > 0 ? 1.12 : 1;
      const rhythm = this.time < 10 || waitingTap ? 1 : this.pattern ? this.pattern.cadence[this.patternBeat - 1] : runnerRhythm(this.obstacleCount++);
      this.obstacleIn = Math.max(this.golden?.74:B.endless.minGap, difficulty.gap * cadence * rhythm * (this.golden&&this.time>=5?.76:1) * (.96 + this.random.next() * .1));
      }
    }
    if (this.coinIn <= 0 && this.bonus <= 0) { this.coinLine(B.width + 30, 5); this.coinIn = 4.7; }
    if (this.itemIn <= 0 && this.bonus <= 0) {
      const type = this.itemCount % 2 === 0 ? 'boost' : 'fever';
      if (this.add(type, B.width + 30, B.ground - 30)) {
        this.itemCount++; this.itemIn = 10;
        if (type === 'boost') this.obstacleIn = Math.max(this.obstacleIn, 1.15);
      } else this.itemIn = .75;
    }
    for (const o of this.objects) {
      o.x -= this.speed * dt;
      if (['coin', 'boost', 'fever'].includes(o.type)) {
        // Slight attraction makes lines forgiving without changing collision bounds.
        const reach = this.giantActive?Math.max(this.bonus>0?60:37,this.bodyRadius+9):this.bonus>0?60:37;
        if (Math.hypot(o.x - B.playerX, o.y - (this.giantActive?this.bodyY:this.y)) < reach) {
          o.x = -200;
          if (o.type === 'coin') {
            this.coins++; this.combo++; this.sinceCoin = 0;
            const points = B.coinScore * (o.landingReward ? B.landingCoinMultiplier : 1) * (1 + Math.min(4, Math.floor(this.combo / 8))) * (this.fever > 0 ? 2 : 1);
            this.score += points;
            this.events.push({ kind: 'coin', x: B.playerX + 6, y: this.y - 12, value: this.combo, points, reward: o.landingReward ? 'landing' : undefined });
          } else {
            if (o.type === 'boost') this.boost = B.boostDuration; else this.fever = B.feverDuration;
            this.events.push({ kind: o.type === 'boost' ? 'boost' : 'fever' });
          }
        }
        continue;
      }
      const closestX = Math.max(o.x, Math.min(B.playerX, o.x + o.width));
      const closestY = Math.max(o.y, Math.min(this.giantActive?this.bodyY:this.y, o.y + o.height));
      const horizontalOverlap = o.x < B.playerX + B.radius && o.x + o.width > B.playerX - B.radius;
      if (horizontalOverlap && o.type !== 'beam') o.minClearance = Math.min(o.minClearance, o.y - (this.y + B.radius));
      if (Math.hypot(closestX-B.playerX,closestY-(this.giantActive?this.bodyY:this.y)) < (this.giantActive?this.bodyRadius-3:B.radius-4)) {
        if (this.fever > 0 || this.giantActive) {
          const points=this.fever>0?100:0;this.score+=points;
          this.events.push({kind:'smash',x:this.giantActive?closestX:o.x+o.width/2,y:this.giantActive?closestY:o.y,value:o.width,points});o.x=-o.width-200;
        } else if (!input.testInvincible) { this.over = true; this.events.push({ kind: 'over', x: B.playerX, y: this.y }); break; }
      }
      if (!o.passed && o.x + o.width < B.playerX - B.radius) {
        o.passed = true;
        if (this.fever <= 0 && !this.giantActive && o.minClearance < 18) { this.score += B.nearScore; this.events.push({ kind: 'near', x: B.playerX, y: this.y }); }
        if (this.boost > 0) this.score += 35;
      }
    }
    if(this.giant.ready&&this.boost<=0&&this.y>=B.ground-B.radius-.5){
      // Remove only the immediate handoff corridor. No bonus points for safety clearing.
      const horizon=B.playerX+B.radius+this.speed*GIANT.reaction;
      for(const o of this.objects)if(!isRunnerPickup(o)&&o.x<horizon&&o.x+o.width>B.playerX-B.radius){
        if(o.x<B.width+40)this.events.push({kind:'smash',x:o.x+o.width/2,y:o.y,value:o.width,points:0});o.x=-o.width-200;
      }
      this.obstacleIn=Math.max(this.obstacleIn,GIANT.reaction);this.giant.finish();
    }
    this.objects = this.objects.filter(o => o.x + o.width > -50);
  }
  get routeHint() {
    return this.objects.some(o => o.landingReward && o.x > B.playerX + 25 && o.x < B.width - 10)
      ? '低めに跳ぶ → 早く着地 → ミントのコインを回収' : '';
  }
}

