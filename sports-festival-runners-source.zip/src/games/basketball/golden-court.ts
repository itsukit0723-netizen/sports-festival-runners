import { BASKETBALL as B } from '../../core/config';

/** Cached arena architecture. Only lighting and the court surface animate. */
export class GoldenCourt {
  private plate = document.createElement('canvas');
  constructor() {
    this.plate.width=840; this.plate.height=1200;
    const c=this.plate.getContext('2d')!; c.scale(2,2);
    const rect=(x:number,y:number,w:number,h:number,fill:string)=>{c.fillStyle=fill;c.fillRect(x,y,w,h);};
    const line=(x:number,y:number,x2:number,y2:number,color:string,width=1)=>{c.strokeStyle=color;c.lineWidth=width;c.beginPath();c.moveTo(x,y);c.lineTo(x2,y2);c.stroke();};
    const gold=c.createLinearGradient(0,0,420,0); gold.addColorStop(0,'#98713d');gold.addColorStop(.4,'#fff0bc');gold.addColorStop(.65,'#d6a651');gold.addColorStop(1,'#8c6037');
    const sky=c.createLinearGradient(0,0,0,584);sky.addColorStop(0,'#080f24');sky.addColorStop(.6,'#20223c');sky.addColorStop(1,'#3d2940');c.fillStyle=sky;c.fillRect(0,0,420,600);
    // Sweeping elliptical roof, double trusses, and hanging light banks.
    for(let row=0;row<6;row++) {
      const cy=140+row*18,rx=290-row*8,ry=115-row*8;
      c.strokeStyle=row%2?'#dec38c':'#4a4559';c.lineWidth=row%2?1.2:4;
      c.beginPath();c.ellipse(210,cy,rx,ry,0,Math.PI,Math.PI*2);c.stroke();
    }
    for(let i=-2;i<12;i++) {
      const x=i*43;line(210,12,x,210,'#9d855554');
      for(let j=0;j<3;j++)rect(x+j*6,161+Math.abs(x-210)*.075,4,3,'#fff3cd');
    }
    // Two luxury boxes flank the suspended four-sided finals scoreboard.
    for(const side of [-1,1]) {
      const x=side<0?8:332;
      rect(x,220,80,97,'#11182c');rect(x,220,80,3,'#ad8954');
      for(let i=0;i<4;i++){rect(x+4+i*19,229,15,66,'#32404c');rect(x+5+i*19,231,3,60,'#ffe2a21a');}
      rect(x,303,80,14,'#1d2337');line(x,303,x+80,303,'#d9b276');
      c.fillStyle='#e3bd80';c.font='6px sans-serif';c.textAlign='center';c.fillText('FESTIVAL • ROYAL BOX',x+40,313);
    }
    line(161,40,161,193,'#78747a',2);line(259,40,259,193,'#78747a',2);
    c.fillStyle=gold;c.beginPath();c.roundRect(116,190,188,116,9);c.fill();
    rect(120,196,180,104,'#0b1529');rect(126,201,168,18,'#263146');
    c.textAlign='center';c.fillStyle='#f7d995';c.font='bold 9px sans-serif';c.fillText('THE GOLDEN FINALS',210,213);
    c.font='bold 28px sans-serif';c.fillStyle='#fff2cd';c.fillText('CROWN',210,249);
    c.font='bold 19px sans-serif';c.fillText('ARENA',210,273);
    c.font='8px sans-serif';c.fillStyle='#a6b7cf';c.fillText('SPORTS FESTIVAL   ✦   CHAMPIONSHIP',210,290);
    // A sculpted cup with metallic shading at each end of the scoreboard.
    for(const x of [103,317]) {
      const cup=c.createLinearGradient(x-15,0,x+15,0);cup.addColorStop(0,'#98703e');cup.addColorStop(.45,'#fff0b7');cup.addColorStop(1,'#b78143');
      c.fillStyle=cup;c.beginPath();c.moveTo(x-12,275);c.bezierCurveTo(x-12,296,x-4,298,x-3,303);c.lineTo(x+3,303);c.bezierCurveTo(x+4,298,x+12,296,x+12,275);c.closePath();c.fill();
      c.strokeStyle='#e4c485';c.lineWidth=3;for(const s of [-1,1]){c.beginPath();c.ellipse(x+s*12,284,7,9,0,0,Math.PI*2);c.stroke();}
      rect(x-2,300,4,10,'#e7c477');rect(x-10,309,20,4,'#eed59f');rect(x-13,314,26,8,'#182237');
    }
    // Six raked spectator tiers: individual heads, jersey shoulders, rails.
    for(let row=0;row<7;row++) {
      const y=328+row*27;rect(0,y,420,25,row%2?'#1d263c':'#141c30');
      for(let i=0;i<49;i++) {
        const x=i*9+(row%2)*4;
        c.fillStyle=['#6c506a','#bc9a73','#9c83a5','#7a927f','#3b5368'][(i*7+row*3)%5];
        c.beginPath();c.arc(x,y+9,2.3,0,Math.PI*2);c.fill();
        rect(x-3,y+12,6,5,['#35415c','#967143','#635678'][(i+row)%3]);
        if((i*13+row)%11===0)rect(x,y+4,1.4,2.5,'#fff0bc');
      }
      line(0,y+23,420,y+23,'#bc94566b');
    }
    // Glass backboards and real suspended hoops, deliberately behind the course.
    for(const x of [32,388]) {
      rect(x-2,365,4,128,'#5c5864');rect(x-25,353,50,36,'#b9d6ee20');
      c.strokeStyle='#cad9e9';c.lineWidth=1.2;c.strokeRect(x-25,353,50,36);c.strokeRect(x-10,366,20,16);
      c.strokeStyle='#f7ad59';c.lineWidth=2;c.beginPath();c.ellipse(x,389,14,4,0,0,Math.PI*2);c.stroke();
      for(let i=-3;i<=3;i++) {line(x+i*4,390,x+i*2.5,410,'#d4d9e9a0');line(x+i*4,390,x-i*2.5,410,'#d4d9e980');}
    }
    rect(0,522,420,46,'#141c30');rect(0,522,420,2,'#e8c88a');rect(0,563,420,5,'#85633b');
    for(let i=0;i<7;i++){rect(i*62+3,531,56,23,'#283044');c.fillStyle='#edce93';c.font='bold 9px sans-serif';c.fillText(i%2?'✦ FINALS ✦':'GOLDEN',i*62+31,546);}
  }
  render(c:CanvasRenderingContext2D,time:number,distance:number,top:number,height:number,reduced:boolean) {
    c.fillStyle='#080f24';c.fillRect(0,top,420,height);c.drawImage(this.plate,0,0,420,600);
    const t=reduced?0:time;
    for(let i=0;i<4;i++) {
      const x=30+i*120,sway=Math.sin(t*.25+i*1.7)*35;
      const beam=c.createLinearGradient(x,175,x,510);beam.addColorStop(0,'#fff4d42b');beam.addColorStop(1,'#fff0bf00');
      c.fillStyle=beam;c.beginPath();c.moveTo(x,175);c.lineTo(x-46+sway,520);c.lineTo(x+60+sway,520);c.fill();
    }
    // Slow arena edge sparkle; never crosses the ball's playable airspace.
    if(!reduced)for(let i=0;i<24;i++) {
      const x=(i*73+17)%420,y=332+(i*29)%173;
      c.globalAlpha=Math.max(0,Math.sin(t*1.7+i*4))*.65;c.fillStyle='#fff0bd';c.fillRect(x,y,2,2);
    }
    c.globalAlpha=1;
    const parquet=c.createLinearGradient(0,568,0,850);parquet.addColorStop(0,'#dca967');parquet.addColorStop(.6,'#896641');parquet.addColorStop(1,'#353248');
    c.fillStyle=parquet;c.fillRect(0,568,420,Math.max(300,top+height-568));
    for(let y=589;y<top+height;y+=22) {
      c.strokeStyle='#513d332a';c.lineWidth=1;c.beginPath();c.moveTo(0,y);c.lineTo(420,y);c.stroke();
      for(let i=-1;i<7;i++){const x=i*90-distance%90+(y%44?30:0);c.beginPath();c.moveTo(x,y);c.lineTo(x-8,y+22);c.stroke();}
    }
    c.strokeStyle='#ffebbcaa';c.lineWidth=2;
    for(let i=-1;i<3;i++) {
      const x=i*360-distance%360;c.beginPath();c.moveTo(x,586);c.lineTo(x-80,900);c.stroke();
      c.beginPath();c.ellipse(x+180,684,102,53,0,0,Math.PI*2);c.stroke();
    }
    c.fillStyle='#fff2bb';c.fillRect(0,B.ground-4,420,4);
    const reflection=c.createLinearGradient(0,586,0,720);reflection.addColorStop(0,'#ffe8ac38');reflection.addColorStop(1,'#ffe8ac00');c.fillStyle=reflection;c.fillRect(0,586,420,134);
  }
}
