import { BASKETBALL as B, STEP } from '../../core/config';
import { clamp } from '../../core/types';

export function releasedVelocity(vy: number, risen: number, elapsed: number, pressure = 0) {
  const strength = Math.max(clamp(elapsed / B.touchJump.fullHoldSeconds, 0, 1), clamp((pressure - .1) / .75, 0, 1));
  const target = B.jumpForce ** 2 / (2 * B.gravity) * (B.touchJump.minHeightRatio + (1 - B.touchJump.minHeightRatio) * strength);
  return vy < 0 ? Math.max(vy, -Math.sqrt(2 * B.gravity * Math.max(0, target - risen))) : vy;
}

// The guide uses the same fixed-step release physics as the player.
export function jumpGuide(hold?: number) {
  let height = 0, vy = -B.jumpForce, released = hold === undefined;
  const points = [{ time: 0, height: 0 }];
  for (let i = 0; i < 120; i++) {
    const time = i * STEP;
    if (!released && time >= hold!) { vy = releasedVelocity(vy, height, time); released = true; }
    vy += B.gravity * STEP; height -= vy * STEP;
    points.push({ time: (i + 1) * STEP, height: Math.max(0, height) });
    if (height <= 0) break;
  }
  const apex = points.reduce((best, p) => p.height > best.height ? p : best);
  return { points, apex: apex.time, flight: points.at(-1)!.time };
}
export const SHORT_GUIDE_HOLD = .08;
export const SHORT_GUIDE = jumpGuide(SHORT_GUIDE_HOLD), FULL_GUIDE = jumpGuide();
