export const GIANT = { scale: 4, grow: .3, shrink: 1.15, returnSpeed: 1.15, reaction: 1.1 } as const;
const ease=(x:number)=>{const t=Math.max(0,Math.min(1,x));return t*t*t*(10+t*(-15+6*t));};

/** Per-run power state. Timers advance only with the simulation, never wall time. */
export class GiantPower {
  scale=1; speedFactor=1; powered=false; recovering=false;
  private growth=0; private growthFrom=1; private releaseFrom=1; private speedFrom=1;
  private releaseTime=0; private speedTime=0; private speedTarget=1; private landed=false;
  get engaged(){return this.powered||this.recovering;}
  get ready(){return this.recovering&&this.releaseTime>=GIANT.returnSpeed&&this.speedTime>=GIANT.returnSpeed;}
  get aura(){return this.powered?1:this.recovering?Math.max(.12,1-ease(this.releaseTime/GIANT.shrink),.2*(1-ease(this.speedTime/GIANT.returnSpeed))):0;}
  clone(){return Object.assign(new GiantPower(),this);}
  reset(){Object.assign(this,new GiantPower());}
  finish(){this.scale=1;this.recovering=false;}
  advance(dt:number,powered:boolean,targetSpeed:number,grounded:boolean){
    let started=false,ending=false;
    if(powered&&!this.powered){
      started=true;this.powered=true;this.recovering=false;
      this.growth=0;this.growthFrom=this.scale;
    }else if(!powered&&this.powered){
      ending=true;this.powered=false;this.recovering=true;this.releaseTime=0;
      this.releaseFrom=this.scale;this.speedFrom=this.speedFactor;this.speedTarget=targetSpeed;this.speedTime=0;this.landed=false;
    }
    if(this.powered){
      this.growth+=dt;this.scale=this.growthFrom+(GIANT.scale-this.growthFrom)*ease(this.growth/GIANT.grow);
      this.speedFactor+=(targetSpeed-this.speedFactor)*(1-Math.exp(-dt*6));
    }else if(this.recovering){
      // Let energy peel away continuously, without freezing a large ball in midair.
      this.releaseTime+=dt;
      this.scale=this.releaseFrom+(1-this.releaseFrom)*ease(this.releaseTime/GIANT.shrink);
      // Preserve horizontal jump timing until a real landing occurs.
      this.landed ||= grounded;
      if(this.landed){
        if(targetSpeed!==this.speedTarget){this.speedFrom=this.speedFactor;this.speedTarget=targetSpeed;this.speedTime=0;}
        this.speedTime+=dt;
        this.speedFactor=this.speedFrom+(targetSpeed-this.speedFrom)*ease(this.speedTime/GIANT.returnSpeed);
      }
    }else this.speedFactor=targetSpeed;
    return {started,ending};
  }
}
