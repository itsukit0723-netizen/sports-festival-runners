import type { ObstacleProfile } from './obstacles';

export interface JumpPattern { id: string; beats: readonly ObstacleProfile[]; cadence: readonly number[] }
const CADENCES = [
  [.88, .9, 1.16, .94, .96, 1.16],
  [1.12, .88, 1.04, .88, .96, 1.12],
  [.94, 1.14, .88, 1.14, .9, 1],
] as const;
const recipes: JumpPattern[] = [];
function permute(beats: ObstacleProfile[], remaining: number[]) {
  if (beats.length === 6) { recipes.push({ id: `jump-${beats.join('-')}`, beats, cadence: CADENCES[recipes.length % CADENCES.length] }); return; }
  (['normal', 'high', 'long'] as const).forEach((profile, i) => {
    if (!remaining[i]) return;
    const next = [...remaining]; next[i]--;
    permute([...beats, profile], next);
  });
}
// 90 different six-jump phrases. Each contains two of each jump, so random
// selection cannot turn a section into six difficult long jumps.
permute([], [2, 2, 2]);
// Add deliberately different phrases: low-jump runs, climbing phrases and
// long-jump phrases. Across the three families each profile stays equally common.
const accents: ObstacleProfile[][] = [
  ['normal','normal','normal','high','long','high'],
  ['high','high','normal','high','long','long'],
  ['long','normal','high','long','normal','long'],
];
accents.forEach((beats, family) => {
  for (let shift = 0; shift < 6; shift++) recipes.push({
    id: `accent-${family}-${shift}`, beats: [...beats.slice(shift), ...beats.slice(0, shift)],
    cadence: CADENCES[family],
  });
});
export const JUMP_PATTERNS: readonly JumpPattern[] = recipes;
