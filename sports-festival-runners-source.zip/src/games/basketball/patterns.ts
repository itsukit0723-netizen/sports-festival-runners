import type { ObstacleProfile } from './obstacles';

export interface JumpPattern { id: string; beats: readonly ObstacleProfile[]; cadence: readonly number[]; staccato?: { gaps: readonly number[]; width: number; height: number } }
const CADENCES = [
  [.88, .9, 1.16, .94, .96, 1.16],
  [1.12, .88, 1.04, .88, .96, 1.12],
  [.94, 1.14, .88, 1.14, .9, 1],
] as const;
const recipes: JumpPattern[] = [];
function permute(beats: ObstacleProfile[], remaining: number[]) {
  if (beats.length === 6) { recipes.push({ id: `jump-${beats.join('-')}`, beats, cadence: CADENCES[recipes.length % CADENCES.length] }); return; }
  (['normal', 'high', 'long'] as const).forEach((profile, i) => {
    if (!remaining[i]) return;
    const next = [...remaining]; next[i]--;
    permute([...beats, profile], next);
  });
}
// 90 different six-jump phrases. Each contains two of each jump, so random
// selection cannot turn a section into six difficult long jumps.
permute([], [2, 2, 2]);
// Add deliberately different phrases: low-jump runs, climbing phrases and
// long-jump phrases. Across the three families each profile stays equally common.
const accents: ObstacleProfile[][] = [
  ['normal','normal','normal','high','long','high'],
  ['high','high','normal','high','long','long'],
  ['long','normal','high','long','normal','long'],
];
accents.forEach((beats, family) => {
  for (let shift = 0; shift < 6; shift++) recipes.push({
    id: `accent-${family}-${shift}`, beats: [...beats.slice(shift), ...beats.slice(0, shift)],
    cadence: CADENCES[family],
  });
});
export const STANDARD_JUMP_PATTERNS: readonly JumpPattern[] = [...recipes];
// Short, learnable rhythms with an actual overhead rail: a full jump cannot
// skip the phrase. Half the deck is dedicated to these 5–8 tap combinations.
export const STACCATO_PATTERNS: readonly JumpPattern[] = Array.from({length:108}, (_, i) => {
  const count = 5 + i % 4;
  const gaps = Array.from({length:count - 1}, (_, j) => .59 + ((i * 7 + j * 11 + Math.floor(i / 4) * j) % 7) * .01);
  return {id:`tap-${i+1}`, beats:Array.from({length:count}, ()=>'normal' as const), cadence:Array.from({length:count},()=>1),
    staccato:{gaps, width:18 + Math.floor(i / 4) % 3 * 2, height:20 + Math.floor(i / 12) % 3 * 2}};
});
export const JUMP_PATTERNS: readonly JumpPattern[] = [...recipes, ...STACCATO_PATTERNS];
