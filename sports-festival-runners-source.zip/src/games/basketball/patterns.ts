import type { ObstacleProfile } from './obstacles';

export interface JumpPattern { id: string; beats: readonly ObstacleProfile[] }
const recipes: JumpPattern[] = [];
function permute(beats: ObstacleProfile[], remaining: number[]) {
  if (beats.length === 6) { recipes.push({ id: `jump-${beats.join('-')}`, beats }); return; }
  (['normal', 'high', 'long'] as const).forEach((profile, i) => {
    if (!remaining[i]) return;
    const next = [...remaining]; next[i]--;
    permute([...beats, profile], next);
  });
}
// 90 different six-jump phrases. Each contains two of each jump, so random
// selection cannot turn a section into six difficult long jumps.
permute([], [2, 2, 2]);
export const JUMP_PATTERNS: readonly JumpPattern[] = recipes;
