import { GoldenCourt } from './golden-court';
import { BASKETBALL as B } from '../../core/config';
import type { GameEvent, GameRenderer } from '../../core/types';
import type { BasketballModel, RunnerObject } from './model';
import { GameFeel } from '../../core/feel';
interface Debris { x:number;y:number;vx:number;vy:number;life:number;angle:number;spin:number;w:number;h:number;color:string;bounced:boolean }
interface Particle { x: number; y: number; vx: number; vy: number; life: number; max: number; size: number; color: string }
export class BasketballRenderer implements GameRenderer {
  private golden = false;
  private goldenCourt?: GoldenCourt;
  setGolden(enabled: boolean) { this.golden = enabled; if(enabled&&!this.goldenCourt)this.goldenCourt=new GoldenCourt(); }
  private ctx: CanvasRenderingContext2D;
  private particles: Particle[] = [];
  private debris:Debris[]=[];
  private trails: { x: number; y: number; life: number; scale:number; giant:boolean }[] = [];
  private trailIn = 0;
  private pickupStreams: { x: number; y: number; life: number; special: boolean }[] = [];
  private worldHeight: number = B.height; private offsetY = 0;
  private feel = new GameFeel(); private waves: { x: number; y: number; life: number; color: string }[] = [];
  private motionQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
  private motionChange = () => { this.feel.reducedMotion = this.motionQuery.matches; };
  constructor(private canvas: HTMLCanvasElement, private model: BasketballModel) { this.ctx = canvas.getContext('2d')!; this.motionChange(); this.motionQuery.addEventListener('change', this.motionChange); this.resize(); }
  resize() {
    const r = Math.min(window.devicePixelRatio || 1, 2);
    this.canvas.width = Math.round(this.canvas.clientWidth * r); this.canvas.height = Math.round(this.canvas.clientHeight * r);
    this.worldHeight = this.canvas.height / (this.canvas.width / B.width);
    this.offsetY = (this.worldHeight - B.height) * .77;
  }
  private rounded(x: number, y: number, w: number, h: number, r: number, fill: string) {
    const c = this.ctx; c.fillStyle = fill; c.beginPath(); c.roundRect(x, y, w, h, r); c.fill();
  }
  private burst(x: number, y: number, color: string, n: number, powerful = false) {
    for (let i = 0; i < n && this.particles.length < 130; i++) {
      const a = Math.random() * Math.PI * 2, s = (powerful ? 210 : 100) * (.3 + Math.random());
      this.particles.push({ x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s - 40, life: .4 + Math.random() * .3, max: .7, size: powerful ? 4 + Math.random() * 8 : 2 + Math.random() * 3, color });
    }
  }
  render(dt: number, events: GameEvent[]) {
    const c = this.ctx, m = this.model;
    this.feel.update(dt, events, m.over ? 0 : m.boost > 0 ? 1 : m.fever > 0 ? .85 : Math.min(.35, Math.max(0, m.speed / B.baseSpeed - 1) * .16 + Math.min(m.combo, 32) * .003));
    for (const e of events) {
      if (e.kind === 'coin') {
        this.pickupStreams.push({ x: e.x ?? B.playerX, y: e.y ?? m.y, life: .24, special: e.reward === 'landing' });
        if (this.pickupStreams.length > 24) this.pickupStreams.shift();
      }
      if (e.kind === 'coin') this.burst(e.x!, e.y!, e.reward === 'landing' ? '#b4ffe0' : '#fff6a8', e.reward ? 12 : 6);
      if (e.kind === 'smash') {
        this.burst(e.x!, e.y!, this.golden?'#ffe5a3':'#f7b87e', 32, true);
        if(this.golden)for(let i=0;i<9&&this.debris.length<54;i++)this.debris.push({x:e.x!,y:e.y!+12,vx:m.speed*.65+90+Math.random()*150,vy:-140-Math.random()*240,life:.85,angle:Math.random()*6.28,spin:(Math.random()-.5)*14,w:Math.min(28,Math.max(10,(e.value??50)/6)),h:7+Math.random()*12,color:['#edc795','#718b94','#df9d62','#fff0c5'][i%4],bounced:false});
      }
      if(e.kind==='giant')this.burst(B.playerX,m.y-40,'#ffdf87',52,true);
      if(e.kind==='giantEnd')this.burst(B.playerX,B.ground-10,'#fff0c2',16);
      if (e.kind === 'land') this.burst(e.x!, e.y!, '#ffe6bf', 9);
      if (e.kind === 'fever' || e.kind === 'boost') this.burst(B.playerX, m.y, e.kind === 'fever' ? '#ffef65' : '#b4ffed', 28, true);
      if (e.kind === 'over') this.burst(B.playerX, m.y, '#ffb38a', 20, true);
      if (['land', 'boost', 'fever', 'smash', 'near', 'giant'].includes(e.kind)) {
        this.waves.push({ x: e.x ?? B.playerX, y: e.kind === 'land' ? B.ground : e.y ?? m.y, life: .4, color: e.kind === 'fever' || e.kind === 'smash' ? '#ffe49b' : '#b7ffe4' });
        if (this.waves.length > 10) this.waves.shift();
      }
    }
    const scale = this.canvas.width / B.width;
    c.setTransform(scale, 0, 0, scale, 0, this.offsetY * scale);
    c.clearRect(0, -this.offsetY, B.width, this.worldHeight); c.fillStyle = '#27364c'; c.fillRect(0, -this.offsetY, B.width, this.worldHeight); c.save();
    if(this.golden)this.goldenCourt!.render(c,m.time,m.distance,-this.offsetY,this.worldHeight,this.motionQuery.matches);else this.background();
    for (const o of m.objects) this.object(o);
    const giant=m.giantScale,bodyY=m.y-(B.radius*giant-B.radius);
    this.trailIn -= dt;
    if ((this.golden || m.boost > 0 || m.fever > 0 || m.combo >= 8) && this.trailIn <= 0 && !m.over) { this.trails.push({ x: B.playerX, y: bodyY, life: m.giantActive?.17:.25,scale:giant,giant:m.giantActive }); this.trailIn = m.giantActive?.08:this.golden ? .045 : .025; }
    for (const trail of this.trails) {
      trail.life -= dt; trail.x -= m.speed * dt;
      c.globalAlpha = Math.max(0, trail.life) * (trail.giant?.65:1.2);c.save();c.translate(trail.x,trail.y);c.scale(trail.scale,trail.scale);this.ball(0,0,m.rotation);c.restore();c.globalAlpha=1;
    }
    this.trails = this.trails.filter(t => t.life > 0);
    for (const wave of this.waves) {
      wave.life -= dt; wave.x -= m.speed * dt * .45;
      c.globalAlpha = Math.max(0, wave.life / .4) * .65; c.strokeStyle = wave.color; c.lineWidth = 2;
      c.beginPath(); c.ellipse(wave.x, wave.y, 15 + (1 - wave.life / .4) * 60, 4 + (1 - wave.life / .4) * 13, 0, 0, Math.PI * 2); c.stroke();
    }
    this.waves = this.waves.filter(wave => wave.life > 0); c.globalAlpha = 1;
    c.fillStyle = '#25132c40'; c.beginPath(); c.ellipse(B.playerX, B.ground + 3, Math.max(8,(22-(B.ground-m.y)*.035)*giant),5*giant, 0, 0, Math.PI * 2); c.fill();
    for (const pickup of this.pickupStreams) {
      pickup.life -= dt; const t = 1 - Math.max(0, pickup.life) / .24, ease = 1 - (1 - t) ** 3;
      const x = pickup.x + (B.playerX - pickup.x) * ease, y = pickup.y + (m.y - pickup.y) * ease - Math.sin(t * Math.PI) * 24;
      c.globalAlpha = Math.max(0, 1 - t); c.strokeStyle = pickup.special ? '#b4ffe0' : '#ffe69a'; c.fillStyle = c.strokeStyle; c.lineWidth = 2;
      c.beginPath(); c.moveTo(x + 12 * (1 - t), y - 8); c.lineTo(x, y); c.stroke();
      c.save(); c.translate(x, y); c.rotate(Math.PI / 4); c.fillRect(-3, -3, 6, 6); c.restore();
    }
    this.pickupStreams = this.pickupStreams.filter(pickup => pickup.life > 0); c.globalAlpha = 1;
    for(const shard of this.debris){
      shard.life-=dt;shard.x+=(shard.vx-m.speed*.65)*dt;shard.y+=shard.vy*dt;shard.vy+=650*dt;shard.angle+=shard.spin*dt;
      if(shard.y>B.ground-shard.h/2&&!shard.bounced){shard.y=B.ground-shard.h/2;shard.vy=-Math.abs(shard.vy)*.3;shard.vx*=.6;shard.bounced=true;}
      c.save();c.globalAlpha=Math.min(1,shard.life*3);c.translate(shard.x,shard.y);c.rotate(shard.angle);c.fillStyle=shard.color;c.fillRect(-shard.w/2,-shard.h/2,shard.w,shard.h);c.strokeStyle='#fff1c477';c.lineWidth=1;c.strokeRect(-shard.w/2,-shard.h/2,shard.w,shard.h);c.restore();
    }
    this.debris=this.debris.filter(p=>p.life>0&&p.x>-90);
    if(m.giantActive){
      const radius=B.radius*giant,aura=c.createRadialGradient(B.playerX,bodyY,radius*.7,B.playerX,bodyY,radius+25);
      aura.addColorStop(0,'#fff4be00');aura.addColorStop(.65,'#ffd66b28');aura.addColorStop(1,'#ffd66b00');c.fillStyle=aura;c.beginPath();c.arc(B.playerX,bodyY,radius+25,0,Math.PI*2);c.fill();
      c.strokeStyle=m.giantRecovery?'#e8fff0':'#ffe7a1';c.lineWidth=2;c.globalAlpha=.45;
      for(let i=0;i<3;i++){const a=m.time*.8+i*Math.PI*2/3;c.beginPath();c.arc(B.playerX,bodyY,radius+7,a,a+.65);c.stroke();}c.globalAlpha=1;
    }
    const reward = this.feel.reward;
    if (reward > .02 || m.boost > 0 || m.fever > 0) {
      c.strokeStyle = m.fever > 0 ? '#ffe49b' : '#b4ffe0'; c.globalAlpha = Math.min(.7, reward + this.feel.rush * .3); c.lineWidth = 2;
      c.beginPath(); c.arc(B.playerX, bodyY, B.radius*giant+5+reward*12, -.7, 1.5); c.stroke();
      c.beginPath(); c.arc(B.playerX, m.y, 25 + reward * 12, Math.PI - .7, Math.PI + 1.5); c.stroke(); c.globalAlpha = 1;
    }
    if (m.fever > 0 || reward > .02) { c.shadowColor = m.fever > 0 ? '#ffef67' : '#b4ffe0'; c.shadowBlur = m.fever > 0 ? 28 : reward * 20; }
    const squash = (this.feel.land * .085 - this.feel.jump * .06) * this.feel.motion / (m.giantActive?3:1);
    c.save(); c.translate(B.playerX, bodyY); c.scale((1+squash)*giant,(1-squash)*giant); this.ball(0, 0, m.rotation); c.restore(); c.shadowBlur = 0;
    for (const p of this.particles) {
      p.life -= dt; p.x += p.vx * dt; p.y += p.vy * dt; p.vy += 360 * dt;
      c.globalAlpha = Math.max(0, p.life / p.max); c.fillStyle = p.color; c.save(); c.translate(p.x, p.y); c.rotate(p.life * 5); c.fillRect(-p.size / 2, -p.size / 2, p.size, p.size); c.restore();
    }
    c.globalAlpha = 1; this.particles = this.particles.filter(p => p.life > 0);
    c.restore();
    if (this.feel.rush > .04) {
      const glow = c.createLinearGradient(0, 0, B.width, 0);
      const color = m.fever > 0 ? '255,216,116' : '157,255,222';
      glow.addColorStop(0, `rgba(${color},${this.feel.rush * .15})`); glow.addColorStop(.18, `rgba(${color},0)`); glow.addColorStop(.82, `rgba(${color},0)`); glow.addColorStop(1, `rgba(${color},${this.feel.rush * .15})`);
      c.fillStyle = glow; c.fillRect(0, -this.offsetY, B.width, this.worldHeight);
      c.strokeStyle = m.boost > 0 ? '#c8fff7b0' : '#ffec9b80'; c.lineWidth = m.boost > 0 ? 2.3 : 1.6;
      c.globalAlpha = this.feel.rush * (this.feel.reducedMotion ? 0 : .28);
      for (let i = 0; i < 10; i++) {
        const x = ((i * 97 - m.distance) % 600 + 600) % 600 - 110, y = -this.offsetY + 30 + i * (this.worldHeight - 60) / 10;
        if (y > B.ground - 190 && y < B.ground + 35) continue;
        c.beginPath(); c.moveTo(x, y); c.lineTo(x + 30 + this.feel.rush * 85 + i % 3 * 12, y); c.stroke();
      }
      c.globalAlpha = 1;
    }
  }
  private background() {
    const c = this.ctx, m = this.model;
    const gradient = c.createLinearGradient(0, -this.offsetY, 0, 600);
    gradient.addColorStop(0, this.golden ? '#211b32' : m.bonus > 0 ? '#574176' : '#27364c'); gradient.addColorStop(1, this.golden ? '#a17c64' : m.bonus > 0 ? '#c39397' : '#8699a8');
    c.fillStyle = gradient; c.fillRect(-32, -this.offsetY - 32, B.width + 64, this.worldHeight + 64);
    c.fillStyle = '#f5dda4'; c.beginPath(); c.arc(332, 178, 38, 0, Math.PI * 2); c.fill();
    c.fillStyle = '#ffffff13'; c.beginPath(); c.arc(332, 178, 60, 0, Math.PI * 2); c.fill();
    // Stadium silhouette, parallax lights, and a court with authentic rolling contact.
    for (let i = -1; i < 6; i++) {
      const x = i * 118 - (m.distance * .1) % 118;
      c.fillStyle = '#2c4057'; c.fillRect(x, 330 + i % 2 * 20, 100, 190);
      c.fillStyle = '#d1e8d130'; for (let j = 0; j < 4; j++) c.fillRect(x + 9 + j * 22, 357 + i % 2 * 20, 9, 17);
    }
    c.fillStyle = '#273747'; c.fillRect(-32, 435, B.width + 64, 112);
    for (let row = 0; row < 4; row++) for (let i = 0; i < 22; i++) {
      const x = i * 23 - (m.distance * .26) % 23;
      c.fillStyle = ['#879794', '#cba387', '#b6a3aa', '#728f9c'][(i + row * 3) % 4];
      c.fillRect(x, 444 + row * 21, 13, 7);
    }
    for (let i = -1; i < 3; i++) {
      const x = i * 260 - (m.distance * .18) % 260;
      c.fillStyle = '#243445'; c.fillRect(x + 10, 260, 5, 180);
      this.rounded(x - 11, 254, 47, 12, 3, '#e8efd4');
      c.fillStyle = '#d6f0db0b'; c.beginPath(); c.moveTo(x - 11, 267); c.lineTo(x - 80, 440); c.lineTo(x + 110, 440); c.lineTo(x + 36, 267); c.fill();
    }
    c.fillStyle = '#213849'; c.fillRect(-32, 526, B.width + 64, 42);
    c.font = 'bold 13px Arial'; c.textAlign = 'left'; c.fillStyle = '#d5e5d8';
    for (let i = -1; i < 4; i++) c.fillText('SF  /  KEEP IT MOVING', i * 202 - (m.distance * .5) % 202, 552);
    c.fillStyle = m.bonus > 0 ? '#a183a9' : '#bf8b75'; c.fillRect(-32, 568, B.width + 64, this.worldHeight - this.offsetY - 568 + 64);
    c.fillStyle = '#edba91'; c.fillRect(-32, 568, B.width + 64, 16);
    c.fillStyle = '#f8dbb1'; c.fillRect(-32, 580, B.width + 64, 4);
    c.strokeStyle = '#f7d9ad80'; c.lineWidth = 2;
    const offset = m.distance % 390;
    for (let i = -1; i < 3; i++) { const x = i * 390 - offset; c.beginPath(); c.moveTo(x, 586); c.lineTo(x - 55, 760); c.stroke(); c.beginPath(); c.ellipse(x + 170, 674, 95, 46, 0, 0, Math.PI * 2); c.stroke(); }
    c.fillStyle = '#1b263450'; c.fillRect(-32, this.worldHeight - this.offsetY - 44, B.width + 64, 108);
  }
  private ball(x: number, y: number, angle: number) {
    const c = this.ctx; c.save(); c.translate(x, y); c.rotate(angle);
    const g = c.createRadialGradient(-7, -9, 2, 0, 0, 22); g.addColorStop(0, '#ffc574'); g.addColorStop(.65, '#f28b40'); g.addColorStop(1, '#ce5b26');
    c.fillStyle = g; c.beginPath(); c.arc(0, 0, 20, 0, Math.PI * 2); c.fill();
    c.save(); c.beginPath(); c.arc(0, 0, 19.5, 0, Math.PI * 2); c.clip();
    c.strokeStyle = '#452d2b'; c.lineWidth = 1.8;
    c.beginPath(); c.moveTo(-21, 0); c.lineTo(21, 0); c.moveTo(0, -21); c.lineTo(0, 21); c.stroke();
    for (const sign of [-1, 1]) { c.beginPath(); c.ellipse(sign * 22, 0, 17, 24, 0, 0, Math.PI * 2); c.stroke(); }
    c.restore(); c.strokeStyle = '#713e2e'; c.lineWidth = 1; c.beginPath(); c.arc(0, 0, 20, 0, Math.PI * 2); c.stroke(); c.restore();
  }
  private object(o: RunnerObject) {
    const c = this.ctx, { x, y, width: w, height: h } = o;
    if (o.type === 'coin') {
      if (o.landingReward) {
        c.save(); c.strokeStyle = '#b4ffe066'; c.lineWidth = 2;
        c.beginPath(); c.arc(x, y, 14 + Math.sin(this.model.time * 3) * 1.5, 0, Math.PI * 2); c.stroke(); c.restore();
        c.save(); c.translate(x, y); c.rotate(Math.PI / 4);
        c.fillStyle = '#b4ffe0'; c.shadowColor = '#b4ffe0'; c.shadowBlur = 12;
        c.fillRect(-10, -10, 20, 20); c.shadowBlur = 0;
        c.strokeStyle = '#edfff6'; c.lineWidth = 2; c.strokeRect(-7, -7, 14, 14);
        c.restore();
        c.fillStyle = '#edfff6';
        for (let i = -1; i <= 1; i++) c.fillRect(x + i * 6 - 1.5, y + 20, 3, 5);
        return;
      }
      c.save(); c.translate(x, y); const pulse = .75 + Math.abs(Math.sin(this.model.time * 3 + o.id)) * .25; c.scale(pulse, 1);
      c.fillStyle = o.landingReward ? '#b4efcf' : '#e9a62f'; c.beginPath(); c.arc(0, 0, 9, 0, Math.PI * 2); c.fill();
      c.strokeStyle = o.landingReward ? '#dcffeb' : '#fff2b0'; c.lineWidth = 2; c.stroke(); c.fillStyle = o.landingReward ? '#244f43' : '#fff1ad'; c.font = 'bold 12px Arial'; c.textAlign = 'center'; c.fillText('✦', 0, 4); c.restore(); return;
    }
    if (o.type === 'boost' || o.type === 'fever') {
      const color = o.type === 'boost' ? '#a2f9dc' : '#ffdc76'; c.save(); c.translate(x, y + Math.sin(this.model.time * 5) * 4);
      c.shadowColor = color; c.shadowBlur = 19; this.rounded(-15, -17, 30, 34, 9, color); c.shadowBlur = 0;
      c.fillStyle = '#273344'; c.font = 'bold 23px Arial'; c.textAlign = 'center'; c.fillText(o.type === 'boost' ? 'ϟ' : '★', 0, 8); c.restore(); return;
    }
    if(o.type==='beam') {
      this.rounded(x,y,w,h,3,'#23334b');this.rounded(x,y+h-5,w,5,2,'#e6bc67');
      c.strokeStyle='#8ca0b9';c.lineWidth=1;
      for(let px=x+10;px<x+w;px+=24){c.beginPath();c.moveTo(px,y+2);c.lineTo(px+10,y+h-6);c.lineTo(px+20,y+2);c.stroke();}
      c.fillStyle='#f2db9e';c.font='bold 9px sans-serif';c.textAlign='left';
      for(let px=x+20;px<x+w;px+=210)c.fillText('LOW  ↓',px,y-7);
      return;
    }
    c.fillStyle = '#34253645'; c.beginPath(); c.ellipse(x + w / 2, B.ground + 4, w * .7, 4, 0, 0, Math.PI * 2); c.fill();
    if (o.type === 'cone') {
      this.rounded(x - 5, B.ground - 5, w + 10, 7, 3, '#db6e46');
      c.fillStyle = '#f69059'; c.beginPath(); c.moveTo(x, B.ground - 5); c.lineTo(x + w * .4, y); c.lineTo(x + w * .6, y); c.lineTo(x + w, B.ground - 5); c.fill();
      c.fillStyle = '#ffecc6'; c.beginPath(); c.moveTo(x + 6, y + h * .53); c.lineTo(x + w - 6, y + h * .53); c.lineTo(x + w - 10, y + h * .3); c.lineTo(x + 10, y + h * .3); c.fill();
    } else if (o.type === 'hurdle') {
      this.rounded(x, y, w, 9, 2, o.tapOnly ? '#b7f6e1' : '#eee7d4'); this.rounded(x + 3, y + 9, 4, h - 9, 1, '#5d6c86'); this.rounded(x + w - 7, y + 9, 4, h - 9, 1, '#5d6c86');
      c.fillStyle = '#dc745c'; c.fillRect(x + 10, y, Math.min(13,w-12), 9);
    } else if (o.type === 'dummy') {
      this.rounded(x + 2, y, w - 4, h - 12, 7, '#8c82b0');
      this.rounded(x + 6, y + 4, w - 12, h - 23, 4, '#a699c9');
      c.strokeStyle = '#f2e7ff'; c.lineWidth = 2;
      for (const cy of [y + 32, y + 53]) { c.beginPath(); c.moveTo(x + 9, cy); c.lineTo(x + w / 2, cy - 7); c.lineTo(x + w - 9, cy); c.stroke(); }
      this.rounded(x + w / 2 - 4, y + h - 14, 8, 14, 2, '#566878');
      this.rounded(x - 4, B.ground - 5, w + 8, 6, 3, '#566878');
    } else if (o.type === 'bench') {
      this.rounded(x, y, w, 12, 3, '#e8c695'); c.fillStyle = '#637684'; c.fillRect(x + 9, y + 12, 7, h - 12); c.fillRect(x + w - 16, y + 12, 7, h - 12);
      c.strokeStyle = '#a58666'; c.lineWidth = 1; c.beginPath(); c.moveTo(x + 5, y + 7); c.lineTo(x + w - 5, y + 7); c.stroke();
    } else {
      this.rounded(x, y, w, h, 6, '#79aaa7'); this.rounded(x + 3, y, w - 6, 5, 3, '#b3d7cf');
      c.strokeStyle = '#b5e6d2'; c.lineWidth = 1.5;
      for (const side of [-1, 1]) { const cx = x + w / 2 + side * 25; c.beginPath(); c.moveTo(cx - side * 8, y + 11); c.lineTo(cx, y + 15); c.lineTo(cx - side * 8, y + 20); c.stroke(); }
    }
  }
  dispose() { this.motionQuery.removeEventListener('change', this.motionChange); this.particles = [];this.debris=[]; this.trails = []; this.waves = []; this.pickupStreams = []; }
}

