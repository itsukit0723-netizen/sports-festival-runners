import { BASKETBALL as B } from '../../core/config';
import type { GameEvent, GameRenderer } from '../../core/types';
import type { BasketballModel, RunnerObject } from './model';
interface Particle { x: number; y: number; vx: number; vy: number; life: number; max: number; size: number; color: string }
export class BasketballRenderer implements GameRenderer {
  private ctx: CanvasRenderingContext2D;
  private particles: Particle[] = []; private shake = 0;
  private trails: { x: number; y: number; life: number }[] = [];
  private trailIn = 0;
  private worldHeight: number = B.height; private offsetY = 0;
  constructor(private canvas: HTMLCanvasElement, private model: BasketballModel) { this.ctx = canvas.getContext('2d')!; this.resize(); }
  resize() {
    const r = Math.min(window.devicePixelRatio || 1, 2);
    this.canvas.width = Math.round(this.canvas.clientWidth * r); this.canvas.height = Math.round(this.canvas.clientHeight * r);
    this.worldHeight = this.canvas.height / (this.canvas.width / B.width);
    this.offsetY = (this.worldHeight - B.height) * .77;
  }
  private rounded(x: number, y: number, w: number, h: number, r: number, fill: string) {
    const c = this.ctx; c.fillStyle = fill; c.beginPath(); c.roundRect(x, y, w, h, r); c.fill();
  }
  private burst(x: number, y: number, color: string, n: number, powerful = false) {
    for (let i = 0; i < n && this.particles.length < 130; i++) {
      const a = Math.random() * Math.PI * 2, s = (powerful ? 210 : 100) * (.3 + Math.random());
      this.particles.push({ x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s - 40, life: .4 + Math.random() * .3, max: .7, size: powerful ? 4 + Math.random() * 8 : 2 + Math.random() * 3, color });
    }
  }
  render(dt: number, events: GameEvent[]) {
    const c = this.ctx, m = this.model;
    for (const e of events) {
      if (e.kind === 'coin') this.burst(e.x!, e.y!, '#fff6a8', 6);
      if (e.kind === 'smash') { this.burst(e.x!, e.y!, '#f7b87e', 22, true); this.shake = .16; }
      if (e.kind === 'land') this.burst(e.x!, e.y!, '#ffe6bf', 5);
      if (e.kind === 'fever' || e.kind === 'boost') this.burst(B.playerX, m.y, e.kind === 'fever' ? '#ffef65' : '#b4ffed', 28, true);
      if (e.kind === 'over') { this.shake = .23; this.burst(B.playerX, m.y, '#ffb38a', 20, true); }
    }
    const scale = this.canvas.width / B.width;
    c.setTransform(scale, 0, 0, scale, 0, this.offsetY * scale);
    c.clearRect(0, -this.offsetY, B.width, this.worldHeight); c.save();
    this.shake = Math.max(0, this.shake - dt);
    if (this.shake > 0) c.translate(Math.sin(m.time * 150) * this.shake * 12, Math.cos(m.time * 110) * this.shake * 8);
    this.background();
    for (const o of m.objects) this.object(o);
    this.trailIn -= dt;
    if ((m.boost > 0 || m.fever > 0) && this.trailIn <= 0 && !m.over) { this.trails.push({ x: B.playerX, y: m.y, life: .22 }); this.trailIn = .035; }
    for (const trail of this.trails) {
      trail.life -= dt; trail.x -= m.speed * dt;
      c.globalAlpha = Math.max(0, trail.life) * 1.2; this.ball(trail.x, trail.y, m.rotation); c.globalAlpha = 1;
    }
    this.trails = this.trails.filter(t => t.life > 0);
    c.fillStyle = '#25132c40'; c.beginPath(); c.ellipse(B.playerX, B.ground + 3, 22 - (B.ground - m.y) * .035, 5, 0, 0, Math.PI * 2); c.fill();
    if (m.fever > 0) { c.shadowColor = '#ffef67'; c.shadowBlur = 28; }
    this.ball(B.playerX, m.y, m.rotation); c.shadowBlur = 0;
    for (const p of this.particles) {
      p.life -= dt; p.x += p.vx * dt; p.y += p.vy * dt; p.vy += 360 * dt;
      c.globalAlpha = Math.max(0, p.life / p.max); c.fillStyle = p.color; c.save(); c.translate(p.x, p.y); c.rotate(p.life * 5); c.fillRect(-p.size / 2, -p.size / 2, p.size, p.size); c.restore();
    }
    c.globalAlpha = 1; this.particles = this.particles.filter(p => p.life > 0);
    if (m.boost > 0 || m.fever > 0) {
      c.strokeStyle = m.boost > 0 ? '#c8fff7b0' : '#ffec9b80'; c.lineWidth = m.boost > 0 ? 2.3 : 1.6;
      for (let i = 0; i < (m.boost > 0 ? 19 : 11); i++) { const x = ((i * 97 - m.distance * 2.2) % 530 + 530) % 530 - 70, y = 105 + i * 27; c.beginPath(); c.moveTo(x, y); c.lineTo(x + (m.boost > 0 ? 60 : 25) + i % 3 * 20, y); c.stroke(); }
      if (m.boost > 0) { c.fillStyle = '#9affdf0c'; c.fillRect(0, -this.offsetY, B.width, this.worldHeight); }
    }
    c.restore();
  }
  private background() {
    const c = this.ctx, m = this.model;
    const gradient = c.createLinearGradient(0, -this.offsetY, 0, 600);
    gradient.addColorStop(0, m.bonus > 0 ? '#574176' : '#27364c'); gradient.addColorStop(1, m.bonus > 0 ? '#c39397' : '#8699a8');
    c.fillStyle = gradient; c.fillRect(0, -this.offsetY, 420, this.worldHeight);
    c.fillStyle = '#f5dda4'; c.beginPath(); c.arc(332, 178, 38, 0, Math.PI * 2); c.fill();
    c.fillStyle = '#ffffff13'; c.beginPath(); c.arc(332, 178, 60, 0, Math.PI * 2); c.fill();
    // Stadium silhouette, parallax lights, and a court with authentic rolling contact.
    for (let i = -1; i < 6; i++) {
      const x = i * 118 - (m.distance * .1) % 118;
      c.fillStyle = '#2c4057'; c.fillRect(x, 330 + i % 2 * 20, 100, 190);
      c.fillStyle = '#d1e8d130'; for (let j = 0; j < 4; j++) c.fillRect(x + 9 + j * 22, 357 + i % 2 * 20, 9, 17);
    }
    c.fillStyle = '#273747'; c.fillRect(0, 435, 420, 112);
    for (let row = 0; row < 4; row++) for (let i = 0; i < 22; i++) {
      const x = i * 23 - (m.distance * .26) % 23;
      c.fillStyle = ['#879794', '#cba387', '#b6a3aa', '#728f9c'][(i + row * 3) % 4];
      c.fillRect(x, 444 + row * 21, 13, 7);
    }
    for (let i = -1; i < 3; i++) {
      const x = i * 260 - (m.distance * .18) % 260;
      c.fillStyle = '#243445'; c.fillRect(x + 10, 260, 5, 180);
      this.rounded(x - 11, 254, 47, 12, 3, '#e8efd4');
      c.fillStyle = '#d6f0db0b'; c.beginPath(); c.moveTo(x - 11, 267); c.lineTo(x - 80, 440); c.lineTo(x + 110, 440); c.lineTo(x + 36, 267); c.fill();
    }
    c.fillStyle = '#213849'; c.fillRect(0, 526, 420, 42);
    c.font = 'bold 13px Arial'; c.textAlign = 'left'; c.fillStyle = '#d5e5d8';
    for (let i = -1; i < 4; i++) c.fillText('SF  /  KEEP IT MOVING', i * 202 - (m.distance * .5) % 202, 552);
    c.fillStyle = m.bonus > 0 ? '#a183a9' : '#bf8b75'; c.fillRect(0, 568, 420, this.worldHeight - this.offsetY - 568);
    c.fillStyle = '#edba91'; c.fillRect(0, 568, 420, 16);
    c.fillStyle = '#f8dbb1'; c.fillRect(0, 580, 420, 4);
    c.strokeStyle = '#f7d9ad80'; c.lineWidth = 2;
    const offset = m.distance % 390;
    for (let i = -1; i < 3; i++) { const x = i * 390 - offset; c.beginPath(); c.moveTo(x, 586); c.lineTo(x - 55, 760); c.stroke(); c.beginPath(); c.ellipse(x + 170, 674, 95, 46, 0, 0, Math.PI * 2); c.stroke(); }
    c.fillStyle = '#1b263450'; c.fillRect(0, this.worldHeight - this.offsetY - 44, 420, 44);
  }
  private ball(x: number, y: number, angle: number) {
    const c = this.ctx; c.save(); c.translate(x, y); c.rotate(angle);
    const g = c.createRadialGradient(-7, -9, 2, 0, 0, 22); g.addColorStop(0, '#ffc574'); g.addColorStop(.65, '#f28b40'); g.addColorStop(1, '#ce5b26');
    c.fillStyle = g; c.beginPath(); c.arc(0, 0, 20, 0, Math.PI * 2); c.fill();
    c.save(); c.beginPath(); c.arc(0, 0, 19.5, 0, Math.PI * 2); c.clip();
    c.strokeStyle = '#452d2b'; c.lineWidth = 1.8;
    c.beginPath(); c.moveTo(-21, 0); c.lineTo(21, 0); c.moveTo(0, -21); c.lineTo(0, 21); c.stroke();
    for (const sign of [-1, 1]) { c.beginPath(); c.ellipse(sign * 22, 0, 17, 24, 0, 0, Math.PI * 2); c.stroke(); }
    c.restore(); c.strokeStyle = '#713e2e'; c.lineWidth = 1; c.beginPath(); c.arc(0, 0, 20, 0, Math.PI * 2); c.stroke(); c.restore();
  }
  private object(o: RunnerObject) {
    const c = this.ctx, { x, y, width: w, height: h } = o;
    if (o.type === 'coin') {
      c.save(); c.translate(x, y); const pulse = .75 + Math.abs(Math.sin(this.model.time * 3 + o.id)) * .25; c.scale(pulse, 1);
      c.fillStyle = '#e9a62f'; c.beginPath(); c.arc(0, 0, 9, 0, Math.PI * 2); c.fill();
      c.strokeStyle = o.landingReward ? '#b4ffe0' : '#fff2b0'; c.lineWidth = 2; c.stroke(); c.fillStyle = '#fff1ad'; c.font = 'bold 12px Arial'; c.textAlign = 'center'; c.fillText('✦', 0, 4); c.restore(); return;
    }
    if (o.type === 'boost' || o.type === 'fever') {
      const color = o.type === 'boost' ? '#a2f9dc' : '#ffdc76'; c.save(); c.translate(x, y + Math.sin(this.model.time * 5) * 4);
      c.shadowColor = color; c.shadowBlur = 19; this.rounded(-15, -17, 30, 34, 9, color); c.shadowBlur = 0;
      c.fillStyle = '#273344'; c.font = 'bold 23px Arial'; c.textAlign = 'center'; c.fillText(o.type === 'boost' ? 'ϟ' : '★', 0, 8); c.restore(); return;
    }
    c.fillStyle = '#34253645'; c.beginPath(); c.ellipse(x + w / 2, B.ground + 4, w * .7, 4, 0, 0, Math.PI * 2); c.fill();
    if (o.profile) {
      const label = o.profile === 'high' ? 'HIGH' : o.profile === 'long' ? 'LONG' : 'LOW';
      c.font = 'bold 8px Arial'; c.textAlign = 'center';
      this.rounded(x + w / 2 - 19, y - 22, 38, 15, 4, o.profile === 'high' ? '#d5cff2' : '#b4e2d1');
      c.fillStyle = '#344157'; c.fillText(label, x + w / 2, y - 11);
    }
    if (o.type === 'cone') {
      this.rounded(x - 5, B.ground - 5, w + 10, 7, 3, '#db6e46');
      c.fillStyle = '#f69059'; c.beginPath(); c.moveTo(x, B.ground - 5); c.lineTo(x + w * .4, y); c.lineTo(x + w * .6, y); c.lineTo(x + w, B.ground - 5); c.fill();
      c.fillStyle = '#ffecc6'; c.beginPath(); c.moveTo(x + 6, y + h * .53); c.lineTo(x + w - 6, y + h * .53); c.lineTo(x + w - 10, y + h * .3); c.lineTo(x + 10, y + h * .3); c.fill();
    } else if (o.type === 'hurdle') {
      this.rounded(x, y, w, 9, 2, '#eee7d4'); this.rounded(x + 3, y + 9, 4, h - 9, 1, '#5d6c86'); this.rounded(x + w - 7, y + 9, 4, h - 9, 1, '#5d6c86');
      c.fillStyle = '#dc745c'; c.fillRect(x + 10, y, 13, 9);
    } else if (o.type === 'dummy') {
      this.rounded(x + 2, y, w - 4, h - 12, 7, '#8c82b0');
      this.rounded(x + 6, y + 4, w - 12, h - 23, 4, '#a699c9');
      c.strokeStyle = '#f2e7ff'; c.lineWidth = 2;
      for (const cy of [y + 32, y + 53]) { c.beginPath(); c.moveTo(x + 9, cy); c.lineTo(x + w / 2, cy - 7); c.lineTo(x + w - 9, cy); c.stroke(); }
      this.rounded(x + w / 2 - 4, y + h - 14, 8, 14, 2, '#566878');
      this.rounded(x - 4, B.ground - 5, w + 8, 6, 3, '#566878');
    } else if (o.type === 'bench') {
      this.rounded(x, y, w, 12, 3, '#e8c695'); c.fillStyle = '#637684'; c.fillRect(x + 9, y + 12, 7, h - 12); c.fillRect(x + w - 16, y + 12, 7, h - 12);
      c.strokeStyle = '#a58666'; c.lineWidth = 1; c.beginPath(); c.moveTo(x + 5, y + 7); c.lineTo(x + w - 5, y + 7); c.stroke();
    } else {
      this.rounded(x, y, w, h, 6, '#79aaa7'); this.rounded(x + 3, y, w - 6, 5, 3, '#b3d7cf');
      c.strokeStyle = '#b5e6d2'; c.lineWidth = 1.5;
      for (const side of [-1, 1]) { const cx = x + w / 2 + side * 25; c.beginPath(); c.moveTo(cx - side * 8, y + 11); c.lineTo(cx, y + 15); c.lineTo(cx - side * 8, y + 20); c.stroke(); }
    }
  }
  dispose() { this.particles = []; this.trails = []; }
}
