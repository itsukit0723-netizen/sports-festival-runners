export function Icon({ name, size = 20 }: { name: 'sound' | 'mute' | 'arrow' | 'play' | 'pause' | 'back' | 'retry' | 'trophy' | 'bolt' | 'tap' | 'move'; size?: number }) {
  const paths: Record<typeof name, React.ReactNode> = {
    sound: <><path d="m11 4-5 4H3v8h3l5 4z"/><path d="M15 8a6 6 0 0 1 0 8m3-11a10 10 0 0 1 0 14"/></>,
    mute: <><path d="m11 4-5 4H3v8h3l5 4z"/><path d="m16 9 6 6m0-6-6 6"/></>,
    arrow: <><path d="M4 12h15m-6-6 6 6-6 6"/></>,
    play: <path d="m8 5 11 7-11 7z" fill="currentColor" stroke="none"/>,
    pause: <><path d="M8 5v14M16 5v14" strokeWidth="3"/></>,
    back: <path d="m14 5-7 7 7 7M7 12h14"/>,
    retry: <><path d="M4 9a8 8 0 1 1 0 7M4 3v6h6"/></>,
    trophy: <><path d="M8 3h8v6a4 4 0 0 1-8 0zM8 5H4v2a4 4 0 0 0 4 4m8-6h4v2a4 4 0 0 1-4 4m-4 2v7m-4 0h8"/></>,
    bolt: <path d="m13 2-9 12h7l-1 8 10-13h-7z" fill="currentColor" stroke="none"/>,
    tap: <><path d="M9 12V6a2 2 0 0 1 4 0v6l2-1 4 3-2 7H9l-5-7 2-2 3 3"/><path d="M5 5 3 3m14 2 2-2M11 1v1"/></>,
    move: <><path d="M3 12h18M7 8l-4 4 4 4m10-8 4 4-4 4"/></>,
  };
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{paths[name]}</svg>;
}
