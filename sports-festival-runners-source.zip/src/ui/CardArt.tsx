function Basketball({ x, y, r }: { x: number; y: number; r: number }) {
  return <g transform={`translate(${x} ${y}) rotate(-24)`}>
    <circle r={r} fill="url(#ballOrange)"/><clipPath id="ballClip"><circle r={r}/></clipPath>
    <g clipPath="url(#ballClip)" fill="none" stroke="#743e27" strokeWidth="3">
      <path d={`M${-r} 0H${r}M0 ${-r}V${r}`}/>
      <ellipse cx={-r * 1.08} rx={r * .86} ry={r * 1.3}/><ellipse cx={r * 1.08} rx={r * .86} ry={r * 1.3}/>
    </g><circle r={r} stroke="#ca6a36" strokeWidth="1.5" fill="none"/>
  </g>;
}
export function CardArt({ football = false }: { football?: boolean }) {
  return football ? <svg className="card-art football-art" viewBox="0 0 560 302" role="img" aria-label="月明かりと暖かな照明の夜のコートを転がるサッカーボール">
    <defs><linearGradient id="footBg" x2="0" y2="1"><stop stopColor="#24364b"/><stop offset="1" stopColor="#72838c"/></linearGradient><linearGradient id="soccerWhite" x2=".6" y2="1"><stop stopColor="#fff4d8"/><stop offset=".6" stopColor="#e1e3d8"/><stop offset="1" stopColor="#8faaa9"/></linearGradient><filter id="soft"><feGaussianBlur stdDeviation="6"/></filter></defs>
    <path fill="url(#footBg)" d="M0 0h560v302H0z"/>
    <circle cx="448" cy="57" r="28" fill="#fff4d0" opacity=".65"/>
    <path d="m221 68 98 0 241 234H0z" fill="#a07b64"/><path d="m229 68 82 0 210 234H16z" fill="#3c5755"/>
    <path d="m238 68-179 234m245-234 182 234" fill="none" stroke="#e1e9cb" strokeWidth="2"/>
    <path d="M271 93v10m0 11v15m0 13v23m0 18v32" stroke="#cbdcbb" strokeWidth="2"/>
    <g fill="#2c4052"><path d="m0 111 184-44 14 7L0 135z"/><path d="m356 66 204 47v27L341 74z"/></g>
    <g stroke="#e9e5d8" strokeWidth="5"><path d="m0 111 184-44M356 66l204 47"/></g>
    <g fill="#3c5659"><circle cx="55" cy="83" r="21"/><circle cx="117" cy="64" r="17"/><circle cx="455" cy="72" r="20"/><circle cx="514" cy="90" r="24"/></g>
    <g stroke="#293d50" strokeWidth="4"><path d="M158 88V20m238 64V15"/></g>
    <g fill="#ffedc7"><path d="M144 17h28v6h-28m238-11h29v6h-29"/></g>
    <path d="m148 24-35 80h85l-30-80m218-5-25 71h82l-35-71" fill="#ffe0ad" opacity=".06"/>
    <g transform="translate(333 107)"><path d="m0 0 34 5v32L0 26z" fill="#2d4350"/><path d="m0 0 34 5v4L0 4z" fill="#bf946d"/><path d="m7 10 20 3" stroke="#e6c294" strokeWidth="2"/></g>
    <g fill="#8f9d93"><path d="M52 95h6v29h-6m63-46h5v23h-5m331-17h6v29h-6m53-11h7v29h-7"/></g>
    <g transform="translate(213 117)"><path d="m0 17 9-26 10 26z" fill="#f5a17a"/><path d="M3 8h13" stroke="#fff2dd" strokeWidth="4"/><path d="M-4 17h27v5H-4" fill="#cb8067"/></g>
    <g transform="translate(343 165)"><path d="m0 25 13-38 14 38z" fill="#f5a17a"/><path d="M5 10h18" stroke="#fff2dd" strokeWidth="5"/><path d="M-5 25h37v7H-5" fill="#cb8067"/></g>
    <g fill="#ffe08c" stroke="#f7f0c3" strokeWidth="1"><path d="m273 99 3 6 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1z"/><path d="m280 137 5 9 10 1-7 7 2 10-10-5-9 5 2-10-7-7 10-1z"/><path d="m286 190 7 13 14 2-10 10 3 14-14-7-12 7 2-14-10-10 14-2z"/></g>
    <ellipse cx="216" cy="263" rx="63" ry="12" fill="#273e49" opacity=".23" filter="url(#soft)"/>
    <g transform="translate(210 214) rotate(18)"><circle r="54" fill="url(#soccerWhite)"/><clipPath id="soccerClip"><circle r="54"/></clipPath><g fill="#31454d" clipPath="url(#soccerClip)"><path d="m-14-17 24-2 10 23-19 17-23-13zM-20-53l20-8 14 19-17 16-22-9zM42-38l25 9 2 27-24 4-15-20zM39 28l18 3-3 27-32 8-6-26zM-47 14l20 10 1 24-29 5-10-26z"/></g><g fill="none" stroke="#aeb8b4" strokeWidth="1"><path d="m-14-17-10-18M10-19l3-23M20 4l25-6M1 21l15 19M-22 8l-25 6"/></g></g>
    <path d="m123 230-35 21m47-5-22 21m28-3-24 17" stroke="#f5f4d4" strokeWidth="3" strokeLinecap="round"/>
    <text x="25" y="34" fill="#d7e1c4" fontSize="10" fontWeight="700" letterSpacing="2.5">AFTER DARK. KEEP ROLLING.</text>
  </svg> : <svg className="card-art basketball-art" viewBox="0 0 560 302" role="img" aria-label="夕暮れのコートを跳ねるバスケットボール">
    <defs><linearGradient id="courtBg" x2="0" y2="1"><stop stopColor="#2f5050"/><stop offset="1" stopColor="#a6b69c"/></linearGradient><radialGradient id="ballOrange" cx=".3" cy=".2" r=".85"><stop stopColor="#ffca7d"/><stop offset=".6" stopColor="#f19b51"/><stop offset="1" stopColor="#d57038"/></radialGradient><filter id="ballShadow"><feGaussianBlur stdDeviation="6"/></filter></defs>
    <path fill="url(#courtBg)" d="M0 0h560v302H0z"/><circle cx="407" cy="67" r="30" fill="#eee4ab" opacity=".75"/>
    <g fill="#56786b"><path d="M0 127 28 88l26 39 21-56 46 56 34-40 28 40 31-58 25 58 36-33 29 33 28-60 37 60 48-46 28 46 34-50 43 50 37-30 29 30v58H0z"/></g>
    <path d="M0 159h560v143H0z" fill="#b9b398"/><path d="m-30 246 590-58v114H-30z" fill="#b58167"/>
    <g fill="none" stroke="#eee1bb" strokeWidth="2" opacity=".8"><path d="m0 264 560-52m-281 25 82 65m82-94 117 94"/><ellipse cx="279" cy="270" rx="76" ry="25"/><path d="m472 221 37 81"/></g>
    <path d="M0 144h560" stroke="#476957" strokeWidth="5"/>
    <path d="M0 152h560" stroke="#d9d8b3" strokeWidth="2"/>
    <g stroke="#466858" strokeWidth="2" opacity=".65"><path d="M28 101v57m38-49v49m38-50v50m38-42v42m38-46v46m38-45v45m38-48v48m38-47v47m38-47v47m38-47v47m38-47v47m38-45v45m38-45v45m38-46v46"/></g>
    <g transform="translate(457 85)"><path d="M8 32v100" stroke="#597365" strokeWidth="6"/><path d="M-26-12h63v43h-63z" fill="#e9e5cf"/><path d="M-8 7h25v18H-8z" fill="none" stroke="#cf8765" strokeWidth="2"/><ellipse cy="34" rx="19" ry="4" fill="none" stroke="#cf8765" strokeWidth="4"/><path d="m-18 35 6 24h24l6-24m-28 1 4 24m4-24v24m8-24-4 24" stroke="#f5e8cd" fill="none"/></g>
    <ellipse cx="247" cy="263" rx="78" ry="11" fill="#4c4f3c" opacity=".3" filter="url(#ballShadow)"/>
    <path d="m137 198-59 12m64 8-40 15m45 5-51 20" stroke="#e6e9c4" strokeWidth="3" strokeLinecap="round"/>
    <Basketball x={251} y={173} r={70}/>
    <g fill="#f3dc8a" stroke="#fff1bd" strokeWidth="2"><ellipse cx="340" cy="119" rx="8" ry="12"/><ellipse cx="372" cy="107" rx="8" ry="12"/><ellipse cx="405" cy="111" rx="8" ry="12"/></g>
    <g transform="translate(385 236)"><path d="m0 28 12-36 13 36z" fill="#f5a17a"/><path d="M4 12h18" stroke="#ffedcf" strokeWidth="5"/><path d="M-5 28h35v6H-5" fill="#cf8060"/></g>
    <text x="25" y="34" fill="#d7e1c4" fontSize="10" fontWeight="700" letterSpacing="2.5">OWN THE COURT</text>
  </svg>;
}
