import type { GameId, RewardKind } from '../core/types';

export interface RewardNotice { kind: RewardKind; points: number; serial: number }
export function RewardFeedback({ notice }: { notice: RewardNotice }) {
  return <div key={notice.serial} className={`reward-feedback ${notice.kind}`}>
    <span className="reward-caption">{notice.kind === 'landing' ? '早めの着地で回収' : 'スター得点が2倍'}</span>
    <strong>{notice.kind === 'landing' ? '着地コイン GET!' : '狭いルート成功! ×2'}</strong>
    <b className="reward-points">+{notice.points.toLocaleString()}</b>
  </div>;
}
export function RouteCue({ game, text }: { game: GameId; text: string }) {
  const landing = game === 'basketballRunner';
  return <div className={`route-cue ${landing ? 'landing' : 'double'}`}>
    <strong>{landing ? '低めのジャンプで、もうひと取り' : text.includes('難所') ? 'ひと息ついて、回収チャンス' : 'どちらのルートで進む？'}</strong>
    <span>{text}</span>
  </div>;
}
