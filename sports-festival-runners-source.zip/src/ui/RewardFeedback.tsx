import type { GameId, RewardKind } from '../core/types';

export interface RewardNotice { kind: RewardKind; points: number; serial: number }
export function RewardFeedback({ notice }: { notice: RewardNotice }) {
  if (notice.kind === 'double') return null;
  return <div key={notice.serial} className={`reward-feedback ${notice.kind}`}>


    <b className="reward-points">+{notice.points.toLocaleString()}</b>
  </div>;
}
export function RouteCue({ game, text }: { game: GameId; text: string }) {
  const landing = game === 'basketballRunner';
  return <div className={`route-cue ${landing ? 'landing' : 'double'}`}>
    <strong>{landing ? '低めのジャンプで、もうひと取り' : text.includes('難所') ? 'ひと息ついて、回収チャンス' : 'どちらのルートで進む？'}</strong>
    <span>{text}</span>
  </div>;
}
