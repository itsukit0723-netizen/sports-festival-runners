import { WORLDS, type WorldId } from '../games/football/worlds';
import type { CSSProperties } from 'react';
import './WorldArrival.css';
export interface WorldArrivalState { world: WorldId; serial: number }
export function WorldArrival({arrival,paused=false}:{arrival:WorldArrivalState;paused?:boolean}){
  return <div key={arrival.serial} className={`world-arrival${paused?' is-paused':''}`} style={{'--arrival-color':WORLDS[arrival.world].accent} as CSSProperties} role="status" aria-live="polite">
    <div className="world-arrival-edge"/><div className="world-arrival-ring"/>
    <div className="world-arrival-title"><span>WORLD SHIFT</span><strong>{WORLDS[arrival.world].name}</strong></div>
  </div>;
}
