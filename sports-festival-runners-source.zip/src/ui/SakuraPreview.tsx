import { useEffect, useRef, useState } from 'react';
import { FootballModel } from '../games/football/model';
import { FootballRenderer } from '../games/football/renderer';
import { WORLD_IDS, WORLDS, type WorldId } from '../games/football/worlds';
import { WorldArrival, type WorldArrivalState } from './WorldArrival';
import { STEP } from '../core/config';
import { emptyInput } from '../core/types';
import './SakuraPreview.css';
const TITLES:Record<WorldId,string>={city:'月灯りのネオン街',sakura:'夜桜の参道',ice:'蒼氷の峡谷',orbit:'星環の宇宙回廊',ember:'熔光の遺跡'};

// Review-only tour using the shipped model and renderer. Never saves scores.
export default function SakuraPreview({initialWorld='sakura',autoCycle=false}:{initialWorld?:WorldId;autoCycle?:boolean}) {
  const canvas=useRef<HTMLCanvasElement>(null),running=useRef(true),target=useRef(initialWorld),cycle=useRef(autoCycle);
  const [selected,setSelected]=useState(initialWorld),[cycling,setCycling]=useState(autoCycle);
  const [ready,setReady]=useState(false),[playing,setPlaying]=useState(true),[error,setError]=useState(false),[arrival,setArrival]=useState<WorldArrivalState|null>(null);
  useEffect(()=>{
    const model=new FootballModel(2);model.world=initialWorld;let renderer:FootballRenderer;
    try{renderer=new FootballRenderer(canvas.current!,model);}catch{setError(true);return;}
    let frame=0,last=0,accumulator=0,shown:WorldId|undefined,until=0,serial=0,sinceChange=0,wasReady=false;
    const animate=(timestamp:number)=>{
      model.world=target.current;
      if(renderer.worldModelFailed){setError(true);return;}
      const dt=last?Math.min(.05,(timestamp-last)/1000):0;last=timestamp;
      const loaded=renderer.worldModelReady;
      if(loaded!==wasReady){wasReady=loaded;setReady(loaded);}
      if(loaded && shown!==model.world){
        if(shown){setArrival({world:model.world,serial:++serial});until=model.time+1.1;}
        else for(let i=0;i<40;i++)renderer.render(.05,[]);
        shown=model.world;sinceChange=0;
      }
      if(loaded&&running.current&&!document.hidden){
        accumulator+=dt;sinceChange+=dt;
        while(accumulator>=STEP){const dx=model.nextChallengeRow().safeX-model.x;model.update(STEP,{...emptyInput(),axis:Math.abs(dx)<.06?0:Math.sign(dx),testInvincible:true});model.world=target.current;model.events.length=0;accumulator-=STEP;}
        if(cycle.current&&sinceChange>=9){const next=WORLD_IDS[(WORLD_IDS.indexOf(target.current)+1)%WORLD_IDS.length];target.current=next;setSelected(next);sinceChange=0;}
      }else accumulator=0;
      if(until&&model.time>=until){until=0;setArrival(null);}
      renderer.render(loaded&&running.current?dt:0,[]);
      canvas.current!.dataset.asset=loaded?'blender':'loading';canvas.current!.dataset.world=model.world;
      canvas.current!.dataset.players=renderer.playerModelReady?'blender':'loading';
      frame=requestAnimationFrame(animate);
    };
    const resize=()=>renderer.resize();window.addEventListener('resize',resize);frame=requestAnimationFrame(animate);
    return()=>{cancelAnimationFrame(frame);window.removeEventListener('resize',resize);renderer.dispose();};
  },[initialWorld]);
  const choose=(world:WorldId)=>{target.current=world;setSelected(world);};
  return <main className="sakura-preview" style={{background:`radial-gradient(ellipse at 50% 25%,${WORLDS[selected].sky},#101720 70%)`}}>
    <header><span>BLENDER × SPORTS FESTIVAL</span><h1>{TITLES[selected]}</h1><p>5つの世界を、自動走行で見て回るプレビュー。</p></header>
    <div className="world-preview-tabs" role="tablist" aria-label="世界を選ぶ">{WORLD_IDS.map(id=><button key={id} role="tab" aria-selected={selected===id} onClick={()=>choose(id)}>{WORLDS[id].name}</button>)}</div>
    <div className="sakura-preview-stage"><canvas ref={canvas} aria-label="Blenderで制作した5世界の自動走行プレビュー"/>{arrival&&<WorldArrival arrival={arrival} paused={!playing}/>}<div className="preview-world-tag">{WORLDS[selected].name}</div>{!ready&&<div className="sakura-preview-loading">{error?'表示を開始できませんでした。':'世界を準備しています…'}</div>}</div>
    <footer><button onClick={()=>{running.current=!running.current;setPlaying(running.current);}} disabled={!ready}>{playing?'一時停止':'再生する'}</button><button aria-pressed={cycling} onClick={()=>{cycle.current=!cycle.current;setCycling(cycle.current);}}>世界の自動切替 {cycling?'ON':'OFF'}</button><a href="./">ゲームで遊ぶ ↗</a><small>鑑賞用プレビュー・スコア保存なし</small></footer>
  </main>;
}
