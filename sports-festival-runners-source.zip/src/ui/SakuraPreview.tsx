import { useEffect, useRef, useState } from 'react';
import { FootballModel } from '../games/football/model';
import { FootballRenderer } from '../games/football/renderer';
import { STEP } from '../core/config';
import { emptyInput } from '../core/types';
import './SakuraPreview.css';

// A review-only tour, using the actual shipped renderer and course model.
// It never saves scores or alters the normal game's opening/world selection.
export default function SakuraPreview() {
  const canvas = useRef<HTMLCanvasElement>(null), running = useRef(true);
  const [ready,setReady] = useState(false), [playing,setPlaying] = useState(true), [error,setError] = useState(false);
  useEffect(() => {
    const model = new FootballModel(2); model.world = 'sakura';
    let renderer: FootballRenderer;
    try { renderer = new FootballRenderer(canvas.current!,model); } catch { setError(true); return; }
    let frame = 0, last = 0, accumulator = 0, started = false;
    const animate = (timestamp:number) => {
      if (renderer.sakuraModelFailed) { setError(true); return; }
      const dt = last ? Math.min(.05,(timestamp-last)/1000) : 0; last = timestamp;
      if (renderer.sakuraModelReady && !started) { started=true;for(let i=0;i<40;i++)renderer.render(.05,[]);setReady(true); }
      if(started && running.current && !document.hidden) {
        accumulator+=dt;
        while(accumulator>=STEP){const dx=model.nextChallengeRow().safeX-model.x;model.update(STEP,{...emptyInput(),axis:Math.abs(dx)<.06?0:Math.sign(dx),testInvincible:true});model.world='sakura';model.events.length=0;accumulator-=STEP;}
      } else accumulator=0;
      renderer.render(started && running.current ? dt : 0,[]);
      canvas.current!.dataset.asset = renderer.sakuraModelReady ? 'blender' : 'loading';
      frame=requestAnimationFrame(animate);
    };
    const resize=()=>renderer.resize();window.addEventListener('resize',resize);frame=requestAnimationFrame(animate);
    return ()=>{cancelAnimationFrame(frame);window.removeEventListener('resize',resize);renderer.dispose();};
  },[]);
  const toggle=()=>{running.current=!running.current;setPlaying(running.current);};
  return <main className="sakura-preview">
    <header><span>BLENDER × SPORTS FESTIVAL</span><h1>夜桜の参道</h1><p>桜の世界を、自動走行で見て回るプレビュー。</p></header>
    <div className="sakura-preview-stage"><canvas ref={canvas} aria-label="Blenderで制作した夜桜の参道の自動走行プレビュー"/>{!ready && <div className="sakura-preview-loading">{error?'表示を開始できませんでした。':'桜の世界を準備しています…'}</div>}</div>
    <footer><button onClick={toggle} disabled={!ready}>{playing?'一時停止':'再生する'}</button><a href="./">ゲームで遊ぶ ↗</a><small>鑑賞用プレビュー・スコア保存なし</small></footer>
  </main>;
}
