/** Track the visible page, including Safari toolbar changes, without scaling input. */
export function bindPlayViewport(page:HTMLElement,canvas:HTMLCanvasElement,onResize:()=>void) {
  const viewport=window.visualViewport;
  const header=page.parentElement?.querySelector<HTMLElement>('[data-play-header]');
  const previousHeight=page.style.height;
  page.setAttribute('data-play-viewport','');
  const refresh=()=>{
    const height=viewport?.height || window.innerHeight;
    const inset=header?.getBoundingClientRect().height??0;
    if(Number.isFinite(height)&&height>0){
      page.style.setProperty('--play-height',`${Math.round(height*100)/100}px`);
      page.style.setProperty('--play-inset',`${inset}px`);
      page.style.height=`${Math.max(0,Math.round((height-inset)*100)/100)}px`;
    }
    onResize();
  };
  const observer=typeof ResizeObserver==='undefined'?undefined:new ResizeObserver(refresh);
  observer?.observe(canvas);
  if(header)observer?.observe(header);
  window.addEventListener('resize',refresh);viewport?.addEventListener('resize',refresh);
  refresh();
  return()=>{window.removeEventListener('resize',refresh);viewport?.removeEventListener('resize',refresh);observer?.disconnect();page.style.removeProperty('--play-height');page.style.removeProperty('--play-inset');page.style.height=previousHeight;page.removeAttribute('data-play-viewport');};
}
