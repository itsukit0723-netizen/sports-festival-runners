import { useEffect, useRef, useState } from 'react';
import { STEP, BASKETBALL as B, FOOTBALL as F } from '../core/config';
import { ArcadeAudio } from '../core/audio';
import { InputController } from '../core/input';
import { saveBest } from '../core/storage';
import type { GameId, GameModel, GameRenderer, GameStats, GameEvent } from '../core/types';
import { BasketballModel } from '../games/basketball/model';
import { BasketballRenderer } from '../games/basketball/renderer';
import { FootballModel } from '../games/football/model';
import { Icon } from './Icon';
import { RewardFeedback, RouteCue, type RewardNotice } from './RewardFeedback';
// TEMP TEST CONTROLS
import { useTemporaryInvincibility, TemporaryInvincibilityButton } from '../testing/TemporaryInvincibility';
interface Props { id: GameId; best: number; sound: boolean; onToggleSound(): void; onBest(score: number): void; onHome(): void }
const initial: GameStats = { score: 0, time: 0, coins: 0, combo: 0, speed: 0, boost: 0, fever: 0, bonus: 0, over: false };
const messages: Partial<Record<GameEvent['kind'], string>> = { near: 'NEAR MISS +70', dribble: 'NICE DRIBBLE +80', bonus: 'BONUS TIME!', boost: 'SPEED BOOST', fever: 'FEVER! ×2', smash: 'SMASH! +100' };
export default function GameView(props: Props) {
  const { id, sound, onToggleSound, onHome } = props;
  const canvas = useRef<HTMLCanvasElement>(null), surface = useRef<HTMLDivElement>(null);
  const audio = useRef<ArcadeAudio | null>(null), pausedRef = useRef(false);
  const propsRef = useRef(props); propsRef.current = props;
  const [run, setRun] = useState(0), [paused, setPaused] = useState(false);
  const testControls = useTemporaryInvincibility(run); // TEMP TEST CONTROLS
  const [stats, setStats] = useState(initial), [ready, setReady] = useState(false);
  const [error, setError] = useState(''), [notice, setNotice] = useState({ text: '', serial: 0 });
  const [reward, setReward] = useState<RewardNotice | null>(null);
  const [isNewBest, setNewBest] = useState(false);
  const football = id === 'rollingFootball';
  const setPause = (value: boolean) => { pausedRef.current = value; setPaused(value); };
  const retry = () => { setPause(false); setRun(n => n + 1); };
  useEffect(() => { audio.current?.setEnabled(sound); }, [sound]);
  useEffect(() => {
    let disposed = false, frame = 0, renderer: GameRenderer | undefined, input: InputController | undefined;
    const model: GameModel = football ? new FootballModel() : new BasketballModel();
    const soundEngine = new ArcadeAudio(); soundEngine.setEnabled(propsRef.current.sound); soundEngine.unlock(); audio.current = soundEngine;
    let last = 0, accumulator = 0, hudIn = 0, announced = false, noticeUntil = 0, rewardUntil = 0, rewardSoundAt = -1000;
    let fpsElapsed = 0, frames = 0, pendingJump = false, pendingDrag = 0;
    setStats(initial); setNewBest(false); setReady(false); setNotice({ text: '', serial: 0 }); setReward(null);
    const pause = () => { if (!model.over) { setPause(!pausedRef.current); input?.reset(); } };
    const hide = () => { if (document.hidden && !model.over) { setPause(true); input?.reset(); } };
    const blur = () => { if (!model.over) { setPause(true); input?.reset(); } };
    const lost = (e: Event) => { e.preventDefault(); setPause(true); setError('3D描画が中断されました。ゲーム選択に戻って、もう一度お試しください。'); };
    async function setup() {
      try {
        if (football) { const { FootballRenderer } = await import('../games/football/renderer'); if (disposed) return; renderer = new FootballRenderer(canvas.current!, model as FootballModel); }
        else renderer = new BasketballRenderer(canvas.current!, model as BasketballModel);
      } catch { if (!disposed) setError('ゲームの描画を開始できませんでした。3D対応のブラウザーでお試しください。'); return; }
      if (disposed) { renderer?.dispose(); return; }
      input = new InputController(surface.current!, id, pause, () => soundEngine.unlock());
      setReady(true);
      const animate = (timestamp: number) => {
        if (disposed) return;
        const elapsed = last ? Math.min(.05, (timestamp - last) / 1000) : 0; last = timestamp;
        const incoming = input!.read(), events: GameEvent[] = [];
        if (!pausedRef.current && !model.over) {
          accumulator += elapsed;
          pendingJump ||= incoming.jump; pendingDrag += incoming.drag;
          while (accumulator >= STEP) {
            model.update(STEP, testControls.apply({ ...incoming, jump: pendingJump, drag: pendingDrag }));
            pendingJump = false; pendingDrag = 0; accumulator -= STEP;
            events.push(...model.events.splice(0));
            if (model.over) { accumulator = 0; break; }
          }
          for (const e of events) {
            if (e.reward && e.points !== undefined) {
              if (e.reward === 'landing') {
                const continuing = timestamp < rewardUntil;
                const kind = e.reward, points = e.points;
                setReward(previous => ({ kind, points: continuing && previous?.kind === kind ? previous.points + points : points, serial: (previous?.serial ?? 0) + 1 }));
                rewardUntil = timestamp + 1400;
                setNotice(previous => ({ ...previous, text: '' })); noticeUntil = 0;
              }
              if (timestamp - rewardSoundAt > 250) { soundEngine.playReward(e.reward); rewardSoundAt = timestamp; }
            } else soundEngine.play(e.kind, e.value);
            const text = e.kind === 'near' && football ? 'NEAR MISS +60' : messages[e.kind];
            if (text && timestamp >= rewardUntil) { setNotice(n => ({ text, serial: n.serial + 1 })); noticeUntil = timestamp + 1500; }
          }
          if (model.over && !announced) {
            announced = true; const score = Math.floor(model.score), previous = propsRef.current.best;
            if (!testControls.used.current) {
              setNewBest(score > previous); const best = saveBest(id, score); propsRef.current.onBest(best);
            }
          }
        } else { accumulator = 0; pendingJump = false; pendingDrag = 0; input!.reset(); }
        if (noticeUntil && timestamp > noticeUntil) { noticeUntil = 0; setNotice(n => ({ ...n, text: '' })); }
        if (rewardUntil && timestamp > rewardUntil) { rewardUntil = 0; setReward(null); }
        soundEngine.rolling(model.speed, football && !pausedRef.current && !model.over);
        soundEngine.surge(model.boost > 0 ? 1 : model.fever > 0 ? .75 : 0, !pausedRef.current && !model.over);
        renderer!.render(pausedRef.current ? 0 : elapsed, events);
        hudIn -= elapsed;
        if (hudIn <= 0 || events.some(e => e.kind === 'over')) {
          setStats({ time: model.time, score: Math.floor(model.score), coins: model.coins, combo: model.combo, speed: model.speed, boost: model.boost, fever: model.fever, bonus: model.bonus, over: model.over, routeHint: model.routeHint }); hudIn = .1;
        }
        fpsElapsed += elapsed; frames++;
        if (fpsElapsed >= 1) { canvas.current!.dataset.fps = String(Math.round(frames / fpsElapsed)); fpsElapsed = 0; frames = 0; }
        frame = requestAnimationFrame(animate);
      };
      frame = requestAnimationFrame(animate);
    }
    const resize = () => renderer?.resize();
    window.addEventListener('resize', resize); window.addEventListener('blur', blur);
    document.addEventListener('visibilitychange', hide); canvas.current?.addEventListener('webglcontextlost', lost);
    void setup();
    const node = canvas.current;
    return () => { disposed = true; cancelAnimationFrame(frame); input?.dispose(); renderer?.dispose(); soundEngine.dispose(); window.removeEventListener('resize', resize); window.removeEventListener('blur', blur); document.removeEventListener('visibilitychange', hide); node?.removeEventListener('webglcontextlost', lost); };
  // A new model and renderer are needed only for a new game / retry.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id, run]);
  return <div className={`game-page ${football ? 'football' : 'basketball'}`}>
    <aside className="game-side-info"><a className="brand" onClick={onHome}><span className="brand-mark"><Icon name="bolt"/></span><span>SF ARCADE</span></a><div><span className="eyebrow">{football ? '02 / THE FIELD' : '01 / THE COURT'}</span><h1>{football ? <>ROLLING<br/>FOOTBALL</> : <>BASKETBALL<br/>RUNNER</>}</h1><p>{football ? '転がって、避けて、どこまでも！' : '跳んで、集めて、突き進め！'}</p><span className="side-controls"><Icon name={football ? 'move' : 'tap'} size={23}/>{football ? '← → / A D / ドラッグ' : '短タップ：小 / 長押し：大 / PC：SPACE'}</span><small>ESC または P で一時停止</small></div><button className="text-button" onClick={onHome}><Icon name="back" size={16}/>ゲーム選択へ</button></aside>
    <div className="game-shell" ref={surface}>
      <canvas ref={canvas} className="game-canvas" tabIndex={-1} role="img" aria-label={football ? 'サッカーゲーム画面。左右ドラッグまたは矢印キーで移動' : 'バスケゲーム画面。短いタップで小ジャンプ、長押しで大ジャンプ。感圧対応端末では強く押しても大ジャンプ。クリックまたはスペースで大ジャンプ'}/>
      {/* TEMP TEST CONTROLS */}
      {ready && !paused && !stats.over && !error && <TemporaryInvincibilityButton active={testControls.active} toggle={testControls.toggle} stats={stats}/>}
      <div className="game-hud"><button className="pause-button" aria-label="一時停止" onClick={() => setPause(true)}><Icon name="pause" size={20}/></button><div className="score-display"><span>{testControls.used.current ? 'TEST SCORE' : 'SCORE'}</span><strong>{stats.score.toLocaleString()}</strong></div><div className="best-display"><span><Icon name="trophy" size={11}/>BEST</span><b>{props.best.toLocaleString()}</b></div></div>
      {ready && !paused && !stats.over && !error && <>
        {football && stats.routeHint && <RouteCue game={id} text={stats.routeHint}/>}
        <div className="game-announcements" aria-live="polite">{reward ? <RewardFeedback notice={reward}/> : notice.text && <div key={notice.serial} className={`game-notice ${notice.text.includes('FEVER') ? 'fever-notice' : ''}`}>{notice.text}</div>}{!reward && stats.combo >= 3 && <div className="combo-counter"><b>{stats.combo}</b><span>COMBO</span></div>}</div>
        <div className="power-status">{stats.fever > 0 && <div className="power-pill fever-pill"><span>★ FEVER ×2 · SPEED UP</span><div style={{ width: `${stats.fever / B.feverDuration * 100}%` }}/></div>}{stats.boost > 0 && <div className="power-pill"><span>ϟ SPEED BOOST{football ? '' : ` ×${B.boostMultiplier}`}</span><div style={{ width: `${stats.boost / (football ? F.boostDuration : B.boostDuration) * 100}%` }}/></div>}</div>
        {stats.time < (football ? 3.2 : 5) && <div className="start-hint"><Icon name={football ? 'move' : 'tap'} size={29}/><strong>{football ? 'DRAG TO MOVE' : 'TAP / HOLD TO JUMP'}</strong><span>{football ? <>左右ドラッグ / ← → / A D<br/>狭いルートの橙スターは ×2</> : <>低い障害物は短め ／ 高い・横長は大きく<br/>短タップ：小 ／ 長押し・感圧：大<br/>PC：クリック / SPACE</>}</span></div>}
      </>}
      {!ready && !error && <div className="game-overlay"><div className="spinner"/><p>WARMING UP…</p></div>}
      {(paused || stats.over || error) && <div className="game-overlay" role="dialog" aria-modal="true" aria-label={error ? '読み込みエラー' : stats.over ? 'ゲーム結果' : '一時停止'}><div className="result-panel">
        <span className="result-eyebrow">{error ? 'LET’S TRY AGAIN' : stats.over ? isNewBest ? '✦ NEW PERSONAL BEST' : 'GOOD RUN. GO AGAIN.' : 'TAKE A BREATHER'}</span>
        <h2>{error ? 'OOPS!' : stats.over ? <>GAME<br/>OVER<span>.</span></> : <>PAUSED<span>.</span></>}</h2>
        {error ? <p>{error}</p> : stats.over ? <><span className="result-score-label">YOUR SCORE</span><div className="result-score">{stats.score.toLocaleString()}</div><div className="result-details"><span>{stats.time.toFixed(1)} <small>SECONDS</small></span><span>{stats.coins} <small>{football ? 'STARS' : 'COINS'}</small></span></div></> : <p>ひと休みしたら、続きをどうぞ。</p>}
        {!error && <button className="primary-button" onClick={stats.over ? retry : () => { audio.current?.unlock(); setPause(false); }} autoFocus><Icon name={stats.over ? 'retry' : 'play'} size={20}/>{stats.over ? 'RETRY' : 'RESUME'}<Icon name="arrow" size={20}/></button>}
        {testControls.used.current && <p>テストプレイ：BESTには保存されません。</p>}
        <button className="overlay-home" onClick={onHome}>ゲーム選択に戻る <Icon name="arrow" size={15}/></button>
        <button className="overlay-sound" onClick={onToggleSound}><Icon name={sound ? 'sound' : 'mute'} size={16}/>SOUND {sound ? 'ON' : 'OFF'}</button>
      </div></div>}
      <div className="game-bottom-label">{football ? 'ROLLING FOOTBALL' : 'BASKETBALL RUNNER'} <span>SF / ARCADE</span></div>
    </div>
    <div className="game-right-note" aria-hidden="true">ONE MORE<br/><em>TRY.</em><span>YOUR NEXT BEST<br/>IS ONE PLAY AWAY.</span></div>
  </div>;
}
